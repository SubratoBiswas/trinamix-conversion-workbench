import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import {
  Sparkles, Check, X, RefreshCw, Search, Filter as FilterIcon,
  GraduationCap, Edit2, ArrowLeft, ArrowLeftRight, AlertTriangle, ChevronDown, Lock, Download,
  GitBranch, Table2, ArrowRight, Layers, ChevronRight, CheckCircle2,
} from "lucide-react";

// P3 — tiny lock glyph for source-column PII badges in the canvas list.
const PiiLockGlyph: React.FC = () => <Lock className="h-2 w-2" />;
import { ConversionsApi, DatasetsApi, FbdiApi, InheritedStandardsApi, LearningApi, MappingApi, OutputApi, ProjectsApi } from "@/api";
import LearnFromExamplePanel from "@/components/learn/LearnFromExamplePanel";
import type { InheritedStandard, ReferenceStandard } from "@/api";
import { RuleAuthorModal } from "@/components/transforms/RuleAuthorModal";
import CodedValuesPanel from "@/components/transforms/CodedValuesPanel";
import {
  Button, Card, CardBody, EmptyState, Modal, PageLoader, PageTitle, Pill, Spinner,
} from "@/components/ui/Primitives";
import { RecommendationsPanel } from "@/components/recommendations/RecommendationsPanel";
import { buildRecommendations, type Recommendation } from "@/lib/recommendations";
import { confidenceTone, cn, formatNumber, statusTone } from "@/lib/utils";
import type {
  Conversion,
  DatasetColumnProfile,
  DatasetDetail,
  FBDIField,
  MappingCandidate,
  MappingSuggestion,
} from "@/types";

type FilterMode = "all" | "required" | "review" | "approved" | "unmapped" | "kb" | "mapped" | "learned";

// Source-system display labels mirroring the server-driven enum, so the
// KB badge can read "🧠 from NetSuite KB" instead of "🧠 from netsuite KB".
const KB_SOURCE_DISPLAY: Record<string, string> = {
  netsuite: "NetSuite",
  oracle_ebs: "Oracle EBS",
  sap_ecc: "SAP ECC",
  sap_s4: "SAP S/4",
  workday: "Workday",
  jde: "JDE",
  custom: "Custom",
};

// Map a target object to its fan-out catalog key so we can show the FBDI
// load-sequence at the top of the mapping screen.
// The values Generate Output writes for target fields with no source column —
// control constants, sequence keys, learned and AI-inferred defaults.
//
// This used to be a hard-coded table right here, copied from the backend's
// _CONTROL_DEFAULTS. That copy is why "Defaulted → 900001" would not go away:
// Batch ID was blanked in the corrections file, a suppress_field learning was
// recorded, and the generated file shipped empty — but the chip read its value
// from a constant compiled into the browser bundle, which no rule, learning or
// Keep blank press could ever reach. The table had also drifted: it still said
// Tax Organization Type = "Corporation" and Business Relationship =
// "PROSPECTIVE" after both had been corrected on the server.
//
// There is now one source of truth, /effective-defaults, which applies the same
// suppression the generator does. A mirror that cannot be corrected is worse
// than no mirror — it makes a correct fix look broken.
function normFieldKey(fieldName?: string | null): string {
  return (fieldName || "").toLowerCase().replace(/\*/g, "").trim();
}

/** What this field will actually carry, "" when it is deliberately blank.
 *  `suppressed` wins over a stored default_value on purpose: a stale default
 *  left on the row by an earlier seed is exactly what kept re-appearing. */
function defaultFor(
  m: { default_value?: string | null } | undefined,
  fieldName: string | null | undefined,
  effectiveDefaults: Record<string, string>,
  suppressed?: Set<string>,
): string {
  const k = normFieldKey(fieldName);
  if (suppressed?.has(k)) return "";
  return m?.default_value || effectiveDefaults[k] || "";
}

function seqKeyForTarget(target?: string | null): string | null {
  const s = (target || "").toLowerCase();
  if (/supplier|vendor/.test(s)) return "supplier";
  if (/customer|client/.test(s)) return "customer";
  if (/\bitem\b|product|material/.test(s)) return "item";
  if (/journal|\bgl\b/.test(s)) return "gl_journal";
  if (/autoinvoice|receivable/.test(s)) return "ar_invoice";
  if (/payable|\bap\b/.test(s)) return "ap_invoice";
  return null;
}

export const MappingReviewPage: React.FC = () => {
  const [params, setParams] = useSearchParams();
  const nav = useNavigate();
  const projParam = params.get("conversion");

  const [projects, setProjects] = useState<Conversion[]>([]);  // all conversions
  const [pid, setPid] = useState<string | null>(projParam ?? null);
  // Engagement (project) selector — scopes the conversion dropdown so the same
  // conversion names across 22 engagements are no longer ambiguous.
  const [engagements, setEngagements] = useState<import("@/types").Project[]>([]);
  const [engagementId, setEngagementId] = useState<string | null>(null);

  const [project, setProject] = useState<Conversion | null>(null);
  const [loadingConversion, setLoadingConversion] = useState(false);
  // AI verdicts shared across the table toolbar and the detail panel, keyed
  // target_field_id -> source_column -> {verdict, reason}. The toolbar "Vet
  // options with AI" fills it once; the detail panel reads it so a field the
  // toolbar already vetted shows its AI reasons with no second click (and no
  // second token spend). A field the toolbar skipped can still be vetted on its
  // own from the panel, which writes back here.
  const [aiVerdicts, setAiVerdicts] = useState<Record<string, Record<string, { verdict: string; reason: string }>>>({});
  const mergeAiVerdicts = useCallback(
    (incoming: Record<string, Record<string, { verdict: string; reason: string }>>) => {
      setAiVerdicts((prev) => {
        const next = { ...prev };
        for (const [tfid, byCol] of Object.entries(incoming || {})) {
          next[tfid] = { ...(next[tfid] || {}), ...byCol };
        }
        return next;
      });
    }, []);
  // Initial load of the conversion list + engagements (drives the landing view).
  const [loadingList, setLoadingList] = useState(true);
  // Surfaced when the conversion context fails to load (e.g. backend cold-start
  // or redeploy) so the page shows a retry affordance instead of spinning forever.
  const [loadError, setLoadError] = useState<string | null>(null);
  const [dataset, setDataset] = useState<DatasetDetail | null>(null);
  // Unified source-column list for the canvas. In dataset mode these are the
  // uploaded file's profiled columns; in EBS live mode they come from
  // Oracle ALL_TAB_COLUMNS for the conversion's ebs_table_hint.
  const [sourceColumns, setSourceColumns] = useState<DatasetColumnProfile[]>([]);
  const [ebsTable, setEbsTable] = useState<string | null>(null);
  // Diagnostic returned by the source-columns endpoint in EBS mode — explains
  // why zero columns came back (no connection / JDBC error / table not found).
  const [ebsDebug, setEbsDebug] = useState<Record<string, any> | null>(null);
  // Target-field ids that have at least one saved transformation rule, so the
  // canvas can badge them (rules apply at Generate Output, not as map lines).
  const [ruleTargetIds, setRuleTargetIds] = useState<Set<number>>(new Set());
  const [targetFields, setTargetFields] = useState<FBDIField[]>([]);
  const [mappings, setMappings] = useState<MappingSuggestion[]>([]);
  // Values Generate Output writes for unmapped target fields (control constants,
  // sequence keys, learned + AI-inferred defaults), keyed by normalized field
  // name. Lets the canvas show "defaulted → value" instead of a red required gap.
  const [effectiveDefaults, setEffectiveDefaults] = useState<Record<string, string>>({});
  // Fields the analyst has said must ship blank (strategy corrections,
  // suppress_field learnings, Keep blank). The backend already omits them from
  // `defaults`; this set also overrides a stale default_value still on the row.
  const [suppressedFields, setSuppressedFields] = useState<Set<string>>(new Set());
  // Cascade visibility — when an upstream master has taught a rule
  // (e.g. REMOVE_HYPHEN on Item.InventoryItemNumber), the matching FK
  // columns on this conversion inherit that rule at output time. We
  // surface them as a banner + per-row chips so the analyst can see
  // the propagation without having to open Output Preview.
  const [inherited, setInherited] = useState<InheritedStandard[]>([]);
  // Gold reference standard stored in the DB for this conversion's object type
  // (auto-applied; no re-upload needed). Null when none is on file yet.
  const [refStd, setRefStd] = useState<ReferenceStandard | null>(null);

  const [running, setRunning] = useState(false);
  const [filter, setFilter] = useState<FilterMode>("all");
  const [fillingPage, setFillingPage] = useState(false);
  // Precedence-layer filter (gold / learned / workbook / manual / deterministic /
  // default / ai / suppressed / unmapped) — set by clicking a chip in the bar.
  const [layerFilter, setLayerFilter] = useState<LayerKey | null>(null);
  // Canvas (drag-to-map graph) vs Table (row-per-field detail: required, how it
  // was mapped, transform, confidence, lower-probability alternatives, notes).
  const [viewMode, setViewMode] = useState<"canvas" | "table">("canvas");
  const [search, setSearch] = useState("");
  // FBDI load-sequence shown at the top of the mapping screen (Req 2).
  const [seqSteps, setSeqSteps] = useState<{ label: string; load_order: number }[]>([]);
  const [selectedMappingId, setSelectedMappingId] = useState<number | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [showRecs, setShowRecs] = useState(true);
  const [appliedRecIds, setAppliedRecIds] = useState<Set<string>>(new Set());
  const [learnedRecIds, setLearnedRecIds] = useState<Set<string>>(new Set());
  const [dismissedRecIds, setDismissedRecIds] = useState<Set<string>>(new Set());

  // Track which source columns have been highlighted in the canvas
  const [hoveredSource, setHoveredSource] = useState<string | null>(null);
  const [hoveredTarget, setHoveredTarget] = useState<number | null>(null);

  // Custom-rule authoring state — opens the universal RuleAuthor modal
  // pre-bound to the inspected mapping.
  const [ruleAuthorOpen, setRuleAuthorOpen] = useState(false);
  const [ruleAuthorMapping, setRuleAuthorMapping] = useState<MappingSuggestion | null>(null);
  // Split-one-source-into-many / combine-many-into-one column mapping modal.
  const [compositeOpen, setCompositeOpen] = useState(false);

  // Load all conversions + engagements on mount. We deliberately do NOT
  // auto-select a conversion: with none selected the page shows a project-wise
  // landing (engagement dropdown + that project's conversion cards). A conversion
  // is only opened when the user picks one (or a ?conversion= param is present).
  useEffect(() => {
    Promise.all([
      ConversionsApi.list().catch(() => null),
      ProjectsApi.list().catch(() => []),
    ]).then(([ps, engs]: [any, any]) => {
      setEngagements(engs || []);
      if (!ps) {
        setLoadError("Couldn't load the conversion list — the backend may be busy running live Oracle EBS queries. Retry in a moment.");
        setLoadingList(false);
        return;
      }
      setProjects(ps);
      // Default the engagement selector. An ?engagement= param (set by the
      // "Mapping list" back button) wins so the user lands on the same
      // engagement they were reviewing; otherwise pick the first project that
      // has conversions so the landing list is populated immediately.
      if (!engagementId && !pid) {
        const engParam = params.get("engagement");
        const withConv = (engs || []).find((e: any) =>
          ps.some((c: any) => String(c.project_id) === String(e.id)));
        const def = engParam
          ?? withConv?.id ?? (engs && engs[0]?.id) ?? (ps[0] ? String(ps[0].project_id) : null);
        if (def) setEngagementId(String(def));
      }
      setLoadingList(false);
    });
  }, []);

  // Load project context. Supports both source modes:
  //   • dataset mode  → dataset_id set; columns come from the upload
  //   • EBS live mode → dataset_id null; columns stream from Oracle EBS
  // dataset_id presence (not source_type) decides the mode, mirroring the
  // Conversion Detail page's source card rule.
  // Fill blanks with AI — available in BOTH canvas and table (lives in the shared
  // header). Only touches unmapped fields; results land in Needs review.
  const fillBlanksPage = async () => {
    if (!pid) return;
    if (!window.confirm("Ask AI to suggest a source for the unmapped fields? Results land in Needs-review for you to approve or reject — nothing is applied blindly.")) return;
    setFillingPage(true);
    try {
      const requiredOnly = filter === "unmapped" || filter === "required";
      const r = await MappingApi.aiFillBlanks(pid, { requiredOnly });
      if (r.filled > 0) { await loadAll(); setFilter("review"); }
      window.alert(r.filled > 0
        ? `AI suggested a source for ${r.filled} of ${r.considered} unmapped field(s). Showing Needs review — approve or reject.`
        : (r.note || "No unmapped fields to fill."));
    } catch (e: any) {
      window.alert(e?.response?.data?.detail || "AI fill is unavailable right now.");
    } finally { setFillingPage(false); }
  };

  // ── Vet + Export ────────────────────────────────────────────────────────
  // Both live HERE rather than in MappingTableView so the shared header can offer
  // them in canvas as well as table (the table view is only mounted in table mode,
  // so a handler owned by it is unreachable from canvas). Export pulls the ranked
  // candidates on click, so the workbook keeps its AI-vetted reason columns even
  // when the analyst never opened the table.
  const [vettingPage, setVettingPage] = useState(false);
  const [exportingPage, setExportingPage] = useState(false);
  const [vetMsgPage, setVetMsgPage] = useState<string | null>(null);
  const [vettedOnce, setVettedOnce] = useState(false);

  /** AI-vet the uncertain candidates for the given targets. Returns the merged
   *  verdict map so the export can annotate without waiting on React state. */
  const runVetPage = async (targetFieldIds: string[], force = false) => {
    if (!pid || !targetFieldIds.length) return {};
    const merged: Record<string, Record<string, { verdict: string; reason: string }>> = {};
    const CHUNK = 150;                       // keep a wide template off the gateway timeout
    for (let i = 0; i < targetFieldIds.length; i += CHUNK) {
      const slice = targetFieldIds.slice(i, i + CHUNK);
      try {
        const r = await MappingApi.vetCandidates(pid, { targetFieldIds: slice, force });
        for (const [fid, byCol] of Object.entries(r.ai || {})) {
          merged[fid] = { ...(merged[fid] || {}), ...(byCol as any) };
        }
      } catch { /* partial vetting is still useful — keep what we got */ }
    }
    if (Object.keys(merged).length) { mergeAiVerdicts(merged); setVettedOnce(true); }
    return merged;
  };

  const vetWithAiPage = async () => {
    if (!pid) return;
    setVettingPage(true);
    setVetMsgPage("Reviewing options with AI…");
    try {
      const ids = targetFields.filter((f) => visibleTargetIds.has(f.id)).map((f) => String(f.id));
      const m = await runVetPage(ids.length ? ids : targetFields.map((f) => String(f.id)), true);
      const n = Object.keys(m).length;
      setVetMsgPage(n ? `AI reviewed ${n} field(s) — reasons are shown.` : "Nothing uncertain enough to need AI review.");
    } finally { setVettingPage(false); }
  };

  const exportMappingPage = async () => {
    if (!pid) return;
    setExportingPage(true);
    try {
      // Ranked alternatives + any stored verdicts, fetched now so canvas exports
      // are as complete as table exports.
      let altBy: Record<string, any[]> = {};
      try {
        const groups = await MappingApi.candidates(pid, { topN: 4 });
        for (const g of groups) altBy[String(g.target_field_id)] = g.candidates || [];
      } catch { /* export still works from mappings alone */ }
      // Value crosswalks, so a canvas export carries the same columns as a table one.
      const cwBy: Record<string, { legacy: string; oracle: string; status: string }[]> = {};
      try {
        const coded = await MappingApi.codedValues(pid);
        (coded?.columns || []).forEach((c: any) => {
          const pairs = (c.resolved || [])
            .filter((rv: any) => String(rv.from) !== String(rv.to))
            .map((rv: any) => ({ legacy: String(rv.from), oracle: String(rv.to), status: rv.how || "" }));
          if (pairs.length) cwBy[(c.target_field || "").toLowerCase()] = pairs;
        });
      } catch { /* crosswalk column just stays empty */ }
      setVetMsgPage("AI-checking options for the export…");
      const verdicts = await runVetPage(targetFields.map((f) => String(f.id)), false);
      setVetMsgPage(null);

      const mByField = new Map(mappings.map((m) => [m.target_field_id, m]));
      const records = targetFields.map((f) => {
        const m = mByField.get(f.id);
        const alts = altBy[String(f.id)] || [];
        const dv = effectiveDefaults[(f.field_name || "").toLowerCase().replace(/\*/g, "").trim()];
        const approvedLike = ["approved", "overridden"].includes(m?.status || "");
        let suggested = "", confidence = 0;
        if (m?.source_column) {
          suggested = m.source_column;
          confidence = approvedLike ? 100 : Math.round((m.confidence ?? 0) * 100);
        } else if (dv) {
          suggested = `(constant) ${dv}`; confidence = 100;
        } else if (alts[0]) {
          suggested = alts[0].source_column || "";
          confidence = Math.round((alts[0].confidence ?? 0) * 100);
        }
        const fv = verdicts[String(f.id)] || {};
        return {
          target_field: f.field_name,
          suggested_source: suggested,
          confidence,
          reason: m?.reason || (suggested ? "" : "No confident match found"),
          excluded: /do-?not-?map|analyst rule/i.test(String(m?.reason || "")),
          required: !!(f as any).required,
          how_mapped: m?.source_column ? (approvedLike ? "Approved / learned" : "Suggested")
                    : dv ? "Default constant" : "Unmapped",
          transform: (m?.suggested_transformation as any)?.rule_type || "",
          status: m?.status ? String(m.status).replace(/_/g, " ") : "",
          needs_confirmation: m?.review_required ? "YES" : "",
          notes: m?.reason || "",
          crosswalks: cwBy[(f.field_name || "").toLowerCase()] || [],
          alternatives: alts.slice(0, 4).map((c: any) => {
            const v = fv[c.source_column];
            return {
              source: c.source_column,
              confidence: c.confidence,
              verdict: v?.verdict || c.ai_verdict || "",
              reason: v?.reason || c.ai_reason || (c.reasons || []).join("; "),
            };
          }),
        };
      });
      const obj = (project?.target_object || project?.name || "FBDI").trim();
      const title = `${obj} Field Mapping`;
      await OutputApi.mappingExport(pid, title,
        title.replace(/[^\w.-]+/g, "_") + ".xlsx", records);
    } catch (e: any) {
      window.alert(e?.response?.data?.detail || "Couldn't build the mapping workbook.");
    } finally { setExportingPage(false); setVetMsgPage(null); }
  };

  const loadAll = async () => {
    if (!pid) return;
    setLoadingConversion(true);
    setLoadError(null);
    setMappings([]);
    let proj: Conversion;
    try {
      proj = await ConversionsApi.get(pid);
    } catch (e: any) {
      // Most often a transient backend cold-start / redeploy. Don't strand the
      // user on an infinite spinner — surface it with a Retry.
      const code = e?.response?.status;
      setLoadError(
        code === 404
          ? "This conversion could not be found. It may have been removed, or the backend is still starting up."
          : `Couldn't load this conversion (${code || "network error"}). The backend may be waking up — retry in a moment.`
      );
      setLoadingConversion(false);
      return;
    }
    setProject(proj);
    if (proj.project_id != null) setEngagementId(String(proj.project_id));

    const isEbs = !proj.dataset_id;

    // A target FBDI template is required in both modes — without it there are
    // no fields to map against. Dataset mode additionally needs a linked file.
    if (!proj.template_id || (!isEbs && !proj.dataset_id)) {
      setDataset(null);
      setSourceColumns([]);
      setEbsTable(null);
      setEbsDebug(null);
      setRuleTargetIds(new Set());
      setTargetFields([]);
      setEffectiveDefaults({});
      setSuppressedFields(new Set());
      setLoadingConversion(false);
      return;
    }

    try {
      const [fields, ms, std, src] = await Promise.all([
        FbdiApi.fields(proj.template_id),
        MappingApi.list(pid),
        InheritedStandardsApi.forConversion(pid).catch(() => [] as InheritedStandard[]),
        ConversionsApi.sourceColumns(pid).catch(() => ({ source_type: "", table: null, columns: [] as DatasetColumnProfile[] })),
      ]);

      // Dataset detail still drives the Recommendations panel (column-level
      // cleansing). EBS mode has no file, so recommendations are skipped.
      let ds: DatasetDetail | null = null;
      if (!isEbs && proj.dataset_id) {
        ds = await DatasetsApi.get(proj.dataset_id).catch(() => null);
      }

      setDataset(ds);
      setSourceColumns(src.columns || []);
      setEbsTable(src.table ?? proj.ebs_table_hint ?? null);
      setEbsDebug((src as any).debug ?? null);
      setTargetFields(fields);
      setMappings(ms);
      setInherited(std);
      // Reference standard on file for this object (from the learning library).
      const objKey = (proj.target_object || "").trim().toLowerCase();
      if (objKey) {
        LearningApi.referenceStandards()
          .then((rows) => setRefStd(rows.find((r) => (r.business_object || "").trim().toLowerCase() === objKey) || null))
          .catch(() => setRefStd(null));
      } else {
        setRefStd(null);
      }
    } catch (e: any) {
      setLoadError(`Couldn't load mapping data (${e?.response?.status || "network error"}). Retry in a moment.`);
      setLoadingConversion(false);
      return;
    }
    setLoadingConversion(false);

    // Saved transformation rules → badge their target fields.
    MappingApi.rules(pid)
      .then((rs) => setRuleTargetIds(new Set(rs.filter((r) => r.target_field_id != null).map((r) => r.target_field_id as any))))
      .catch(() => setRuleTargetIds(new Set()));

    // Effective defaults (control constants + learned + AI-inferred) for unmapped
    // target fields → drives the "defaulted → value" badges. Fetched separately
    // so the optional AI inference pass never blocks the canvas render.
    ConversionsApi.effectiveDefaults(pid)
      .then((r) => {
        setEffectiveDefaults(r.defaults || {});
        setSuppressedFields(new Set(r.suppressed || []));
      })
      .catch(() => { setEffectiveDefaults({}); setSuppressedFields(new Set()); });
  };
  useEffect(() => { loadAll(); }, [pid]);

  // Load the FBDI file-set sequence for the current object (supplier → 7, …).
  useEffect(() => {
    const key = seqKeyForTarget(project?.target_object || project?.template_name);
    if (!key) { setSeqSteps([]); return; }
    let alive = true;
    ConversionsApi.objectTypes()
      .then((types) => { if (alive) setSeqSteps((types.find((t) => t.key === key)?.steps) || []); })
      .catch(() => { if (alive) setSeqSteps([]); });
    return () => { alive = false; };
  }, [project?.target_object, project?.template_name]);

  // Seed standard Oracle Fusion fields for templates with 0 parsed fields
  const [seeding, setSeeding] = useState(false);
  const seedFields = async () => {
    if (!project?.template_id) return;
    setSeeding(true);
    try {
      const res = await FbdiApi.seedStandardFields(project.template_id);
      flash(res.message);
      if (res.seeded > 0) {
        // Reload target fields then re-run mapping
        const fields = await FbdiApi.fields(project.template_id);
        setTargetFields(fields);
        await suggest();
      }
    } catch (err: any) {
      flash(err?.response?.data?.detail ?? "Seed failed — template name not recognised");
    } finally {
      setSeeding(false);
    }
  };

  // Run AI mapping
  const suggest = async () => {
    if (!pid) return;
    setRunning(true);
    try {
      const res = await MappingApi.suggest(pid);
      setMappings(res);
      const auto = res.filter((m) => m.approved_by === "learning-engine").length;
      const kb = res.filter((m) => !!m.kb_source && m.status === "suggested").length;
      const ai = res.filter(
        (m) => m.source_column && m.status === "suggested" && !m.kb_source,
      ).length;
      // Three-part breakdown so the analyst sees where each row came from.
      const parts: string[] = [];
      if (kb)   parts.push(`${kb} pre-filled from Knowledge Bank`);
      if (auto) parts.push(`${auto} auto-applied (same project)`);
      if (ai)   parts.push(`${ai} AI-suggested`);
      flash(parts.length ? `AI mapping run — ${parts.join(", ")}` : "AI mapping run complete");
    } finally { setRunning(false); }
  };

  const flash = (msg: string) => { setToast(msg); setTimeout(() => setToast(null), 2400); };

  // Remove gold-derived constant defaults (e.g. a wrong Country → AE that one gold
  // file baked in). This forgets the object-level rule so it can't reapply on
  // regenerate, then — because that's the natural next step — re-runs AI to re-fill
  // the freed fields. `fields` scopes it to one field; omit for all gold defaults.
  const resetGoldDefaults = async (fields?: string[], rerunAi = true) => {
    if (!pid) return;
    const scope = fields?.length ? `“${fields[0]}”` : "all gold-derived defaults for this object";
    if (!window.confirm(
      `Remove ${scope}?\n\nThis forgets the rule so it stops being applied to this and future ` +
      `conversions of this object${rerunAi ? ", then re-runs AI to re-fill the field(s)" : ""}. ` +
      `Control defaults (Import Action, batch id, running numbers) are not touched.`
    )) return;
    setRunning(true);
    try {
      const r = await ConversionsApi.resetDefaults(pid, {
        fields, forget_global: true, rerun_ai: rerunAi,
      });
      const bits = [`${r.defaults_cleared} default(s) cleared`, `${r.rules_forgotten} rule(s) forgotten`];
      if (r.remapped != null) bits.push("AI re-run");
      flash(bits.join(" · "));
      await loadAll();
    } catch (e: any) {
      // Surface the backend's actual reason instead of a generic message.
      const detail = e?.response?.data?.detail;
      flash(detail ? `Reset failed: ${detail}` : "Couldn't reset the defaults — try again.");
    } finally { setRunning(false); }
  };

  // Generate the FBDI output for this conversion and download it. Multi-sheet
  // objects come back as a .zip (one CSV per interface sheet); the artifact's
  // real file_name carries the correct extension.
  const [generating, setGenerating] = useState(false);
  // Header-row toggle for the generated file. Default is "auto": supplier FBDI
  // loads are headerless (data only), every other object keeps its header row.
  // The user can override per-download; null = follow the auto default.
  const isSupplierObj = /supplier/i.test(project?.target_object || project?.name || "");
  const [includeHeader, setIncludeHeader] = useState<boolean | null>(null);
  const headerOn = includeHeader ?? !isSupplierObj;
  const generateAndDownload = async () => {
    if (!pid) return;
    setGenerating(true);
    try {
      // Async generation: kick it off, poll until ready (nothing hits the gateway
      // timeout), then download. Heavy objects like the 19-sheet Customer build in
      // the background and can take a while — surface elapsed time so it's not silent.
      const fallback = `${(project?.target_object || project?.name || "fbdi").replace(/[^\w.-]+/g, "_")}.csv`;
      // Merge-by-interface: produce ONE merged file for this interface (all source
      // conversions in the project merged + de-duplicated). Works for a single
      // source too. Fall back to the plain (async) generate on any error.
      let out: any = null;
      try {
        out = await OutputApi.generateMergedAndWait(pid, headerOn, (sec) => {
          if (sec >= 3) setToast(`Merging + generating FBDI output… ${sec}s`);
        });
        await OutputApi.download(out.conversion_id || pid, out.file_name || fallback);
      } catch {
        out = await OutputApi.generateAndWait(pid, "csv", (sec) => {
          if (sec >= 3) setToast(`Generating FBDI output… ${sec}s`);
        }, headerOn);
        await OutputApi.download(pid, out.file_name || fallback);
      }
      const dq = out.dq_report;
      if (dq && (dq.error_count || dq.warning_count || dq.cleansing_fix_count)) {
        flash(`Downloaded. Data quality: ${dq.cleansing_fix_count} cleansing fix(es), ` +
          `${dq.error_count} error(s)` + (dq.hard_error_count ? ` (${dq.hard_error_count} hard)` : "") +
          `, ${dq.warning_count} warning(s).`);
      } else {
        flash("FBDI output generated and downloaded.");
      }
    } catch (e: any) {
      flash(e?.message || e?.response?.data?.detail || "Failed to generate output");
    } finally { setGenerating(false); }
  };

  // ── Filtering ──
  const fieldById = useMemo(() => {
    const m = new Map<string, FBDIField>();
    for (const f of targetFields) m.set(String(f.id), f);
    return m;
  }, [targetFields]);

  const visibleMappings = useMemo(() => {
    return mappings.filter((m) => {
      const term = search.toLowerCase();
      if (term && !((m.target_field_name || "") + " " + (m.source_column || ""))
            .toLowerCase().includes(term)) return false;
      // precedence-layer filter (from the "How each field is decided" bar)
      if (layerFilter) {
        const f = fieldById.get(String(m.target_field_id));
        if (!f) return false;
        const key = classifyLayer(m, f, effectiveDefaults,
          ruleTargetIds.has(m.target_field_id) || ruleTargetIds.has(String(m.target_field_id) as any),
          suppressedFields);
        if (key !== layerFilter) return false;
      }
      switch (filter) {
        case "required": return m.target_required;
        case "review":   return Boolean(m.review_required);
        case "approved": return m.status === "approved";
        case "unmapped": return !m.source_column && m.target_required;
        case "kb":       return !!m.kb_source;
        case "mapped":   return !!m.source_column;
        case "learned":  return m.status === "approved" &&
          (m.approved_by === "learning-engine" || (m.comment || "").includes("[learned]"));
        default: return true;
      }
    });
  }, [mappings, search, filter, layerFilter, fieldById, effectiveDefaults, ruleTargetIds, suppressedFields]);

  const visibleTargetIds = useMemo(() => new Set(visibleMappings.map((m) => m.target_field_id)), [visibleMappings]);

  // ── Stats — scoped to the active FBDI template's fields only ──
  const stats = useMemo(() => {
    const activeIds = new Set(targetFields.map((f) => f.id));
    const scoped = mappings.filter((m) => activeIds.has(m.target_field_id));
    const total = targetFields.length;
    const mapped = scoped.filter((m) => m.source_column).length;
    const approved = scoped.filter((m) => m.status === "approved").length;
    const nameById = new Map(targetFields.map((f) => [f.id, f.field_name]));
    // A required field is only a genuine gap when it has neither a source column
    // nor any default (learned default_value, static control constant, sequence
    // key, or an AI-inferred/effective default). Defaulted fields are handled at
    // Generate Output, so they must not inflate the "required gaps" count.
    const reqMissing = scoped.filter((m) => {
      if (!m.target_required || m.source_column || m.status === "approved") return false;
      if (m.default_value) return false;
      const fname = nameById.get(m.target_field_id);
      if (suppressedFields.has(normFieldKey(fname))) return false;
      if (effectiveDefaults[normFieldKey(fname)]) return false;
      return true;
    }).length;
    const learned = scoped.filter(
      (m) => m.status === "approved" &&
        (m.approved_by === "learning-engine" || m.comment?.includes("[learned]"))
    ).length;
    const kb = scoped.filter((m) => !!m.kb_source).length;
    return { total, mapped, approved, reqMissing, learned, kb };
  }, [mappings, targetFields, effectiveDefaults, suppressedFields]);

  // ── Recommendations (column-level cleansing tied to this project) ──
  const recommendations = useMemo<Recommendation[]>(() => {
    if (!dataset) return [];
    return buildRecommendations({ dataset, targetFields });
  }, [dataset, targetFields]);

  const selectedMapping = mappings.find((m) => m.id === selectedMappingId) || null;

  // Every approve teaches — backend persists a LearnedMapping so the next
  // file dropped on the same business object auto-corrects without asking.
  const approve = async (m: MappingSuggestion) => {
    await MappingApi.update(m.id, { status: "approved" });
    flash("Approved & learned — will auto-apply next time");
    loadAll();
  };

  const reject = async (m: MappingSuggestion) => {
    await MappingApi.update(m.id, { status: "rejected" });
    flash("Rejected");
    loadAll();
  };

  const override = async (m: MappingSuggestion, newSourceColumn: string) => {
    await MappingApi.update(m.id, { source_column: newSourceColumn, status: "overridden" });
    flash("Override saved");
    loadAll();
  };

  // Set a FIXED value on a field — a constant the user types (e.g. Tax Org Type =
  // CORPORATION, Supplier Type = SUPPLIER, Business Relationship = SPEND_AUTHORIZED,
  // Country = US). It's written to every row, clears any source mapping, and is
  // marked "overridden" so gold/AI/learnings never overwrite it. Passing an empty
  // value clears the fixed value and frees the field to be mapped/AI'd again.
  const setFixedValue = async (m: MappingSuggestion, value: string) => {
    const v = value.trim();
    await MappingApi.update(m.id, {
      source_column: null as any,
      default_value: v || (null as any),
      suggested_transformation: null as any,
      status: v ? "overridden" : "suggested",
      comment: v ? `Fixed value set by user: ${v}` : "Fixed value cleared",
    });
    flash(v ? `Fixed value set: “${v}”` : "Fixed value cleared");
    loadAll();
  };

  // "Keep blank" — the decision that this column ships empty. Distinct from
  // clearing a fixed value: clearing leaves the field open, so a control default
  // or the AI can refill it (this is exactly why Batch ID kept shipping 900001
  // after an analyst had "blanked" it). The endpoint suppresses the field, writes
  // a suppress_field learning so every current and future conversion inherits the
  // decision, and marks the built outputs stale.
  const keepBlank = async (m: MappingSuggestion) => {
    try {
      const r = await MappingApi.keepBlank(m.id);
      flash(
        `${m.target_field_name || "Field"} will ship blank` +
        (r?.learned_suppression ? " — saved to learning for all conversions" : ""),
      );
      loadAll();
    } catch (e: any) {
      flash(`Could not keep blank: ${e?.response?.data?.detail || e?.message || "failed"}`);
    }
  };

  // Drag-to-map: dropping a source column onto a target field binds it. We
  // update that target's existing suggestion row (created by AI mapping) and
  // mark it "overridden" so it reads as a deliberate manual mapping.
  const mapDrop = async (targetFieldId: number, sourceColumn: string) => {
    const m = mappings.find((x) => x.target_field_id === targetFieldId);
    if (!m) {
      flash("Run AI Mapping first so the field is ready to map");
      return;
    }
    if (m.source_column === sourceColumn) return;
    try {
      await MappingApi.update(m.id, { source_column: sourceColumn, status: "overridden" });
      flash(`Mapped ${sourceColumn} → ${m.target_field_name || "field"}`);
      loadAll();
    } catch (e: any) {
      flash(`Could not map: ${e?.response?.data?.detail || e?.message || "failed"}`);
    }
  };

  // Delete a mapping arrow — clears the source binding and returns the row to
  // an unmapped "suggested" state (the field can then be re-mapped by drag).
  const unmap = async (m: MappingSuggestion) => {
    try {
      await MappingApi.update(m.id, { source_column: null as any, status: "suggested" });
      flash(`Cleared mapping for ${m.target_field_name || "field"}`);
      loadAll();
    } catch (e: any) {
      flash(`Could not clear: ${e?.response?.data?.detail || e?.message || "failed"}`);
    }
  };

  // ── Apply & (optionally) Learn a recommendation ──
  const applyRecommendation = async (rec: Recommendation, learn: boolean) => {
    if (!pid || !rec.ruleType) {
      flash("No transformation rule available for this recommendation");
      return;
    }

    try {
      // 1. Add transformation rule to this conversion
      await MappingApi.addRule(pid, {
        source_column: rec.column,
        rule_type: rec.ruleType,
        rule_config: rec.ruleConfig ?? {},
        description: rec.title,
        ...(rec.targetField
          ? { target_field_id: targetFields.find((f) => f.field_name === rec.targetField)?.id?.toString() }
          : {}),
      });

      // 2. Approve the mapping for this source column (if one exists)
      const matchingMapping = mappings.find((m) => m.source_column === rec.column);
      if (matchingMapping && matchingMapping.status !== "approved") {
        await MappingApi.update(matchingMapping.id, { status: "approved" });
      }

      // 3. On "Apply & Learn" — capture to Learning Center + propagate to all other conversions
      if (learn) {
        // Capture to Learning Center (Rule Library)
        await LearningApi.capture({
          kind: "transformation_rule",
          category: rec.kind,
          original_value: rec.column,
          resolved_value: rec.ruleType,
          rule_type: rec.ruleType,
          rule_config: rec.ruleConfig ?? {},
          target_field: rec.targetField,
          captured_from: rec.title,
          project_id: pid,
          records_auto_fixed: rec.impact.records,
        });

        // Propagate rule to all other conversions that have the same source column
        const allConversions = await ConversionsApi.list();
        const others = allConversions.filter((c) => c.id !== pid);
        await Promise.allSettled(
          others.map(async (conv) => {
            const theirMappings = await MappingApi.list(conv.id);
            const hasColumn = theirMappings.some((m) => m.source_column === rec.column);
            if (!hasColumn) return;
            await MappingApi.addRule(conv.id, {
              source_column: rec.column,
              rule_type: rec.ruleType!,
              rule_config: rec.ruleConfig ?? {},
              description: `[learned] ${rec.title}`,
            });
            const theirMapping = theirMappings.find((m) => m.source_column === rec.column);
            if (theirMapping && theirMapping.status !== "approved") {
              await MappingApi.update(theirMapping.id, { status: "approved" });
            }
          })
        );

        setLearnedRecIds((prev) => new Set([...prev, rec.id]));
        flash(`Applied & learned — rule propagated to all conversions with ${rec.column}`);
      } else {
        setAppliedRecIds((prev) => new Set([...prev, rec.id]));
        flash(`Applied — ${rec.title}`);
      }

      // Dismiss the card from the list after a brief "Applied" display
      setTimeout(() => {
        setDismissedRecIds((prev) => new Set([...prev, rec.id]));
      }, 1500);

      // Refresh mappings so the canvas reflects the approve
      loadAll();
    } catch (err) {
      flash("Failed to apply recommendation");
      console.error(err);
    }
  };

  // ── Landing: project-wise conversion list (no conversion selected) ──────────
  if (!pid) {
    if (loadingList) return <PageLoader />;
    if (loadError) return (
      <div className="p-6">
        <EmptyState
          icon={<AlertTriangle className="h-5 w-5" />}
          title="Couldn't load mapping review"
          description={loadError}
        />
        <div className="mt-3 flex justify-center">
          <Button variant="primary" onClick={() => window.location.reload()}>
            <RefreshCw className="h-4 w-4" /> Retry
          </Button>
        </div>
      </div>
    );

    const scoped = projects.filter(
      (c) => !engagementId || String(c.project_id) === engagementId
    );
    const tone = (s?: string) => statusTone(s || "draft");

    return (
      <div className="space-y-4 p-6">
        <PageTitle
          title="Mapping Review"
          subtitle="Pick an engagement to review the mapping status of its conversions, then open one to map fields."
        />

        <div className="flex flex-wrap items-center gap-3">
          <ArrowLeftRight className="h-4 w-4 text-brand" />
          <label className="text-xs font-medium text-ink-muted">Engagement</label>
          <select
            className="input !h-9 !w-auto"
            value={engagementId ?? ""}
            onChange={(e) => setEngagementId(e.target.value || null)}
          >
            <option value="" disabled>— select engagement —</option>
            {engagements.map((eng) => (
              <option key={eng.id} value={eng.id}>{eng.name}</option>
            ))}
          </select>
          <span className="text-xs text-ink-subtle">
            {scoped.length} conversion{scoped.length === 1 ? "" : "s"}
          </span>
        </div>

        {!engagementId ? (
          <EmptyState
            icon={<ArrowLeftRight className="h-5 w-5" />}
            title="Select an engagement"
            description="Choose a project from the dropdown to see its conversions and mapping status."
          />
        ) : scoped.length === 0 ? (
          <EmptyState
            icon={<ArrowLeftRight className="h-5 w-5" />}
            title="No conversions in this engagement"
            description="This project has no conversion objects yet."
          />
        ) : (
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
            {scoped.map((c) => {
              const src = (c as any).ebs_table_hint || (c as any).dataset_name;
              const hasTpl = !!c.template_id;
              return (
                <button
                  key={c.id}
                  onClick={() => { setPid(c.id); setParams({ conversion: String(c.id) }); }}
                  className="group flex flex-col gap-2 rounded-lg border border-line bg-white p-4 text-left transition hover:border-brand hover:shadow-sm"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-semibold text-ink">{c.name}</div>
                      {c.target_object && (
                        <div className="truncate text-[11px] text-ink-subtle">{c.target_object}</div>
                      )}
                    </div>
                    <Pill tone={tone(c.status)}>{c.status}</Pill>
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] text-ink-muted">
                    {src ? (
                      <span className="inline-flex items-center gap-1">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                        <span className="font-mono text-emerald-800">{src}</span>
                      </span>
                    ) : (
                      <span className="text-ink-subtle">No source linked</span>
                    )}
                    <span className="mx-0.5">→</span>
                    <span className={cn(hasTpl ? "text-ink" : "text-danger")}>
                      {c.template_name || "No FBDI template"}
                    </span>
                  </div>
                  <div className="mt-1 text-[11px] font-medium text-brand opacity-0 transition group-hover:opacity-100">
                    Open mapping →
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  // ── Canvas: a single conversion's field mapping ────────────────────────────
  if (loadingConversion) return <PageLoader />;
  if (loadError) return (
    <div className="p-6">
      <EmptyState
        icon={<AlertTriangle className="h-5 w-5" />}
        title="Couldn't load this conversion"
        description={loadError}
      />
      <div className="mt-3 flex justify-center">
        <Button variant="primary" onClick={() => (pid ? loadAll() : window.location.reload())}>
          <RefreshCw className="h-4 w-4" /> Retry
        </Button>
      </div>
    </div>
  );
  if (!project) return <PageLoader />;

  const isEbs = !project.dataset_id;

  // No target template → nothing to map against, in either mode.
  if (!project.template_id) return (
    <div className="p-6">
      <EmptyState
        icon={<ArrowLeftRight className="h-5 w-5" />}
        title="No FBDI template linked"
        description="Link a target FBDI template to this conversion to begin mapping."
      />
    </div>
  );
  // Dataset mode with no uploaded file → prompt for a source extract.
  if (!isEbs && !dataset) return (
    <div className="p-6">
      <EmptyState
        icon={<ArrowLeftRight className="h-5 w-5" />}
        title="No source file linked yet"
        description="Upload a source extract and link it to this conversion to begin mapping."
      />
    </div>
  );

  return (
    <div className="-m-6 flex h-[calc(100vh-3.5rem)] flex-col bg-canvas">
      {/* Top bar */}
      <header className="border-b border-line bg-white px-5 py-3">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              // Return to this engagement's mapping list (clear the open
              // conversion but keep the engagement context so the right
              // project's cards show). Fixes the broken back flow (Req 9).
              setSelectedMappingId(null);
              setPid(null);
              setProject(null);
              const eid = engagementId || (project ? String(project.project_id) : "");
              setParams(eid ? { engagement: eid } : {});
            }}
            className="btn-ghost !h-8 shrink-0"
            title="Back to this engagement's mapping list"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span className="ml-1 text-xs">Mapping list</span>
          </button>
          {project?.project_id != null && (
            <button
              onClick={() => nav(`/projects/${project.project_id}`)}
              className="btn-ghost !h-8 shrink-0"
              title="Back to the engagement overview"
            >
              <span className="text-xs">Project</span>
            </button>
          )}
          <ArrowLeftRight className="h-4 w-4 text-brand" />
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold text-ink">Mapping Review</div>
            <div className="text-[11px] text-ink-muted">
              {isEbs ? (
                <span className="inline-flex items-center gap-1 text-emerald-700">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="font-mono text-emerald-800">{ebsTable || "Oracle EBS"}</span>
                  <span className="text-emerald-600">· live</span>
                </span>
              ) : (
                <span className="text-ink">{dataset?.name}</span>
              )}
              <span className="mx-1.5">→</span>
              <span className="text-ink">{project.template_name}</span>
              <span className="ml-1.5 font-mono text-ink-subtle">· {targetFields.length} target fields</span>
            </div>
          </div>

          {/* Engagement (project) selector — scopes the conversion list below. */}
          <select
            className="input !h-8 !w-auto !text-xs"
            value={engagementId ?? ""}
            onChange={(e) => {
              const eid = e.target.value;
              setEngagementId(eid);
              // Jump to that engagement's first conversion.
              const first = projects.find((c) => String(c.project_id) === eid);
              if (first) { setPid(first.id); setParams({ conversion: String(first.id) }); }
            }}
            title="Engagement"
          >
            <option value="" disabled>— engagement —</option>
            {engagements.map((eng) => <option key={eng.id} value={eng.id}>{eng.name}</option>)}
          </select>
          {/* FBDI-file (target template) selector — Req 6: switch which of the
              engagement's generated FBDI files you're reviewing. */}
          <select
            className="input !h-8 !w-auto !text-xs"
            value={pid ?? ""}
            onChange={(e) => { const v = e.target.value; setPid(v); setParams({ conversion: v }); }}
            title="FBDI file — switch between the templates generated for this engagement"
          >
            {projects
              .filter((c) => !engagementId || String(c.project_id) === engagementId)
              .map((p) => (
                <option key={p.id} value={p.id}>
                  {(p as any).template_name || p.target_object || p.name}
                </option>
              ))}
          </select>

          <button
            onClick={() => setShowRecs(!showRecs)}
            className={cn("btn-ghost !h-8", showRecs && "bg-brand-subtle text-brand-dark")}
            title="Toggle recommendations panel"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span className="ml-1 text-xs">Recommendations</span>
          </button>

          <button
            onClick={() => resetGoldDefaults()}
            className="btn-ghost !h-8"
            title="Remove constant defaults that a gold file baked in (e.g. a wrong Country → AE), then re-run AI to re-fill them. Control defaults are kept."
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span className="ml-1 text-xs">Reset gold defaults</span>
          </button>

          <Button
            onClick={() => setCompositeOpen(true)}
            variant="secondary"
            className="!h-8"
            disabled={!pid || targetFields.length === 0}
            title="Split one source column into several fields (e.g. phone → country/area/number), or combine several source columns into one"
          >
            <ArrowLeftRight className="h-3.5 w-3.5" />
            <span className="ml-1 text-xs">Split / combine</span>
          </Button>

          <Button onClick={suggest} loading={running} variant="primary" className="!h-8">
            <Sparkles className="h-3.5 w-3.5" />
            {mappings.length ? "Re-run AI" : "Run AI Mapping"}
          </Button>

          <button
            type="button"
            onClick={() => setIncludeHeader(!headerOn)}
            role="switch"
            aria-checked={headerOn}
            title={headerOn
              ? "Header row INCLUDED — the output's first row is the column names. Click to exclude (Oracle FBDI load files are headerless)."
              : "Header row EXCLUDED — data rows only (Oracle FBDI load format). Click to include column names as the first row."}
            className={cn("btn-ghost !h-8", headerOn && "bg-brand-subtle text-brand-dark")}
          >
            <Table2 className="h-3.5 w-3.5" />
            <span className="ml-1 text-xs">Header: {headerOn ? "on" : "off"}</span>
          </button>

          <Button
            onClick={generateAndDownload}
            loading={generating}
            variant="secondary"
            className="!h-8"
            disabled={!mappings.some((m) => m.source_column)}
            title="Generate this object's FBDI file and download it"
          >
            <Download className="h-3.5 w-3.5" />
            <span className="ml-1 text-xs">Generate &amp; download</span>
          </Button>
        </div>

        {/* Zero-fields warning — template parsed with no columns */}
        {targetFields.length === 0 && (
          <div className="mt-3 flex items-center gap-2 rounded-md border border-warning/40 bg-warning-subtle px-3 py-2 text-xs text-warning-dark">
            <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
            <span className="flex-1">
              This FBDI template has <strong>0 target fields</strong> — the Excel file may not have parsed correctly when uploaded.
              Click <strong>Seed Standard Fields</strong> to inject Oracle Fusion standard columns, then re-run mapping.
            </span>
            <button
              onClick={seedFields}
              disabled={seeding}
              className="flex items-center gap-1 rounded border border-warning/50 bg-white px-2 py-1 font-medium hover:bg-warning-subtle disabled:opacity-50"
            >
              {seeding ? <Spinner className="h-3 w-3" /> : <RefreshCw className="h-3 w-3" />}
              Seed Standard Fields
            </button>
          </div>
        )}

        {/* Stats + filters — each KPI filters the list (canvas + table) */}
        <div className="mt-3 flex items-center gap-3">
          <Stat label="Target fields"  value={stats.total}                       onClick={() => { setFilter("all"); setLayerFilter(null); }}      active={filter === "all" && !layerFilter} />
          <Stat label="Auto-mapped"    value={stats.mapped}    tone="info"       onClick={() => { setFilter("mapped"); setLayerFilter(null); }}   active={filter === "mapped"} />
          <Stat label="Approved"       value={stats.approved}  tone="success"    onClick={() => { setFilter("approved"); setLayerFilter(null); }} active={filter === "approved"} />
          <Stat label="Required gaps"  value={stats.reqMissing} tone="danger"    onClick={() => { setFilter("unmapped"); setLayerFilter(null); }} active={filter === "unmapped"} />
          <Stat label="Learned"        value={stats.learned}   tone="brand"      onClick={() => { setFilter("learned"); setLayerFilter(null); }}  active={filter === "learned"} />
          <Stat label="From KB"        value={stats.kb}        tone="brand"      onClick={() => { setFilter("kb"); setLayerFilter(null); }}       active={filter === "kb"} />

          <div className="flex-1" />

          {/* Available in BOTH canvas and table (the table also has its own copy) */}
          <button
            onClick={fillBlanksPage}
            disabled={fillingPage}
            title="Ask AI to suggest a source only for fields still unmapped. Lands in Needs review — nothing is applied blindly."
            className="inline-flex items-center gap-1.5 rounded-md border border-brand/40 bg-brand-subtle px-2.5 py-1 text-[11px] font-semibold text-brand hover:bg-brand/10 disabled:opacity-50"
          >
            {fillingPage ? <Spinner /> : <Sparkles className="h-3 w-3" />}
            {fillingPage ? "Filling…" : (filter === "unmapped" || filter === "required") ? "Fill required blanks with AI" : "Fill blanks with AI"}
          </button>

          {/* Vet + Export in CANVAS. The table view has its own pair in its toolbar,
              built from the row models it already holds; these fetch the same data on
              click so canvas is not a second-class view. Rendered only for canvas so
              the two never appear at once. */}
          {viewMode !== "table" && (
          <>
          {vetMsgPage && <span className="max-w-[220px] truncate text-[10px] text-ink-subtle" title={vetMsgPage}>{vetMsgPage}</span>}
          <button
            onClick={vetWithAiPage}
            disabled={vettingPage}
            title="Ask AI to judge the uncertain alternatives and explain why each does or doesn't fit. Adds reasons to the table and the Excel export."
            className={cn(
              "inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-[11px] font-semibold disabled:opacity-50",
              vettedOnce
                ? "border-success/40 bg-success-subtle text-success hover:bg-success/10"
                : "border-brand/40 bg-brand-subtle text-brand hover:bg-brand/10",
            )}
          >
            {vettingPage ? <Spinner /> : vettedOnce ? <Check className="h-3 w-3" /> : <Sparkles className="h-3 w-3" />}
            {vettingPage ? "Reviewing…" : vettedOnce ? "AI review done" : "Vet options with AI"}
          </button>
          <button
            onClick={exportMappingPage}
            disabled={exportingPage}
            title="Download the mapping as an Excel workbook — a flat All Fields sheet plus one sheet per confidence band"
            className="inline-flex items-center gap-1.5 rounded-md border border-line bg-white px-2.5 py-1 text-[11px] font-semibold text-ink hover:bg-canvas disabled:opacity-50"
          >
            <Download className={cn("h-3 w-3", exportingPage && "animate-pulse")} />
            {exportingPage ? "Building…" : "Export mapping (Excel)"}
          </button>
          </>
          )}

          {/* View toggle — canvas graph vs tabular field-mapping detail */}
          <div className="flex items-center rounded-md border border-line bg-white p-0.5">
            {([
              { v: "canvas", label: "Canvas", Icon: GitBranch },
              { v: "table",  label: "Table",  Icon: Table2 },
            ] as const).map((o) => (
              <button
                key={o.v}
                onClick={() => setViewMode(o.v)}
                title={o.v === "table"
                  ? "Tabular view — source → target with required flag, how it was mapped, transform, confidence, and lower-probability alternatives"
                  : "Canvas view — drag source columns onto target fields"}
                className={cn("inline-flex items-center gap-1 rounded px-2 py-1 text-[11px] font-medium",
                  viewMode === o.v ? "bg-brand text-white" : "text-ink-muted hover:text-ink")}
              >
                <o.Icon className="h-3 w-3" /> {o.label}
              </button>
            ))}
          </div>

          <div className="flex items-center rounded-md border border-line bg-white p-0.5">
            {([
              { v: "all",      label: "All" },
              { v: "required", label: "Required" },
              { v: "review",   label: "Needs review" },
              { v: "approved", label: "Approved" },
              { v: "unmapped", label: "Required gaps" },
              { v: "kb",       label: "From KB" },
            ] as const).map((f) => (
              <button
                key={f.v}
                onClick={() => setFilter(f.v)}
                className={cn("rounded px-2 py-1 text-[11px] font-medium",
                  filter === f.v ? "bg-brand text-white" : "text-ink-muted hover:text-ink")}
              >
                {f.label}
              </button>
            ))}
          </div>
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-subtle" />
            <input className="input !h-8 !pl-8 !w-56 !text-xs" placeholder="Search field…"
              value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
        </div>
      </header>

      {/* FBDI load-sequence map — click a file to review its mappings (Req 2/6) */}
      {seqSteps.length > 1 && (
        <div className="border-b border-line bg-white px-5 py-2">
          <div className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-ink-muted">
            Load sequence · {seqSteps.length} FBDI files
          </div>
          <div className="flex flex-wrap items-center gap-1">
            {seqSteps.map((s, i) => {
              const sc = projects.find(
                (c) =>
                  (!engagementId || String(c.project_id) === engagementId) &&
                  ((c.target_object || "").toLowerCase() === s.label.toLowerCase() ||
                    (c.template_name || "").toLowerCase() === s.label.toLowerCase())
              );
              const isCurrent = !!sc && String(sc.id) === String(pid);
              return (
                <React.Fragment key={s.label}>
                  <button
                    disabled={!sc}
                    onClick={() => { if (sc) { setPid(String(sc.id)); setParams({ conversion: String(sc.id) }); } }}
                    title={sc ? "Show this FBDI file's mappings" : "Not generated yet"}
                    className={cn(
                      "rounded border px-2 py-1 text-[11px] transition",
                      isCurrent
                        ? "border-brand bg-brand-subtle font-semibold text-brand-dark"
                        : sc
                        ? "border-line bg-white text-ink hover:border-brand"
                        : "cursor-default border-dashed border-line bg-canvas text-ink-subtle"
                    )}
                  >
                    <span className="font-mono text-ink-subtle">{s.load_order}.</span> {s.label}
                  </button>
                  {i < seqSteps.length - 1 && <span className="text-ink-subtle">→</span>}
                </React.Fragment>
              );
            })}
          </div>
        </div>
      )}

      {pid && (
        <LearnFromExamplePanel conversionId={String(pid)} onApplied={loadAll} />
      )}

      {pid && refStd && (
        <div className="border-b border-line bg-brand-subtle/15 px-5 py-2 text-[12px]">
          <div className="flex items-start gap-2">
            <span className="mt-0.5 inline-flex h-4 w-4 items-center justify-center rounded-full bg-brand text-[10px] font-bold text-white">✓</span>
            <div>
              <div className="font-semibold text-ink">
                Gold reference standard on file for {refStd.business_object} — auto-applied
              </div>
              <div className="mt-0.5 leading-snug text-ink-muted">
                Stored from a previously uploaded gold output: {refStd.column_mappings} mapped column{refStd.column_mappings === 1 ? "" : "s"},
                {" "}{refStd.defaults} constant default{refStd.defaults === 1 ? "" : "s"}, {refStd.suppressions} suppressed field{refStd.suppressions === 1 ? "" : "s"}.
                No need to re-upload — uploading a new gold file above overrides it for this object.
              </div>
            </div>
          </div>
        </div>
      )}

      {inherited.length > 0 && (
        <div className="border-b border-line bg-gradient-to-r from-brand-subtle/40 to-white px-5 py-2.5 text-[12px]">
          <div className="flex items-start gap-2">
            <span className="mt-0.5 inline-flex h-4 w-4 items-center justify-center rounded-full bg-brand text-[10px] font-bold text-white">↶</span>
            <div>
              <div className="font-semibold text-ink">
                {inherited.length} reference standard{inherited.length === 1 ? "" : "s"} inherited from upstream masters
              </div>
              <div className="mt-0.5 leading-snug text-ink-muted">
                The following column{inherited.length === 1 ? " is" : "s are"} auto-prepending master-taught rules at output time —
                no need to re-author. Override here to opt out per column.
              </div>
              <div className="mt-1.5 flex flex-wrap gap-1">
                {inherited.map((s, i) => (
                  <span
                    key={`${s.target_field}-${s.master_object}-${s.rule_type}-${i}`}
                    className="inline-flex items-center gap-1 rounded-md border border-brand/30 bg-white px-2 py-0.5 font-mono text-[10.5px] text-brand-dark"
                    title={s.captured_from}
                  >
                    {s.target_field} · {s.rule_type}
                    <span className="ml-1 text-[9px] uppercase text-ink-muted">from {s.master_object}</span>
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* EBS live mode but no columns came back — connection unreachable or
          the conversion has no table hint. Keep the page usable. */}
      {isEbs && sourceColumns.length === 0 && (
        <div className="border-b border-line bg-warning-subtle px-5 py-2.5 text-[12px] text-warning-dark">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
            <span>
              No live columns returned from Oracle EBS
              {ebsTable ? <> for <span className="font-mono">{ebsTable}</span></> : " (no table hint set)"}.
              {ebsDebug?.stage === "no_connection" && " No Oracle EBS connection is configured — add one under Source Connections."}
              {ebsDebug?.stage === "error" && <> Connection error: <span className="font-mono">{String(ebsDebug.error)}</span>.</>}
              {ebsDebug?.stage === "no_columns" && <> Connected as <span className="font-mono">{String(ebsDebug.username)}</span> but the table was not found in ALL_TAB_COLUMNS.</>}
              {!ebsDebug?.stage && " Confirm the EBS connection is healthy and the table hint is set, then re-run AI Mapping."}
            </span>
          </div>
          {ebsDebug && (
            <div className="mt-1 font-mono text-[10.5px] text-warning-dark/70">
              diag: {JSON.stringify(ebsDebug)}
            </div>
          )}
        </div>
      )}

      {/* Coded (LOV) columns — what Oracle will accept, checked before generating */}
      {pid && (
        <div className="px-5 pt-4">
          <CodedValuesPanel conversionId={String(pid)} />
        </div>
      )}

      {/* How each field is decided — the layered pipeline, shown for both views */}
      <PrecedenceBar
        mappings={mappings}
        targetFields={targetFields}
        visibleTargetIds={visibleTargetIds}
        ruleTargetIds={ruleTargetIds}
        effectiveDefaults={effectiveDefaults}
        suppressedFields={suppressedFields}
        activeLayer={layerFilter}
        onSelectLayer={(k) => { setLayerFilter(k); if (k) setFilter("all"); }}
      />

      {/* Body */}
      <div className="flex flex-1 overflow-hidden">
        {viewMode === "table" ? (
          <MappingTableView
            conversionId={pid ?? ""}
            sourceColumns={sourceColumns}
            targetFields={targetFields}
            mappings={mappings}
            visibleTargetIds={visibleTargetIds}
            effectiveDefaults={effectiveDefaults}
            suppressedFields={suppressedFields}
            ruleTargetIds={ruleTargetIds}
            selectedMappingId={selectedMappingId}
            setSelectedMappingId={setSelectedMappingId}
            onOverride={(m, src) => override(m, src)}
            loading={running}
            aiVerdicts={aiVerdicts}
            onAiVerdicts={mergeAiVerdicts}
            onReload={loadAll}
            objectName={project?.target_object || project?.name || undefined}
            sourceName={(project as any)?.dataset_name || (project as any)?.ebs_table_hint || undefined}
          />
        ) : (
        /* Mapping canvas */
        <MappingCanvas
          sourceColumns={sourceColumns}
          targetFields={targetFields}
          mappings={mappings}
          visibleTargetIds={visibleTargetIds}
          selectedMappingId={selectedMappingId}
          setSelectedMappingId={setSelectedMappingId}
          hoveredSource={hoveredSource}
          setHoveredSource={setHoveredSource}
          hoveredTarget={hoveredTarget}
          setHoveredTarget={setHoveredTarget}
          ruleTargetIds={ruleTargetIds}
          effectiveDefaults={effectiveDefaults}
          suppressedFields={suppressedFields}
          onMapDrop={mapDrop}
          onUnmap={unmap}
          loading={running}
        />
        )}

        {/* Selected mapping inspector */}
        {selectedMapping && (
          <MappingInspector
            mapping={selectedMapping}
            sourceColumns={sourceColumns}
            conversionId={pid ?? ""}
            targetObject={project?.target_object}
            onClose={() => setSelectedMappingId(null)}
            onApprove={(m) => approve(m)}
            onReject={(m) => reject(m)}
            onOverride={(m, newSrc) => override(m, newSrc)}
            onAddCustomRule={(m) => { setRuleAuthorMapping(m); setRuleAuthorOpen(true); }}
            onResetDefault={(fn) => resetGoldDefaults([fn], false)}
            onSetFixedValue={(m, v) => setFixedValue(m, v)}
            onKeepBlank={(m) => keepBlank(m)}
            aiVerdicts={aiVerdicts}
            onAiVerdicts={mergeAiVerdicts}
          />
        )}

        {/* Recommendations panel */}
        {showRecs && (
          <RecommendationsPanel
            recommendations={recommendations.filter(r => !dismissedRecIds.has(r.id))}
            appliedIds={appliedRecIds}
            learnedIds={learnedRecIds}
            onApply={applyRecommendation}
            onDismiss={(rec) => {
              setAppliedRecIds((prev) => new Set([...prev, rec.id]));
              setTimeout(() => setDismissedRecIds((prev) => new Set([...prev, rec.id])), 1500);
            }}
            className="w-[340px]"
          />
        )}
      </div>

      {toast && (
        <div className="pointer-events-none fixed bottom-6 right-6 rounded-md bg-ink px-4 py-2 text-xs text-white shadow-soft">
          {toast}
        </div>
      )}

      {pid && sourceColumns.length > 0 && (
        <RuleAuthorModal
          open={ruleAuthorOpen}
          onClose={() => setRuleAuthorOpen(false)}
          conversionId={pid}
          fields={targetFields}
          sourceColumns={sourceColumns}
          defaultTargetFieldId={ruleAuthorMapping?.target_field_id ?? null}
          defaultSourceColumn={ruleAuthorMapping?.source_column ?? null}
          mappingIdForField={(tfid) =>
            mappings.find((m) => String(m.target_field_id) === String(tfid))?.id != null
              ? String(mappings.find((m) => String(m.target_field_id) === String(tfid))!.id)
              : undefined}
          /* RELOAD. This closed the modal and flashed a message without refetching
             anything, so the grid and the inspector kept showing their in-memory copy
             — SOURCE "(none)", "Required field with no source and no default" — for a
             field the rule had just bound to a column. Saving a rule now also writes
             that binding onto the mapping row server-side; this is the half that makes
             the screen show it without a manual page reload. Both halves are the same
             report: "the change in transformation rule is not reflecting in the
             mapping section." */
          onSaved={async () => {
            setRuleAuthorOpen(false);
            flash("Rule saved & added to library");
            await loadAll();
          }}
        />
      )}

      {pid && (
        <CompositeMappingModal
          open={compositeOpen}
          conversionId={pid}
          sourceColumns={sourceColumns}
          targetFields={targetFields}
          mappings={mappings}
          onClose={() => setCompositeOpen(false)}
          onDone={async (msg) => { setCompositeOpen(false); flash(msg); await loadAll(); }}
        />
      )}
    </div>
  );
};

// ─── Split / combine columns ─────────────────────────────────────────────────
// One source column → several target fields (phone → country/area/extension/
// number, or a delimited value → parts), or several source columns → one target
// (CONCAT). Wires the mapping + its transform via the existing MappingApi so it
// flows straight into Generate.
/** Modules a plain-English rule can be learned for. Mirrors
 *  rule_authoring_service.KNOWN_OBJECTS — the backend rejects anything else, so
 *  a drift here shows up as "not a known module, skipped" rather than silently. */
const RULE_MODULES = ["Supplier", "Customer", "Item", "BOM", "Employee",
  "Subinventory", "Locator", "Price List", "Lot Number", "Serial Number"] as const;

interface AuthoredRule {
  written: number;
  objects: string[];
  unknown?: string[];
  translated?: {
    rule_type?: string; explanation?: string; ambiguities?: string[];
  } | null;
}

const CompositeMappingModal: React.FC<{
  open: boolean;
  conversionId: number;
  sourceColumns: DatasetColumnProfile[];
  targetFields: FBDIField[];
  mappings: MappingSuggestion[];
  onClose: () => void;
  onDone: (msg: string) => void | Promise<void>;
}> = ({ open, conversionId, sourceColumns, targetFields, mappings, onClose, onDone }) => {
  const [mode, setMode] = useState<"split" | "combine" | "describe">("split");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  // describe — one sentence, learned for every module the analyst names, so a
  // convention stated once for Item also governs BOM instead of being retyped.
  const [ruleText, setRuleText] = useState("");
  // Several destinations from one sentence — see the picker below.
  const [ruleTargets, setRuleTargets] = useState<string[]>([]);
  const [ruleTargetFilter, setRuleTargetFilter] = useState("");
  const [ruleObjects, setRuleObjects] = useState<string[]>([]);
  const [ruleResult, setRuleResult] = useState<AuthoredRule | null>(null);

  // split
  const [srcCol, setSrcCol] = useState("");
  const [preset, setPreset] = useState<"phone" | "delimiter">("phone");
  const [phoneParts, setPhoneParts] = useState<Record<string, string>>({}); // part -> target field id
  const [sep, setSep] = useState("-");
  const [splitRows, setSplitRows] = useState<{ fieldId: string; index: number }[]>([]);
  // A Customer template carries 1,365 fields, so the tick-list needs a filter to
  // be usable at all — without one the analyst scrolls for the four they want.
  const [splitFilter, setSplitFilter] = useState("");

  // combine
  const [combineTarget, setCombineTarget] = useState("");
  const [combineCols, setCombineCols] = useState<string[]>([]);
  const [combineSep, setCombineSep] = useState(" ");

  React.useEffect(() => {
    if (open) {
      setMode("split"); setErr(null); setSrcCol(""); setPreset("phone");
      setRuleText(""); setRuleTargets([]); setRuleTargetFilter("");
      setRuleObjects([]); setRuleResult(null);
      setPhoneParts({}); setSep("-"); setSplitRows([]); setSplitFilter("");
      setCombineTarget(""); setCombineCols([]); setCombineSep(" ");
    }
  }, [open]);

  const colName = (c: DatasetColumnProfile) => (c as any).column_name ?? (c as any).name ?? "";
  const mapByField = new Map(mappings.map((m) => [String(m.target_field_id), m]));

  const applyOne = async (fieldId: string, sourceColumn: string, rule_type: string, config: any) => {
    const existing = mapByField.get(String(fieldId));
    if (existing) {
      await MappingApi.update(String(existing.id), {
        source_column: sourceColumn, status: "overridden",
        suggested_transformation: { rule_type, config } as any,
      });
    } else {
      await MappingApi.addRule(String(conversionId), {
        target_field_id: fieldId, source_column: sourceColumn, rule_type, rule_config: config,
      });
    }
  };

  const submit = async () => {
    setBusy(true); setErr(null);
    try {
      if (mode === "describe") {
        if (!ruleText.trim()) throw new Error("Describe the rule in a sentence first.");
        if (!ruleTargets.length) throw new Error("Pick at least one target field the rule writes to.");
        if (!ruleObjects.length) throw new Error("Pick at least one module.");
        const res = await MappingApi.authorRule(String(conversionId), {
          description: ruleText.trim(),
          target_fields: ruleTargets,
          objects: ruleObjects,
        });
        setRuleResult(res);
        // Deliberately does NOT close: the translation is only visible now, and
        // closing would hide what was actually saved.
        await onDone(`Learned ${ruleTargets.length} field(s) — ${ruleTargets.join(", ")} — for ${res.objects.join(", ")}.`);
        return;
      }
      if (mode === "split") {
        if (!srcCol) throw new Error("Pick the source column to split.");
        let n = 0;
        if (preset === "phone") {
          for (const [part, fid] of Object.entries(phoneParts)) {
            if (!fid) continue;
            await applyOne(fid, srcCol, "PHONE_PART", { part });
            n++;
          }
          if (!n) throw new Error("Assign at least one phone part to a target field.");
        } else {
          for (const row of splitRows) {
            if (!row.fieldId) continue;
            await applyOne(row.fieldId, srcCol, "SPLIT", { separator: sep, index: row.index });
            n++;
          }
          if (!n) throw new Error("Add at least one part → target field.");
        }
        await onDone(`Split ${srcCol} into ${n} field${n === 1 ? "" : "s"}.`);
      } else {
        if (!combineTarget) throw new Error("Pick the target field to combine into.");
        if (combineCols.length < 2) throw new Error("Pick at least two source columns to combine.");
        await applyOne(combineTarget, combineCols[0], "CONCAT", { columns: combineCols, separator: combineSep });
        await onDone(`Combined ${combineCols.length} columns into the target field.`);
      }
    } catch (e: any) {
      setErr(e?.response?.data?.detail ?? e?.message ?? "Could not apply.");
    } finally {
      setBusy(false);
    }
  };

  // {id,label} for the tick-list. Built once rather than inside the map so a
  // 1,365-row list is not rebuilt on every keystroke in the filter box.
  const targetFieldOptions = useMemo(
    () => targetFields.map((f) => ({ id: String(f.id), label: f.field_name })),
    [targetFields]);

  const fieldSelect = (value: string, onChange: (v: string) => void, placeholder: string) => (
    <select value={value} onChange={(e) => onChange(e.target.value)}
      className="w-full rounded-md border border-line px-2 py-1.5 text-xs">
      <option value="">{placeholder}</option>
      {targetFields.map((f) => <option key={String(f.id)} value={String(f.id)}>{f.field_name}</option>)}
    </select>
  );

  return (
    <Modal open={open} onClose={onClose} size="lg" title="Split / combine columns"
      footer={<>
        <Button variant="ghost" onClick={onClose}>Cancel</Button>
        <Button onClick={() => void submit()} loading={busy}>Apply</Button>
      </>}>
      <div className="space-y-4 text-sm">
        <div className="flex gap-1.5">
          {(["split", "combine", "describe"] as const).map((mo) => (
            <button key={mo} onClick={() => setMode(mo)}
              className={cn("rounded-md border px-3 py-1 text-xs",
                mode === mo ? "border-brand bg-brand text-white" : "border-line text-ink-muted hover:text-ink")}>
              {mo === "split" ? "One source → many fields"
                : mo === "combine" ? "Many sources → one field"
                : "Describe a rule"}
            </button>
          ))}
        </div>

        {mode === "split" ? (
          <>
            <div>
              <div className="mb-1 text-xs font-semibold text-ink">Source column to split</div>
              <select value={srcCol} onChange={(e) => setSrcCol(e.target.value)}
                className="w-full rounded-md border border-line px-2 py-1.5 text-xs">
                <option value="">Choose a source column…</option>
                {sourceColumns.map((c) => <option key={colName(c)} value={colName(c)}>{colName(c)}</option>)}
              </select>
            </div>
            <div className="flex gap-1.5">
              {(["phone", "delimiter"] as const).map((p) => (
                <button key={p} onClick={() => setPreset(p)}
                  className={cn("rounded-md border px-2.5 py-1 text-[11px]",
                    preset === p ? "border-brand bg-brand-subtle text-brand-dark" : "border-line text-ink-muted")}>
                  {p === "phone" ? "Phone / Fax parts" : "Split by delimiter"}
                </button>
              ))}
            </div>
            {preset === "phone" ? (
              <div className="space-y-2">
                <p className="text-[11px] text-ink-muted">Assign each phone part to its FBDI field (leave blank to skip).</p>
                {(["country", "area", "extension", "number"] as const).map((part) => (
                  <div key={part} className="flex items-center gap-2">
                    <span className="w-24 text-xs capitalize text-ink-muted">{part}</span>
                    {fieldSelect(phoneParts[part] || "", (v) => setPhoneParts((s) => ({ ...s, [part]: v })), "— target field —")}
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-24 text-xs text-ink-muted">Delimiter</span>
                  <input value={sep} onChange={(e) => setSep(e.target.value)}
                    className="w-24 rounded-md border border-line px-2 py-1.5 text-xs" />
                </div>
                {/* Tick the fields the parts go to, in order — the mirror image of the
                    combine tab's source-column list. It replaced a stack of dropdowns
                    with an "+ Add part" button: choosing four fields meant four clicks
                    to add rows and four dropdowns to hunt through, on a template with
                    1,365 fields. Ticking also makes the part NUMBERS automatic, which
                    is where the dropdown version went wrong most often — two rows
                    silently sharing an index. */}
                <div className="mb-1 text-xs font-semibold text-ink">Target fields (in order)</div>
                <input
                  value={splitFilter}
                  onChange={(e) => setSplitFilter(e.target.value)}
                  placeholder="Filter fields…"
                  className="w-full rounded-md border border-line px-2 py-1.5 text-xs"
                />
                <div className="max-h-40 space-y-1 overflow-auto rounded-md border border-line p-2">
                  {targetFieldOptions
                    .filter((f) => !splitFilter
                      || f.label.toLowerCase().includes(splitFilter.toLowerCase()))
                    .map((f) => {
                      const at = splitRows.findIndex((r) => r.fieldId === f.id);
                      return (
                        <label key={f.id} className="flex items-center gap-2 text-xs">
                          <input
                            type="checkbox"
                            checked={at >= 0}
                            onChange={(e) => setSplitRows((rows) => {
                              const kept = rows.filter((r) => r.fieldId && r.fieldId !== f.id);
                              const next = e.target.checked
                                ? [...kept, { fieldId: f.id, index: kept.length }]
                                : kept;
                              // Re-number so the part indexes always match tick order
                              // and can never collide.
                              return next.map((r, i) => ({ ...r, index: i }));
                            })}
                          />
                          <span className="text-ink">{f.label}</span>
                          {at >= 0 && (
                            <span className="text-[10px] text-ink-subtle">
                              part #{splitRows[at].index + 1}
                            </span>
                          )}
                        </label>
                      );
                    })}
                </div>
                {splitRows.filter((r) => r.fieldId).length > 0 && (
                  <p className="text-[11px] text-ink-muted">
                    {splitRows.filter((r) => r.fieldId).length} field(s) selected — the
                    value is split on <span className="font-mono">{sep || "the delimiter"}</span>{" "}
                    and the parts land in the order ticked.
                  </p>
                )}
              </div>
            )}
          </>
        ) : mode === "combine" ? (
          <>
            <div>
              <div className="mb-1 text-xs font-semibold text-ink">Combine into target field</div>
              {fieldSelect(combineTarget, setCombineTarget, "Choose the FBDI field…")}
            </div>
            <div>
              <div className="mb-1 text-xs font-semibold text-ink">Source columns (in order)</div>
              <div className="max-h-40 space-y-1 overflow-auto rounded-md border border-line p-2">
                {sourceColumns.map((c) => {
                  const name = colName(c);
                  const idx = combineCols.indexOf(name);
                  return (
                    <label key={name} className="flex items-center gap-2 text-xs">
                      <input type="checkbox" checked={idx >= 0}
                        onChange={(e) => setCombineCols((cols) => e.target.checked ? [...cols, name] : cols.filter((x) => x !== name))} />
                      <span className="font-mono text-ink">{name}</span>
                      {idx >= 0 && <span className="text-[10px] text-ink-subtle">#{idx + 1}</span>}
                    </label>
                  );
                })}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-ink-muted">Separator</span>
              <input value={combineSep} onChange={(e) => setCombineSep(e.target.value)}
                className="w-24 rounded-md border border-line px-2 py-1.5 text-xs" />
            </div>
          </>
        ) : null}

        {mode === "describe" && (
          <>
            <div>
              <div className="mb-1 text-xs font-semibold text-ink">Describe the rule</div>
              <textarea
                value={ruleText}
                onChange={(e) => setRuleText(e.target.value)}
                rows={3}
                placeholder={"e.g. Trim the part number and upper-case it\n"
                  + "e.g. If the remittance email has a value set Delivery Method to EMAIL, else FAX"}
                className="w-full rounded-md border border-line px-2.5 py-2 text-xs"
              />
              <p className="mt-1 text-[11px] text-ink-subtle">
                Written in plain English and turned into a transformation rule. You
                see the translation before anything is saved.
              </p>
            </div>

            <div>
              {/* A rule routinely writes to SEVERAL fields — splitting a phone into
                  country, area, number and extension is one sentence, not four. The
                  single dropdown forced the analyst to retype the same sentence once
                  per destination, and the copies then drifted apart as each was
                  edited. Ticking several here writes one learning per field from one
                  sentence, so they cannot diverge. The many-sources direction needs
                  nothing extra: name the columns in the sentence and the translator
                  puts them in the rule's own config. */}
              <div className="mb-1 text-xs font-semibold text-ink">
                Target field(s) it writes to
              </div>
              <input
                value={ruleTargetFilter}
                onChange={(e) => setRuleTargetFilter(e.target.value)}
                placeholder="Filter fields…"
                className="mb-1 w-full rounded-md border border-line px-2 py-1.5 text-xs"
              />
              <div className="max-h-40 space-y-1 overflow-auto rounded-md border border-line p-2">
                {targetFieldOptions
                  .filter((f) => !ruleTargetFilter
                    || f.label.toLowerCase().includes(ruleTargetFilter.toLowerCase()))
                  .map((f) => {
                    const on = ruleTargets.includes(f.label);
                    return (
                      <label key={f.id} className="flex items-center gap-2 text-xs">
                        <input
                          type="checkbox"
                          checked={on}
                          onChange={(e) => setRuleTargets((t) => e.target.checked
                            ? [...t, f.label]
                            : t.filter((x) => x !== f.label))}
                        />
                        <span className="text-ink">{f.label}</span>
                      </label>
                    );
                  })}
              </div>
              {ruleTargets.length > 0 && (
                <p className="mt-1 text-[11px] text-ink-muted">
                  One sentence, {ruleTargets.length} field(s):{" "}
                  <span className="font-mono">{ruleTargets.join(", ")}</span>
                </p>
              )}
            </div>

            <div>
              <div className="mb-1 text-xs font-semibold text-ink">Learn it for these modules</div>
              {/* Explicit, never inferred. Guessing that an Item rule also suits
                  Customer is the kind of silent over-reach that makes a learning
                  library untrustworthy. */}
              <div className="flex flex-wrap gap-1.5">
                {RULE_MODULES.map((o) => {
                  const on = ruleObjects.includes(o);
                  return (
                    <button key={o} type="button"
                      onClick={() => setRuleObjects((xs) =>
                        on ? xs.filter((x) => x !== o) : [...xs, o])}
                      className={cn("rounded-full border px-2.5 py-1 text-[11px]",
                        on ? "border-brand bg-brand-subtle text-brand-dark"
                           : "border-line text-ink-muted hover:text-ink")}>
                      {o}
                    </button>
                  );
                })}
              </div>
              <p className="mt-1 text-[11px] text-ink-subtle">
                Saved against this client and source system only — a rule about this
                extract is not a fact about NetSuite generally.
              </p>
            </div>

            {ruleResult && (
              <div className="rounded-lg border border-line bg-canvas p-2.5 text-[11px]">
                <div className="font-medium text-ink">
                  Learned for {ruleResult.objects.join(", ") || "nothing"} as{" "}
                  <span className="font-mono">{ruleResult.translated?.rule_type}</span>
                </div>
                {ruleResult.translated?.explanation && (
                  <div className="mt-0.5 text-ink-muted">{ruleResult.translated.explanation}</div>
                )}
                {!!ruleResult.translated?.ambiguities?.length && (
                  <div className="mt-1 text-warning">
                    Check: {ruleResult.translated.ambiguities.join(" · ")}
                  </div>
                )}
                {!!ruleResult.unknown?.length && (
                  <div className="mt-1 text-danger">
                    Not a known module, skipped: {ruleResult.unknown.join(", ")}
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {err && <div className="rounded-lg border border-danger/30 bg-danger-subtle p-2.5 text-xs text-danger">{err}</div>}
      </div>
    </Modal>
  );
};

// ─────── Top KPI pill ───────

const Stat: React.FC<{
  label: string; value: number; tone?: "info" | "success" | "danger" | "brand";
  onClick?: () => void; active?: boolean;
}> = ({ label, value, tone, onClick, active }) => {
  const text = tone === "info" ? "text-info" :
               tone === "success" ? "text-success" :
               tone === "danger" ? "text-danger" :
               tone === "brand" ? "text-brand-dark" :
               "text-ink";
  const inner = (
    <>
      <span className={cn("text-base font-semibold tabular-nums", text)}>{value}</span>
      <span className="text-[10.5px] uppercase tracking-wider text-ink-muted">{label}</span>
    </>
  );
  if (!onClick) return <div className="flex items-baseline gap-1.5">{inner}</div>;
  return (
    <button
      onClick={onClick}
      title={`Filter to ${label}`}
      className={cn("flex items-baseline gap-1.5 rounded-md px-1.5 py-0.5 transition hover:bg-canvas",
        active && "bg-canvas ring-1 ring-brand/40")}
    >
      {inner}
    </button>
  );
};

// ─────── Tabular mapping view ───────
// One row per target FBDI field: the source it's drawn from, whether the target
// is mandatory, HOW the value is produced (learned / rule-based / AI / constant
// default / suppressed), any transform, the confidence, and the lower-probability
// alternative source columns the ranker considered (click one to re-map).

/** Derive a human-readable "how was this mapped" chip from the mapping row. */
/**
 * The decision layers, in the exact order the tool applies them. Every target
 * field takes the HIGHEST layer that has an answer; AI only fills what nothing
 * above it could. This is the single source of truth for both the per-field badge
 * and the precedence bar, so the two can never disagree.
 */
type LayerKey =
  | "gold" | "learned" | "workbook" | "manual"
  | "deterministic" | "default" | "ai" | "suppressed" | "unmapped";

const LAYER_META: Record<
  LayerKey,
  { label: string; tone: "brand" | "info" | "success" | "warning" | "neutral"; blurb: string }
> = {
  gold:          { label: "Golden record",    tone: "brand",   blurb: "From an approved gold file for this object" },
  learned:       { label: "Learned",          tone: "brand",   blurb: "From the learning knowledge base (prior conversions + metadata catalog)" },
  workbook:      { label: "Mapping workbook",  tone: "info",    blurb: "From an uploaded source→target mapping" },
  manual:        { label: "Your rule",         tone: "warning", blurb: "A rule or override you applied by hand" },
  deterministic: { label: "Deterministic",     tone: "success", blurb: "Rule-based match — country/currency/UOM/flags and column-name match" },
  default:       { label: "Default",           tone: "info",    blurb: "A constant value written on every row" },
  ai:            { label: "AI",                tone: "warning", blurb: "AI suggestion — used only where no layer above it applied" },
  suppressed:    { label: "Left blank",        tone: "neutral", blurb: "Gold leaves this column empty on purpose" },
  unmapped:      { label: "Unmapped",          tone: "neutral", blurb: "No source column, default, or rule yet" },
};

// Priority order shown in the precedence bar (the pipeline, gold → AI).
const LAYER_ORDER: LayerKey[] = ["gold", "learned", "workbook", "manual", "deterministic", "default", "ai"];

function classifyLayer(
  m: MappingSuggestion | undefined,
  f: FBDIField,
  effectiveDefaults: Record<string, string>,
  hasRule: boolean,
  suppressedFields?: Set<string>,
): LayerKey {
  const dv = defaultFor(m, f.field_name, effectiveDefaults, suppressedFields);
  // A strategy correction or a suppress_field learning is the same decision as a
  // not_applicable mapping, so it must read as "Left blank" and not as "Default".
  if (m?.status === "not_applicable"
      || suppressedFields?.has(normFieldKey(f.field_name))) return "suppressed";
  if (!m?.source_column) return dv ? "default" : "unmapped";

  const reason = (m.reason || "").toLowerCase();
  if (m.status === "overridden") return "manual";
  // The learning engine embeds the rule's origin in the reason string
  // (`…captured from "gold example"`), so we can name the exact source layer.
  if (reason.includes('from "gold') || reason.includes("value-set") || reason.includes("example")) return "gold";
  if (reason.includes("mapping workbook")) return "workbook";
  if (reason.includes("learning library") || reason.includes("learned") ||
      reason.includes("metadata catalog") || reason.includes("knowledge")) return "learned";
  if (hasRule || m.suggested_transformation?.rule_type) return "manual";
  if ((m.confidence ?? 0) >= 0.6) return "deterministic";
  return "ai";
}

function mappingMethod(
  m: MappingSuggestion | undefined,
  f: FBDIField,
  effectiveDefaults: Record<string, string>,
  hasRule: boolean,
  suppressedFields?: Set<string>,
): { label: string; tone: "brand" | "info" | "success" | "warning" | "neutral"; detail?: string } {
  const key = classifyLayer(m, f, effectiveDefaults, hasRule, suppressedFields);
  const meta = LAYER_META[key];
  return { label: meta.label, tone: meta.tone, detail: m?.reason || meta.blurb };
}

const LAYER_DOT: Record<LayerKey, string> = {
  gold: "bg-brand", learned: "bg-brand/70", workbook: "bg-info", manual: "bg-warning",
  deterministic: "bg-success", default: "bg-info/60", ai: "bg-warning/70",
  suppressed: "bg-ink-subtle", unmapped: "bg-line",
};

/**
 * Precedence bar — shows HOW this output is built, and how much each layer did.
 *
 * The tool resolves every field through the same ordered pipeline: an approved
 * golden record wins first, then learned rules, then an uploaded mapping workbook,
 * then rules you applied by hand, then deterministic matches, then constant
 * defaults — and only where none of those had an answer does AI fill the gap. The
 * counts are live for this conversion, so the bar doubles as a "what carried the
 * output" breakdown. Shown above both the canvas and the table.
 */
const PrecedenceBar: React.FC<{
  mappings: MappingSuggestion[];
  targetFields: FBDIField[];
  visibleTargetIds: Set<string> | null;
  ruleTargetIds: Set<string>;
  effectiveDefaults: Record<string, string>;
  suppressedFields: Set<string>;
  activeLayer?: LayerKey | null;
  onSelectLayer?: (k: LayerKey | null) => void;
}> = ({ mappings, targetFields, visibleTargetIds, ruleTargetIds, effectiveDefaults, suppressedFields, activeLayer, onSelectLayer }) => {
  const { counts, total } = useMemo(() => {
    const _PRIO: Record<string, number> = { overridden: 4, approved: 3, not_applicable: 2, rejected: 1, suggested: 0 };
    const mapByTarget = new Map<string, MappingSuggestion>();
    for (const m of mappings) {
      const k = String(m.target_field_id);
      const cur = mapByTarget.get(k);
      if (!cur || (_PRIO[m.status ?? "suggested"] ?? 0) > (_PRIO[cur.status ?? "suggested"] ?? 0)) mapByTarget.set(k, m);
    }
    const c: Record<LayerKey, number> = {
      gold: 0, learned: 0, workbook: 0, manual: 0,
      deterministic: 0, default: 0, ai: 0, suppressed: 0, unmapped: 0,
    };
    // Match the id handling the two views already use: visibleTargetIds/ruleTargetIds
    // are keyed on the raw target_field_id, while mapByTarget is keyed on its string
    // form. Be tolerant of both so counts can never silently diverge from the rows.
    const seen = (set: Set<any>, id: any) => set.has(id) || set.has(String(id));
    let n = 0;
    for (const f of targetFields) {
      if (visibleTargetIds && !seen(visibleTargetIds as Set<any>, f.id)) continue;
      const m = mapByTarget.get(String(f.id));
      const key = classifyLayer(m, f, effectiveDefaults, seen(ruleTargetIds as Set<any>, f.id), suppressedFields);
      c[key] += 1;
      n += 1;
    }
    return { counts: c, total: n };
  }, [mappings, targetFields, visibleTargetIds, ruleTargetIds, effectiveDefaults, suppressedFields]);

  const [open, setOpen] = useState(false);
  const resolvedByAi = counts.ai;
  const aiPct = total ? Math.round((resolvedByAi / total) * 100) : 0;

  return (
    <div className="border-b border-line bg-canvas/60 px-5 py-2.5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 text-[11px] text-ink-muted">
          <Layers className="h-3.5 w-3.5 text-brand" />
          <span className="font-semibold text-ink">How each field is decided</span>
          <span className="hidden sm:inline">
            — highest layer with an answer wins; AI only fills the rest
            {total > 0 && <> (<span className="font-medium text-ink">{aiPct}%</span> from AI)</>}
          </span>
        </div>
        <button onClick={() => setOpen(o => !o)} className="text-[11px] font-medium text-brand hover:underline">
          {open ? "Hide" : "What's this?"}
        </button>
      </div>

      <div className="mt-2 flex flex-wrap items-center gap-x-1.5 gap-y-1.5">
        {LAYER_ORDER.map((k, i) => {
          const meta = LAYER_META[k];
          const n = counts[k];
          return (
            <React.Fragment key={k}>
              {i > 0 && <ChevronRight className="h-3 w-3 text-ink-subtle" />}
              <button
                title={n > 0 ? `${meta.blurb} — click to filter` : meta.blurb}
                disabled={n === 0}
                onClick={() => onSelectLayer?.(activeLayer === k ? null : k)}
                className={cn(
                  "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] transition",
                  activeLayer === k ? "border-brand bg-brand-subtle text-brand-dark ring-1 ring-brand/40"
                    : n > 0 ? "border-line bg-white text-ink hover:border-brand/50"
                    : "cursor-default border-line/60 bg-transparent text-ink-subtle",
                )}
              >
                <span className={cn("h-2 w-2 rounded-full", n > 0 ? LAYER_DOT[k] : "bg-line")} />
                <span className="font-medium">{meta.label}</span>
                <span className="tabular-nums">{n}</span>
              </button>
            </React.Fragment>
          );
        })}
        {counts.suppressed > 0 && (
          <button title={`${LAYER_META.suppressed.blurb} — click to filter`}
            onClick={() => onSelectLayer?.(activeLayer === "suppressed" ? null : "suppressed")}
            className={cn("ml-1 inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] transition",
              activeLayer === "suppressed" ? "border-brand bg-brand-subtle text-brand-dark ring-1 ring-brand/40" : "border-line/60 text-ink-subtle hover:border-brand/50")}>
            <span className="h-2 w-2 rounded-full bg-ink-subtle" /> Left blank {counts.suppressed}
          </button>
        )}
        {counts.unmapped > 0 && (
          <button title={`${LAYER_META.unmapped.blurb} — click to filter`}
            onClick={() => onSelectLayer?.(activeLayer === "unmapped" ? null : "unmapped")}
            className={cn("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] transition",
              activeLayer === "unmapped" ? "border-brand bg-brand-subtle text-brand-dark ring-1 ring-brand/40" : "border-line/60 text-ink-subtle hover:border-brand/50")}>
            <span className="h-2 w-2 rounded-full bg-line" /> Unmapped {counts.unmapped}
          </button>
        )}
      </div>

      {open && (
        <div className="mt-2 grid grid-cols-1 gap-1 rounded-md border border-line bg-white p-3 text-[11.5px] sm:grid-cols-2">
          {LAYER_ORDER.map((k, i) => (
            <div key={k} className="flex items-baseline gap-2">
              <span className={cn("mt-1 h-2 w-2 shrink-0 rounded-full", LAYER_DOT[k])} />
              <span>
                <span className="font-semibold text-ink">{i + 1}. {LAYER_META[k].label}</span>{" "}
                <span className="text-ink-muted">— {LAYER_META[k].blurb}</span>
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/** Flag mappings the tool isn't sure about, so a human confirms rather than the
 *  tool silently guessing (the "confirm per-install" idea). Returns the reason,
 *  or null when the mapping is trustworthy. Human decisions and gold/learned
 *  rules are never flagged — they're already settled. */
function needsConfirmation(
  m: MappingSuggestion | undefined,
  f: FBDIField,
  alts: MappingCandidate[],
  dv?: string | null,
): string | null {
  if (!m) return null;
  // Settled: a person chose it, gold suppressed it, or it came from the KB.
  if (m.status === "overridden" || m.status === "not_applicable") return null;
  const reason = (m.reason || "").toLowerCase();
  if (reason.includes("learning library") || reason.includes("gold") || reason.includes("learned")) return null;

  const conf = m.confidence ?? 0;
  if (m.source_column) {
    if (conf < 0.6) {
      return `Low-confidence match (${Math.round(conf * 100)}%) — AI/weak rule score. Confirm the source column is right.`;
    }
    const top = alts[0];
    const gap = conf - (top?.confidence ?? 0);
    if (top && gap < 0.1) {
      return `Ambiguous — “${top.source_column}” scored almost the same (${Math.round((top.confidence ?? 0) * 100)}%). Confirm which column is correct.`;
    }
    return null;
  }
  if (f.required && !dv) return "Required field with no source column and no default — must be resolved before load.";
  return null;
}

/** Clickable, sort-aware table header cell. */
const SortableTh: React.FC<{
  label: string;
  sk: "seq" | "source" | "target" | "method" | "conf" | "required";
  sortKey: string;
  sortDir: "asc" | "desc";
  onSort: (k: any) => void;
  extra?: React.ReactNode;
}> = ({ label, sk, sortKey, sortDir, onSort, extra }) => {
  const active = sortKey === sk;
  return (
    <th
      onClick={() => onSort(sk)}
      title={`Sort by ${label.toLowerCase()}`}
      className={cn(
        "cursor-pointer select-none border-b border-line px-3 py-2 font-semibold transition hover:text-ink",
        active && "text-brand-dark",
      )}
    >
      <span className="inline-flex items-center gap-1">
        {label}
        <ChevronDown
          className={cn(
            "h-3 w-3 transition",
            active ? "opacity-100" : "opacity-25",
            active && sortDir === "asc" && "rotate-180",
          )}
        />
        {extra}
      </span>
    </th>
  );
};

const MethodChip: React.FC<{ tone: string; children: React.ReactNode; title?: string }> = ({ tone, children, title }) => (
  <span
    title={title}
    className={cn(
      "inline-flex items-center whitespace-nowrap rounded px-1.5 py-0.5 text-[10px] font-medium",
      tone === "brand" && "bg-brand-subtle text-brand-dark",
      tone === "info" && "bg-info-subtle text-info",
      tone === "success" && "bg-success-subtle text-success",
      tone === "warning" && "bg-warning-subtle text-warning-dark",
      tone === "neutral" && "bg-canvas text-ink-muted",
    )}
  >
    {children}
  </span>
);

const MappingTableView: React.FC<{
  conversionId: string;
  sourceColumns: DatasetDetail["columns"];
  targetFields: FBDIField[];
  mappings: MappingSuggestion[];
  visibleTargetIds: Set<number>;
  effectiveDefaults: Record<string, string>;
  suppressedFields: Set<string>;
  ruleTargetIds: Set<number>;
  selectedMappingId: number | null;
  setSelectedMappingId: (id: number | null) => void;
  onOverride: (m: MappingSuggestion, newSrc: string) => void;
  loading?: boolean;
  aiVerdicts?: Record<string, Record<string, { verdict: string; reason: string }>>;
  onAiVerdicts?: (m: Record<string, Record<string, { verdict: string; reason: string }>>) => void;
  onReload?: () => void | Promise<void>;
  objectName?: string;
  sourceName?: string;
}> = ({
  conversionId, sourceColumns, targetFields, mappings, visibleTargetIds,
  effectiveDefaults, suppressedFields, ruleTargetIds, selectedMappingId, setSelectedMappingId, onOverride, loading,
  aiVerdicts, onAiVerdicts, onReload, objectName, sourceName,
}) => {
  // Ranked alternatives for every target field (one round-trip), so each row can
  // show the runner-up source columns the matcher scored lower.
  const [altByTarget, setAltByTarget] = useState<Record<string, MappingCandidate[]>>({});
  const [altLoading, setAltLoading] = useState(true);
  const [vetting, setVetting] = useState(false);
  const [vetMsg, setVetMsg] = useState<string | null>(null);
  const [alreadyVetted, setAlreadyVetted] = useState(false);
  // AI-vetted value crosswalks (legacy → Oracle code) per target field — shown in
  // the vet panel AND carried into the Excel export. Fetched once per conversion.
  const [cwByField, setCwByField] = useState<Record<string, { legacy: string; oracle: string; status: string }[]>>({});
  useEffect(() => {
    if (!conversionId) return;
    MappingApi.codedValues(conversionId)
      .then((coded) => {
        const map: Record<string, { legacy: string; oracle: string; status: string }[]> = {};
        (coded?.columns || []).forEach((c) => {
          const pairs = (c.resolved || [])
            .filter((rv) => String(rv.from) !== String(rv.to))
            .map((rv) => ({ legacy: String(rv.from), oracle: String(rv.to), status: rv.how || "" }));
          if (pairs.length) map[(c.target_field || "").toLowerCase()] = pairs;
        });
        setCwByField(map);
      })
      .catch(() => setCwByField({}));
  }, [conversionId]);
  useEffect(() => {
    if (!conversionId) return;
    setAltLoading(true);
    MappingApi.candidates(conversionId, { topN: 4 })
      .then((groups) => {
        const byId: Record<string, MappingCandidate[]> = {};
        const cached: Record<string, Record<string, { verdict: string; reason: string }>> = {};
        for (const g of groups) {
          byId[String(g.target_field_id)] = g.candidates || [];
          // candidates may already carry stored AI verdicts (from an earlier review)
          for (const c of g.candidates || []) {
            if (c.ai_verdict) {
              (cached[String(g.target_field_id)] ||= {})[c.source_column] =
                { verdict: c.ai_verdict, reason: c.ai_reason || "" };
            }
          }
        }
        setAltByTarget(byId);
        if (Object.keys(cached).length) {
          onAiVerdicts?.(cached);              // seed the shared cache for the panel
          setAlreadyVetted(true);
          setVetMsg("AI review already done for this project — reasons are shown. No need to re-run.");
        }
      })
      .catch(() => setAltByTarget({}))
      .finally(() => setAltLoading(false));
  }, [conversionId]);

  // Batched AI vetting shared by the toolbar button AND the export. Covers ALL the
  // given target-field ids (chunked so a wide template — Item/Customer, 1000+
  // fields — can't overrun the gateway), folds each verdict + reason back into the
  // on-screen candidates, and RETURNS the merged verdict map so a caller (export)
  // can annotate immediately without waiting on React state. Already-vetted fields
  // reuse stored verdicts server-side (no repeat token cost).
  const runVet = async (
    ids: string[],
    onlyUncertain: boolean,
    onProgress?: (done: number, total: number) => void,
  ): Promise<Record<string, Record<string, { verdict: string; reason: string }>>> => {
    const merged: Record<string, Record<string, { verdict: string; reason: string }>> = {};
    const CHUNK = 90;
    for (let i = 0; i < ids.length; i += CHUNK) {
      const slice = ids.slice(i, i + CHUNK);
      try {
        const r = await MappingApi.vetCandidates(conversionId, {
          topN: 4, onlyUncertain, targetFieldIds: slice,
        });
        for (const [tid, v] of Object.entries(r.ai || {})) merged[tid] = { ...(merged[tid] || {}), ...v };
        setAltByTarget((prev) => {
          const next: Record<string, MappingCandidate[]> = { ...prev };
          for (const g of r.groups) {
            const verdicts = r.ai[String(g.target_field_id)] || {};
            next[String(g.target_field_id)] = (g.candidates || []).map((c) => {
              const v = verdicts[c.source_column];
              return v ? { ...c, ai_verdict: v.verdict, ai_reason: v.reason } : c;
            });
          }
          return next;
        });
      } catch { /* keep going — a failed chunk just keeps its deterministic reasons */ }
      onProgress?.(Math.min(i + CHUNK, ids.length), ids.length);
    }
    if (Object.keys(merged).length) { onAiVerdicts?.(merged); setAlreadyVetted(true); }
    return merged;
  };

  // Toolbar button: vet EVERY field in view (all modules, not just the first 120,
  // and not only the uncertain ones), with progress.
  const vetWithAi = async () => {
    if (!conversionId) return;
    setVetting(true); setVetMsg(null);
    try {
      const ids = viewRows.map((r) => String(r.f.id));
      const merged = await runVet(ids, false, (done, total) =>
        setVetMsg(`AI reviewing options… ${done}/${total} fields`));
      const n = Object.values(merged).reduce((s, v) => s + Object.keys(v).length, 0);
      setVetMsg(n > 0
        ? `AI reviewed ${n} option(s) across ${Object.keys(merged).length} field(s). Reasons added to the table, panel and export.`
        : "AI review returned nothing this time — the deterministic reasons are still shown.");
    } catch {
      setVetMsg("AI review is unavailable right now — the deterministic reasons are still shown.");
    } finally { setVetting(false); }
  };

  // Opt-in: AI suggests a source ONLY for fields that are still unmapped (no source,
  // no default, not human-touched). Lands as reviewable 'suggested' mappings.
  const [filling, setFilling] = useState(false);
  const fillBlanksWithAi = async () => {
    if (!conversionId) return;
    if (!window.confirm("Ask AI to suggest a source for the unmapped fields? Results land in Needs-review for you to approve or reject — nothing is applied blindly.")) return;
    setFilling(true); setVetMsg(null);
    try {
      const r = await MappingApi.aiFillBlanks(conversionId, { requiredOnly: onlyRequired });
      setVetMsg(r.filled > 0
        ? `AI suggested a source for ${r.filled} of ${r.considered} unmapped field(s). Review them under Needs review.`
        : (r.note || "No unmapped fields to fill."));
      if (r.filled > 0) await onReload?.();
    } catch (e: any) {
      setVetMsg(e?.response?.data?.detail || "AI fill is unavailable right now.");
    } finally { setFilling(false); }
  };

  // Field names that occur on more than one interface sheet (e.g. "Item Number"
  // is the linking key on all 16 item tables). We badge those with their sheet so
  // they don't read as the same field mapped repeatedly.
  const dupNames = useMemo(() => {
    const c = new Map<string, number>();
    for (const f of targetFields) c.set(f.field_name, (c.get(f.field_name) || 0) + 1);
    return new Set([...c].filter(([, n]) => n > 1).map(([k]) => k));
  }, [targetFields]);
  const mapByTarget = useMemo(() => {
    // Keep the HIGHEST-PRIORITY mapping per target field. The backend can return
    // more than one row for a target (e.g. a stale "suggested" plus a human
    // "rejected"/"approved"); last-write-wins let a suggested row shadow a rejected
    // one, so a rejected mapping was still shown/exported as "suggested".
    const PRIO: Record<string, number> = { overridden: 4, approved: 3, not_applicable: 2, rejected: 1, suggested: 0 };
    const m: Record<string, MappingSuggestion> = {};
    for (const x of mappings) {
      const k = String(x.target_field_id);
      const cur = m[k];
      if (!cur || (PRIO[x.status ?? "suggested"] ?? 0) > (PRIO[cur.status ?? "suggested"] ?? 0)) m[k] = x;
    }
    return m;
  }, [mappings]);

  const srcProfile = useMemo(() => {
    const m: Record<string, DatasetColumnProfile> = {};
    for (const c of sourceColumns) m[c.column_name] = c;
    return m;
  }, [sourceColumns]);

  const [onlyConfirm, setOnlyConfirm] = useState(false);
  const [onlyRequired, setOnlyRequired] = useState(false);
  const [methodFilter, setMethodFilter] = useState<string>("all");
  const [tableSearch, setTableSearch] = useState("");
  type SortKey = "seq" | "source" | "target" | "method" | "conf" | "required";
  const [sortKey, setSortKey] = useState<SortKey>("seq");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const toggleSort = (k: SortKey) => {
    if (sortKey === k) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(k); setSortDir("asc"); }
  };

  // Derive every row once — the table, the confirm counter and the CSV export
  // all read from this so they can never disagree.
  const viewRows = useMemo(() => {
    return targetFields
      .filter((f) => visibleTargetIds.has(f.id))
      .map((f) => {
        const m = mapByTarget[String(f.id)];
        const hasRule = ruleTargetIds.has(f.id);
        const method = mappingMethod(m, f, effectiveDefaults, hasRule);
        const dv = defaultFor(m, f.field_name, effectiveDefaults, suppressedFields);
        const prof = m?.source_column ? srcProfile[m.source_column] : undefined;
        const transform = m?.suggested_transformation?.rule_type as string | undefined;
        // Alternatives = ranked candidates minus the one actually chosen.
        const alts = (altByTarget[String(f.id)] || [])
          .filter((c) => c.source_column !== m?.source_column)
          .slice(0, 3);
        // "Required" must read the SAME signal everywhere (sort, count, filter,
        // gap). Some templates (e.g. HDL) don't carry the flag on the template
        // field, but the mapping row does (target_required) — so OR them. Without
        // this the table sorted/counted on f.required alone, which was falsy for
        // every HDL row, so "sort by Required" reordered nothing.
        const req = !!(f.required || m?.target_required);
        const isGap = req && !m?.source_column && !dv && m?.status !== "not_applicable";
        const confirm = needsConfirmation(m, f, alts, dv);
        return { f, m, hasRule, method, dv, prof, transform, alts, isGap, confirm, req };
      });
  }, [targetFields, visibleTargetIds, mapByTarget, ruleTargetIds, effectiveDefaults, srcProfile, altByTarget]);

  const confirmCount = viewRows.filter((r) => r.confirm).length;
  const requiredCount = viewRows.filter((r) => r.req).length;
  // The distinct "how it's mapped" methods actually present, for the dropdown.
  const methods = useMemo(
    () => Array.from(new Set(viewRows.map((r) => r.method.label))).sort(),
    [viewRows],
  );

  const rows = useMemo(() => {
    const q = tableSearch.trim().toLowerCase();
    let out = viewRows.filter((r) => {
      if (onlyConfirm && !r.confirm) return false;
      if (onlyRequired && !r.req) return false;
      if (methodFilter !== "all" && r.method.label !== methodFilter) return false;
      if (q) {
        const hay = `${r.f.field_name} ${r.m?.source_column ?? ""} ${r.dv ?? ""}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
    if (sortKey === "seq") {
      // Default order: MANDATORY fields first (they're what blocks a load),
      // then the template's own column sequence.
      out = [...out].sort((a, b) => {
        const ra = a.req ? 0 : 1;
        const rb = b.req ? 0 : 1;
        if (ra !== rb) return ra - rb;
        return (a.f.sequence ?? 0) - (b.f.sequence ?? 0);
      });
    } else {
      const dir = sortDir === "asc" ? 1 : -1;
      const val = (r: typeof viewRows[number]) => {
        switch (sortKey) {
          case "source":   return (r.m?.source_column || "~").toLowerCase(); // unmapped sort last
          case "target":   return (r.f.field_name || "").toLowerCase();
          case "method":   return r.method.label.toLowerCase();
          case "conf":     return r.m?.source_column ? (r.m.confidence ?? 0) : -1;
          // Ascending = mandatory first (that's what people mean by "sort by required").
          case "required": return r.req ? 0 : 1;
          default:         return 0;
        }
      };
      out = [...out].sort((a, b) => {
        const va = val(a), vb = val(b);
        if (va < vb) return -1 * dir;
        if (va > vb) return 1 * dir;
        // Stable tiebreak: still keep required above optional, then sequence.
        const ra = a.req ? 0 : 1;
        const rb = b.req ? 0 : 1;
        if (ra !== rb) return ra - rb;
        return (a.f.sequence ?? 0) - (b.f.sequence ?? 0);
      });
    }
    return out;
  }, [viewRows, onlyConfirm, onlyRequired, methodFilter, tableSearch, sortKey, sortDir]);

  const [exporting, setExporting] = useState(false);
  // Analyst-friendly banded Excel export (Issue #3): one "best suggestion" per target
  // field, bucketed into confidence bands, built server-side (Summary + band sheets).
  const exportMapping = async () => {
    const optReason = (c: MappingCandidate): string => {
      if (c.ai_reason) return `${c.ai_verdict ? c.ai_verdict + ": " : ""}${c.ai_reason}`;
      if (c.plausible === false && c.caution) return `implausible — ${c.caution}`;
      return (c.reasons || []).join("; ");
    };
    const isExcluded = (r: any) =>
      /do-?not-?map|do not map|analyst rule/i.test(String(r.m?.reason || ""));
    // Auto-vet with AI first so the "Vetted Alternatives (AI-checked)" column is
    // genuinely AI-checked, not a deterministic fallback (reuses stored verdicts,
    // so a re-export is cheap). Uncertain-only — confident top picks need no AI.
    let verdicts: Record<string, Record<string, { verdict: string; reason: string }>> = {};
    try {
      setVetMsg("AI-checking options for the export…");
      verdicts = await runVet(rows.map((r) => String(r.f.id)), true);
    } catch { /* export still works with deterministic reasons */ }
    finally { setVetMsg(null); }
    const records = rows.map((r) => {
      const top = r.alts && r.alts.length ? r.alts[0] : null;
      const mappedSrc = r.m?.source_column;
      // Learned / approved / overridden mappings are exact (100); a plain suggested
      // mapping keeps its own confidence; unmapped fields take the top candidate's.
      const approvedLike = ["approved", "overridden"].includes(r.m?.status || "")
        || /learned|gold/i.test(r.method?.label || "");
      let suggested = "", confidence = 0, reason = "";
      if (mappedSrc) {
        suggested = mappedSrc;
        confidence = approvedLike ? 100 : Math.round((r.m?.confidence ?? 0) * 100);
        reason = r.m?.reason || r.method?.label || "";
      } else if (r.dv) {
        // Populated by a constant default → treat as an exact, resolved decision.
        suggested = `(constant) ${r.dv}`;
        confidence = 100;
        reason = r.m?.reason || "Default constant";
      } else if (top) {
        suggested = top.source_column || "";
        confidence = Math.round((top.confidence ?? 0) * 100);
        reason = r.m?.reason || optReason(top) || "weak name/type overlap only";
      } else {
        reason = r.m?.reason || (r.isGap ? "Required field with no source and no default." : "No confident match found");
      }
      // Ranked, AI-checked source alternatives (top few), annotated with the AI
      // verdict/reason from the auto-vet just run (falls back to any stored verdict,
      // then the deterministic reason).
      const fieldVerdicts = verdicts[String(r.f.id)] || {};
      const alternatives = (r.alts || []).slice(0, 4).map((c: MappingCandidate) => {
        const v = fieldVerdicts[c.source_column];
        return {
          source: c.source_column,
          confidence: c.confidence,
          verdict: v?.verdict || c.ai_verdict || "",
          reason: v?.reason || c.ai_reason || optReason(c),
        };
      });
      const crosswalks = cwByField[String(r.f.field_name || "").toLowerCase()] || [];
      // Extra columns for the flat "All Fields" sheet (mirror the on-screen table).
      const how_mapped = [r.method?.label, r.hasRule && !r.transform ? "custom rule" : ""]
        .filter(Boolean).join(" · ");
      const notes = r.isGap
        ? "Required field with no source and no default."
        : (r.confirm || r.m?.reason || r.method?.detail || "");
      return { target_field: r.f.field_name, suggested_source: suggested,
               confidence, reason, excluded: isExcluded(r), alternatives, crosswalks,
               required: !!r.req, how_mapped, transform: r.transform || "",
               status: r.m?.status ? String(r.m.status).replace(/_/g, " ") : "",
               needs_confirmation: r.confirm || "", notes };
    });
    const obj = (objectName || "FBDI").trim();
    const src = (sourceName || "Source").trim();
    const title = `${obj} to ${src} Field Mapping`;
    const filename = `${obj} to ${src} Field Mapping`.replace(/[^\w.-]+/g, "_") + ".xlsx";
    setExporting(true);
    try {
      await OutputApi.mappingExport(conversionId, title, filename, records);
    } catch {
      alert("Couldn't build the mapping workbook. Please try again.");
    } finally { setExporting(false); }
  };

  return (
    <div className="flex-1 overflow-auto bg-white">
      {loading && (
        <div className="flex items-center gap-2 border-b border-line bg-canvas px-5 py-2 text-[12px] text-ink-muted">
          <Spinner /> Running mapping…
        </div>
      )}
      {/* Table toolbar — filters, uncertainty counter, CSV export */}
      <div className="sticky top-0 z-20 flex flex-wrap items-center gap-2 border-b border-line bg-white px-3 py-2">
        <span className="whitespace-nowrap text-[11px] text-ink-muted">
          <span className="font-semibold text-ink">{rows.length}</span>
          {rows.length !== viewRows.length && <span className="text-ink-subtle"> / {viewRows.length}</span>}
          {" "}field{rows.length === 1 ? "" : "s"}
        </span>

        {/* Search across source + target field names */}
        <div className="relative">
          <Search className="pointer-events-none absolute left-2 top-1/2 h-3 w-3 -translate-y-1/2 text-ink-subtle" />
          <input
            value={tableSearch}
            onChange={(e) => setTableSearch(e.target.value)}
            placeholder="Filter source / target…"
            className="h-7 w-52 rounded-md border border-line bg-white pl-7 pr-2 text-[11px] text-ink placeholder:text-ink-subtle focus:border-brand focus:outline-none"
          />
        </div>

        {/* How-it's-mapped filter */}
        <select
          value={methodFilter}
          onChange={(e) => setMethodFilter(e.target.value)}
          title="Filter by how the value is produced"
          className="h-7 rounded-md border border-line bg-white px-2 text-[11px] text-ink focus:border-brand focus:outline-none"
        >
          <option value="all">All methods</option>
          {methods.map((mv) => <option key={mv} value={mv}>{mv}</option>)}
        </select>

        {/* Required-only */}
        <button
          onClick={() => setOnlyRequired((v) => !v)}
          title="Show only mandatory FBDI fields"
          className={cn(
            "inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium transition",
            onlyRequired
              ? "border-danger bg-danger-subtle text-danger"
              : "border-line bg-white text-ink-muted hover:border-danger hover:text-danger",
          )}
        >
          Required only ({requiredCount})
          {onlyRequired && <X className="h-3 w-3" />}
        </button>

        {confirmCount > 0 && (
          <button
            onClick={() => setOnlyConfirm((v) => !v)}
            title="Mappings the tool isn't confident about — low score, or a runner-up column scored almost as well. Confirm rather than trust blindly."
            className={cn(
              "inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium transition",
              onlyConfirm
                ? "border-warning bg-warning-subtle text-warning-dark"
                : "border-line bg-white text-ink-muted hover:border-warning hover:text-warning-dark",
            )}
          >
            <AlertTriangle className="h-3 w-3" />
            {confirmCount} need confirmation
            {onlyConfirm && <X className="h-3 w-3" />}
          </button>
        )}

        {(onlyConfirm || onlyRequired || methodFilter !== "all" || tableSearch || sortKey !== "seq") && (
          <button
            onClick={() => {
              setOnlyConfirm(false); setOnlyRequired(false);
              setMethodFilter("all"); setTableSearch("");
              setSortKey("seq"); setSortDir("asc");
            }}
            className="text-[11px] font-medium text-ink-subtle underline-offset-2 hover:text-ink hover:underline"
          >
            Reset
          </button>
        )}

        <div className="flex-1" />
        {vetMsg && <span className="text-[10px] text-ink-subtle">{vetMsg}</span>}
        <button
          onClick={vetWithAi}
          disabled={vetting || altLoading}
          title={alreadyVetted
            ? "This project has already been reviewed by AI — reasons are shown. Click to review any newly-added options (already-done ones cost no tokens)."
            : "Ask AI to judge the uncertain alternatives and explain why each does or doesn't fit. Adds reasons to the table and the CSV export."}
          className={cn(
            "inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-[11px] font-semibold disabled:opacity-50",
            alreadyVetted
              ? "border-success/40 bg-success-subtle text-success hover:bg-success/10"
              : "border-brand/40 bg-brand-subtle text-brand hover:bg-brand/10",
          )}
        >
          {vetting ? <Spinner /> : alreadyVetted ? <Check className="h-3 w-3" /> : <Sparkles className="h-3 w-3" />}
          {vetting ? "Reviewing…" : alreadyVetted ? "AI review done" : "Vet options with AI"}
        </button>
        <button
          onClick={exportMapping}
          disabled={exporting}
          title="Download the mapping as an Excel workbook grouped into confidence bands (Summary + one sheet per band)"
          className="inline-flex items-center gap-1.5 rounded-md border border-line bg-white px-2.5 py-1 text-[11px] font-semibold text-ink hover:bg-canvas disabled:opacity-50"
        >
          <Download className={cn("h-3 w-3", exporting && "animate-pulse")} /> {exporting ? "Building…" : "Export mapping (Excel)"}
        </button>
      </div>
      <table className="w-full border-collapse text-[12px]">
        <thead className="sticky top-[41px] z-10 bg-canvas">
          <tr className="text-left text-[10px] uppercase tracking-wider text-ink-muted">
            <SortableTh label="Source field"     sk="source"   sortKey={sortKey} sortDir={sortDir} onSort={toggleSort} />
            <th className="border-b border-line px-1 py-2" />
            <SortableTh label="Target FBDI field" sk="target"  sortKey={sortKey} sortDir={sortDir} onSort={toggleSort} />
            <SortableTh label="Required"         sk="required" sortKey={sortKey} sortDir={sortDir} onSort={toggleSort} />
            <SortableTh label="How it's mapped"  sk="method"   sortKey={sortKey} sortDir={sortDir} onSort={toggleSort} />
            <SortableTh label="Conf."            sk="conf"     sortKey={sortKey} sortDir={sortDir} onSort={toggleSort} />
            <th className="border-b border-line px-3 py-2 font-semibold">Other options (lower probability)</th>
            <th className="border-b border-line px-3 py-2 font-semibold">Notes</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const { f, m, hasRule, method, dv, prof, transform, alts, isGap, confirm, req } = r;
            const selected = m && selectedMappingId === m.id;
            return (
              <tr
                key={f.id}
                onClick={() => m && setSelectedMappingId(selected ? null : m.id)}
                className={cn(
                  "cursor-pointer align-top border-b border-line/60 hover:bg-canvas/60",
                  selected && "bg-brand-subtle/25",
                  isGap && "bg-danger-subtle/25",
                )}
              >
                {/* Source */}
                <td className="px-3 py-2">
                  {m?.source_column ? (
                    <>
                      <div className="font-mono text-[11.5px] text-ink">{m.source_column}</div>
                      {prof && (
                        <div className="mt-0.5 text-[10px] text-ink-subtle">
                          {prof.inferred_type} · {formatNumber(prof.distinct_count ?? 0)} distinct
                          {prof.null_percent != null && <> · {Number(prof.null_percent).toFixed(1)}% null</>}
                        </div>
                      )}
                    </>
                  ) : (
                    <span className="text-[11px] italic text-ink-subtle">
                      {dv ? "— (constant)" : "— (none)"}
                    </span>
                  )}
                </td>
                <td className="px-1 py-2 text-ink-subtle">
                  <ArrowRight className="h-3 w-3" />
                </td>
                {/* Target */}
                <td className="px-3 py-2">
                  <div className="font-medium text-ink">
                    {f.field_name}
                    {f.sheet_name && dupNames.has(f.field_name) && (
                      <span className="ml-1.5 rounded bg-canvas px-1 py-0.5 font-mono text-[9px] font-normal text-ink-subtle" title={`Interface sheet: ${f.sheet_name}`}>{f.sheet_name}</span>
                    )}
                  </div>
                  <div className="mt-0.5 text-[10px] text-ink-subtle">{f.data_type || "Character"}</div>
                </td>
                {/* Required */}
                <td className="px-3 py-2">
                  {req ? (
                    <span className="rounded bg-danger-subtle px-1.5 py-0.5 text-[9px] font-bold uppercase text-danger">
                      required
                    </span>
                  ) : (
                    <span className="text-[10px] text-ink-subtle">optional</span>
                  )}
                </td>
                {/* How mapped */}
                <td className="px-3 py-2">
                  <div className="flex flex-wrap items-center gap-1">
                    <MethodChip tone={method.tone} title={method.detail}>{method.label}</MethodChip>
                    {transform && (
                      <MethodChip tone="info" title="Transformation applied to the source value">
                        {transform}
                      </MethodChip>
                    )}
                    {hasRule && !transform && <MethodChip tone="info">custom rule</MethodChip>}
                    {confirm && (
                      <span
                        title={confirm}
                        className="inline-flex items-center gap-0.5 whitespace-nowrap rounded border border-warning bg-warning-subtle px-1.5 py-0.5 text-[10px] font-semibold text-warning-dark"
                      >
                        <AlertTriangle className="h-2.5 w-2.5" /> confirm
                      </span>
                    )}
                  </div>
                  {dv && !m?.source_column && (
                    <div className="mt-0.5 font-mono text-[10px] text-info">→ {dv}</div>
                  )}
                  {m && (
                    <div className="mt-0.5">
                      <Pill tone={statusTone(m.status)}>{m.status.replace("_", " ")}</Pill>
                    </div>
                  )}
                </td>
                {/* Confidence */}
                <td className="px-3 py-2">
                  {m?.source_column ? (() => {
                    const t = confidenceTone(m.confidence ?? 0);
                    return (
                      <span className={cn(
                        "font-mono text-[11px] font-medium tabular-nums",
                        t === "success" ? "text-success" : t === "warning" ? "text-warning-dark" : "text-danger",
                      )}>
                        {Math.round((m.confidence ?? 0) * 100)}%
                      </span>
                    );
                  })() : (
                    <span className="text-[11px] text-ink-subtle">—</span>
                  )}
                </td>
                {/* Alternatives + AI-vetted value crosswalks */}
                <td className="px-3 py-2">
                  {(() => {
                  const cws = cwByField[(f.field_name || "").toLowerCase()] || [];
                  return (
                    <div className="flex flex-wrap items-center gap-1">
                    {altLoading ? (
                      <span className="text-[10px] text-ink-subtle">ranking…</span>
                    ) : alts.length === 0 && !cws.length ? (
                      <span className="text-[10px] text-ink-subtle">—</span>
                    ) : (
                      alts.map((c) => {
                        const bad = c.plausible === false;
                        const why = c.ai_reason
                          ? `${c.ai_verdict ? c.ai_verdict + ": " : ""}${c.ai_reason}`
                          : bad && c.caution ? `implausible — ${c.caution}`
                          : (c.reasons || []).join("; ") || "ranked alternative";
                        return (
                          <button
                            key={c.source_column}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (m) onOverride(m, c.source_column);
                            }}
                            title={`Re-map to ${c.source_column} — ${why}${
                              c.sample_values?.length ? `\nSamples: ${c.sample_values.slice(0, 3).join(", ")}` : ""
                            }`}
                            className={cn(
                              "inline-flex items-center gap-1 rounded border px-1.5 py-0.5 font-mono text-[10px] transition",
                              bad
                                ? "border-danger/40 bg-danger-subtle text-danger line-through decoration-danger/50 hover:border-danger"
                                : "border-line bg-white text-ink-muted hover:border-brand hover:text-brand-dark",
                            )}
                          >
                            {bad && <AlertTriangle className="h-2.5 w-2.5" />}
                            {c.source_column}
                            <span className="text-[9px] text-ink-subtle">{Math.round((c.confidence ?? 0) * 100)}%</span>
                            {c.ai_reason && <Sparkles className="h-2.5 w-2.5 text-brand" />}
                          </button>
                        );
                      })
                    )}
                    {cws.length > 0 && (
                      <span
                        title={`AI-vetted value crosswalks:\n${cws.slice(0, 15).map((p) => `${p.legacy} → ${p.oracle}${p.status ? ` (${p.status})` : ""}`).join("\n")}`}
                        className="inline-flex items-center gap-1 rounded border border-brand/30 bg-brand-subtle px-1.5 py-0.5 text-[10px] text-brand-dark"
                      >
                        <ArrowLeftRight className="h-2.5 w-2.5" />
                        {cws.length} value{cws.length !== 1 ? "s" : ""} vetted
                      </span>
                    )}
                    </div>
                  );
                  })()}
                </td>
                {/* Notes */}
                <td className="px-3 py-2 text-[11px] leading-snug text-ink-muted">
                  {isGap ? (
                    <span className="font-medium text-danger">Required field with no source and no default.</span>
                  ) : confirm ? (
                    <span className="text-warning-dark">{confirm}</span>
                  ) : (
                    m?.reason || method.detail || "—"
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      {rows.length === 0 && (
        <div className="p-8 text-center text-[12px] text-ink-muted">
          {onlyConfirm
            ? "Nothing needs confirmation — every mapping is either high-confidence, learned, or human-approved."
            : "No fields match the current filter."}
        </div>
      )}
    </div>
  );
};

// ─────── The visual mapping canvas ───────

interface CanvasProps {
  sourceColumns: DatasetDetail["columns"];
  targetFields: FBDIField[];
  mappings: MappingSuggestion[];
  visibleTargetIds: Set<number>;
  selectedMappingId: number | null;
  setSelectedMappingId: (id: number | null) => void;
  hoveredSource: string | null;
  setHoveredSource: (s: string | null) => void;
  hoveredTarget: number | null;
  setHoveredTarget: (t: number | null) => void;
  ruleTargetIds?: Set<number>;
  effectiveDefaults?: Record<string, string>;
  suppressedFields: Set<string>;
  onMapDrop?: (targetFieldId: number, sourceColumn: string) => void;
  onUnmap?: (m: MappingSuggestion) => void;
  loading?: boolean;
}

const MappingCanvas: React.FC<CanvasProps> = ({
  sourceColumns, targetFields, mappings, visibleTargetIds,
  selectedMappingId, setSelectedMappingId,
  hoveredSource, setHoveredSource, hoveredTarget, setHoveredTarget,
  ruleTargetIds, effectiveDefaults = {}, suppressedFields, onMapDrop, onUnmap, loading,
}) => {
  // Which source column is being dragged, and which target is hovered during a
  // drag — drives the drop-zone highlight for the drag-to-map gesture.
  const [dragSource, setDragSource] = useState<string | null>(null);
  const [dropTargetId, setDropTargetId] = useState<number | null>(null);
  // Live text filters for the source-column and target-FBDI lists.
  const [srcQuery, setSrcQuery] = useState("");
  // Field names present on more than one interface sheet (e.g. "Item Number") —
  // badged with their sheet so repeats read as distinct per-sheet keys.
  const dupNames = useMemo(() => {
    const c = new Map<string, number>();
    for (const f of targetFields) c.set(f.field_name, (c.get(f.field_name) || 0) + 1);
    return new Set([...c].filter(([, n]) => n > 1).map(([k]) => k));
  }, [targetFields]);
  const [tgtQuery, setTgtQuery] = useState("");
  // Refs to source/target cards keyed by name/id so we can read their DOM positions
  const sourceRefs = useRef<Map<string, HTMLDivElement>>(new Map());
  const targetRefs = useRef<Map<number, HTMLDivElement>>(new Map());
  const canvasRef = useRef<HTMLDivElement>(null);

  // Positions to draw lines (re-measured after layout changes)
  const [lines, setLines] = useState<{ id: number; x1: number; y1: number; x2: number; y2: number; mapping: MappingSuggestion }[]>([]);

  const recalc = () => {
    if (!canvasRef.current) return;
    const canvasRect = canvasRef.current.getBoundingClientRect();
    const next: typeof lines = [];
    for (const m of mappings) {
      if (!m.source_column) continue;
      if (!visibleTargetIds.has(m.target_field_id)) continue;
      const src = sourceRefs.current.get(m.source_column);
      const tgt = targetRefs.current.get(m.target_field_id);
      if (!src || !tgt) continue;
      const sr = src.getBoundingClientRect();
      const tr = tgt.getBoundingClientRect();
      next.push({
        id: m.id,
        x1: sr.right - canvasRect.left,
        y1: sr.top + sr.height / 2 - canvasRect.top,
        x2: tr.left - canvasRect.left,
        y2: tr.top + tr.height / 2 - canvasRect.top,
        mapping: m,
      });
    }
    setLines(next);
  };

  useLayoutEffect(() => { recalc(); }, [mappings, visibleTargetIds, sourceColumns, targetFields, srcQuery, tgtQuery]);

  // Recalc on scroll/resize — both the source and target lists scroll independently
  const onScroll = () => recalc();

  useEffect(() => {
    const obs = new ResizeObserver(() => recalc());
    if (canvasRef.current) obs.observe(canvasRef.current);
    window.addEventListener("resize", recalc);
    return () => { obs.disconnect(); window.removeEventListener("resize", recalc); };
  }, []);

  // Sort source columns: mapped first
  const sortedSources = useMemo(() => {
    const used = new Set(mappings.filter((m) => m.source_column).map((m) => m.source_column));
    return [...sourceColumns].sort((a, b) => {
      const ua = used.has(a.column_name) ? 0 : 1;
      const ub = used.has(b.column_name) ? 0 : 1;
      if (ua !== ub) return ua - ub;
      return a.position - b.position;
    });
  }, [sourceColumns, mappings]);

  // Apply the live source filter (name, type, or sample value match).
  const shownSources = useMemo(() => {
    const q = srcQuery.trim().toLowerCase();
    if (!q) return sortedSources;
    return sortedSources.filter((c) =>
      c.column_name.toLowerCase().includes(q) ||
      (c.inferred_type || "").toLowerCase().includes(q) ||
      (c.sample_values || []).some((v) => String(v).toLowerCase().includes(q))
    );
  }, [sortedSources, srcQuery]);

  // Sort target fields: required first, then by sequence
  const sortedTargets = useMemo(() => [...targetFields].sort((a, b) => {
    if (a.required !== b.required) return a.required ? -1 : 1;
    return a.sequence - b.sequence;
  }), [targetFields]);

  // Apply the live target filter (field name or data type match).
  const shownTargets = useMemo(() => {
    const q = tgtQuery.trim().toLowerCase();
    if (!q) return sortedTargets;
    return sortedTargets.filter((f) =>
      (f.field_name || "").toLowerCase().includes(q) ||
      (f.data_type || "").toLowerCase().includes(q)
    );
  }, [sortedTargets, tgtQuery]);

  return (
    <div ref={canvasRef} className="relative flex flex-1 overflow-hidden bg-canvas">
      {/* SVG overlay drawing curves between cards */}
      <svg className="pointer-events-none absolute inset-0 z-10 h-full w-full">
        <defs>
          <marker id="arrow-success" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#10B981" />
          </marker>
          <marker id="arrow-warning" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#F59E0B" />
          </marker>
          <marker id="arrow-danger" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#EF4444" />
          </marker>
          <marker id="arrow-brand" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#6366F1" />
          </marker>
        </defs>
        {lines.map((l) => {
          const m = l.mapping;
          const isApproved = m.status === "approved" || m.status === "overridden";
          const isRejected = m.status === "rejected";
          const tone = isApproved ? "brand" :
                       isRejected ? "danger" :
                       confidenceTone(m.confidence);
          const stroke = { success: "#10B981", warning: "#F59E0B", danger: "#EF4444", brand: "#6366F1" }[tone];
          const dash = isApproved ? undefined :
                       isRejected ? "6 4" : undefined;
          const isSel = selectedMappingId === m.id;
          const isHovered = hoveredSource === m.source_column ||
                           hoveredTarget === m.target_field_id;
          // Bezier control points — clean curve from right of source to left of target
          const dx = (l.x2 - l.x1) * 0.5;
          const path = `M ${l.x1} ${l.y1} C ${l.x1 + dx} ${l.y1}, ${l.x2 - dx} ${l.y2}, ${l.x2} ${l.y2}`;
          return (
            <g key={l.id} className="pointer-events-auto">
              {/* invisible thicker hit area */}
              <path d={path} stroke="transparent" strokeWidth={14} fill="none"
                onClick={() => setSelectedMappingId(m.id)}
                style={{ cursor: "pointer" }}
              />
              <path
                d={path}
                stroke={stroke}
                strokeWidth={isSel || isHovered ? 2.5 : 1.5}
                strokeDasharray={dash}
                fill="none"
                opacity={isSel || isHovered ? 1 : 0.55}
                markerEnd={`url(#arrow-${tone})`}
              />
            </g>
          );
        })}
      </svg>

      {/* Source columns */}
      <div className="flex w-[320px] flex-col border-r border-line bg-white">
        <div className="flex items-center justify-between border-b border-line bg-canvas px-3 py-2">
          <div className="text-[10.5px] font-semibold uppercase tracking-wider text-ink-muted">
            Source · {shownSources.length}{srcQuery && <span className="text-ink-subtle"> / {sortedSources.length}</span>}
            <span className="ml-1.5 normal-case font-normal text-ink-subtle">· drag onto a target to map</span>
          </div>
          {loading && <Spinner />}
        </div>
        <div className="border-b border-line bg-white px-2 py-1.5">
          <input
            value={srcQuery}
            onChange={(e) => setSrcQuery(e.target.value)}
            placeholder="Filter source columns…"
            className="w-full rounded-md border border-line bg-canvas px-2.5 py-1.5 text-[12px] text-ink placeholder:text-ink-subtle focus:border-brand focus:outline-none"
          />
        </div>
        <div className="flex-1 overflow-y-auto p-2" onScroll={onScroll}>
          {shownSources.length === 0 && (
            <div className="px-2 py-6 text-center text-[11px] text-ink-subtle">No source columns match “{srcQuery}”.</div>
          )}
          {shownSources.map((c) => {
            const mapping = mappings.find((m) => m.source_column === c.column_name);
            const isMapped = !!mapping;
            const tone = mapping ?
              (mapping.status === "approved" ? "success" : confidenceTone(mapping.confidence)) :
              "neutral";
            return (
              <div
                key={c.id}
                ref={(el) => { if (el) sourceRefs.current.set(c.column_name, el); else sourceRefs.current.delete(c.column_name); }}
                draggable
                onDragStart={(e) => {
                  setDragSource(c.column_name);
                  e.dataTransfer.setData("text/plain", c.column_name);
                  e.dataTransfer.effectAllowed = "link";
                }}
                onDragEnd={() => { setDragSource(null); setDropTargetId(null); }}
                onClick={() => mapping && setSelectedMappingId(mapping.id)}
                onMouseEnter={() => setHoveredSource(c.column_name)}
                onMouseLeave={() => setHoveredSource(null)}
                title="Drag onto a target field to map it"
                className={cn(
                  "mb-1 cursor-grab rounded-md border bg-white px-2.5 py-2 transition active:cursor-grabbing",
                  dragSource === c.column_name ? "border-brand ring-2 ring-brand/30 opacity-60" :
                  hoveredSource === c.column_name ? "border-brand bg-brand-subtle/40 shadow-soft" :
                  isMapped ? "border-line" : "border-line/60 opacity-80",
                )}
              >
                <div className="flex items-center gap-1.5">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <div className="truncate text-[12px] font-semibold text-ink">{c.column_name}</div>
                      {c.contains_pii ? (
                        <span
                          className="inline-flex items-center gap-0.5 rounded-full bg-danger/10 px-1 py-0.5 text-[8.5px] font-semibold text-danger"
                          title={`Sensitive · ${c.pii_category || "PII"} — must be pseudonymised before load`}
                        >
                          <PiiLockGlyph /> {c.pii_category || "PII"}
                        </span>
                      ) : null}
                    </div>
                    <div className="font-mono text-[10px] text-ink-muted">
                      {c.inferred_type}
                      {c.distinct_count > 0 && ` · ${c.distinct_count} distinct`}
                      {c.null_percent > 0 && (
                        <span className="text-warning"> · {c.null_percent}% null</span>
                      )}
                    </div>
                  </div>
                  {isMapped && (
                    <span className={cn(
                      "inline-block h-2 w-2 rounded-full shrink-0",
                      tone === "success" ? "bg-success" :
                      tone === "warning" ? "bg-warning" : "bg-danger"
                    )} />
                  )}
                </div>
                {(c.sample_values || []).length > 0 && (
                  <div className="mt-1 truncate font-mono text-[10px] text-ink-subtle">
                    {(c.sample_values || []).slice(0, 3).map((v) => String(v)).join(" · ")}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Spacer where lines render — lines live in the absolute SVG above */}
      <div className="flex-1" />

      {/* Target FBDI fields */}
      <div className="flex w-[360px] flex-col border-l border-line bg-white">
        <div className="border-b border-line bg-canvas px-3 py-2 text-[10.5px] font-semibold uppercase tracking-wider text-ink-muted">
          Target FBDI · {shownTargets.length}{tgtQuery && <span className="text-ink-subtle"> / {sortedTargets.length}</span>}
        </div>
        <div className="border-b border-line bg-white px-2 py-1.5">
          <input
            value={tgtQuery}
            onChange={(e) => setTgtQuery(e.target.value)}
            placeholder="Filter target FBDI fields…"
            className="w-full rounded-md border border-line bg-canvas px-2.5 py-1.5 text-[12px] text-ink placeholder:text-ink-subtle focus:border-brand focus:outline-none"
          />
        </div>
        <div className="flex-1 overflow-y-auto p-2" onScroll={onScroll}>
          {shownTargets.length === 0 && (
            <div className="px-2 py-6 text-center text-[11px] text-ink-subtle">No target fields match “{tgtQuery}”.</div>
          )}
          {shownTargets.map((f) => {
            const mapping = mappings.find((m) => m.target_field_id === f.id);
            const visible = visibleTargetIds.has(f.id);
            return (
              <div
                key={f.id}
                ref={(el) => { if (el) targetRefs.current.set(f.id, el); }}
                onClick={() => mapping && setSelectedMappingId(mapping.id)}
                onMouseEnter={() => setHoveredTarget(f.id)}
                onMouseLeave={() => setHoveredTarget(null)}
                onDragOver={(e) => {
                  if (!onMapDrop) return;
                  e.preventDefault();
                  e.dataTransfer.dropEffect = "link";
                  if (dropTargetId !== f.id) setDropTargetId(f.id);
                }}
                onDragLeave={() => setDropTargetId((cur) => (cur === f.id ? null : cur))}
                onDrop={(e) => {
                  e.preventDefault();
                  const col = e.dataTransfer.getData("text/plain");
                  setDropTargetId(null);
                  setDragSource(null);
                  if (col && onMapDrop) onMapDrop(f.id, col);
                }}
                className={cn(
                  "mb-1 cursor-pointer rounded-md border bg-white px-2.5 py-2 transition",
                  !visible && "opacity-30",
                  dropTargetId === f.id ? "border-emerald-500 ring-2 ring-emerald-300 bg-emerald-50" :
                  hoveredTarget === f.id ? "border-brand bg-brand-subtle/40 shadow-soft" :
                  mapping?.status === "approved" ? "border-success/50 bg-success-subtle/30" :
                  mapping?.source_column ? "border-line" : "border-dashed border-line",
                )}
              >
                <div className="flex items-center gap-1.5">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <div className="truncate text-[12px] font-semibold text-ink">{f.field_name}</div>
                      {f.sheet_name && dupNames.has(f.field_name) && (
                        <span className="shrink-0 rounded bg-canvas px-1 py-0.5 font-mono text-[9px] font-normal text-ink-subtle" title={`Interface sheet: ${f.sheet_name}`}>{f.sheet_name}</span>
                      )}
                      {f.required && (
                        <span className="rounded bg-danger-subtle px-1 py-0.5 font-mono text-[9px] font-bold text-danger">REQ</span>
                      )}
                      {mapping?.kb_source && mapping.status === "suggested" && (
                        <span
                          className="inline-flex items-center gap-0.5 rounded bg-brand-subtle px-1 py-0.5 font-mono text-[9px] font-bold text-brand-dark"
                          title={`Pre-filled from ${KB_SOURCE_DISPLAY[mapping.kb_source] || mapping.kb_source} Knowledge Bank · ${(mapping.kb_times_reused ?? 0)} prior reuse${(mapping.kb_times_reused ?? 0) === 1 ? "" : "s"}`}
                        >
                          🧠 KB
                        </span>
                      )}
                      {ruleTargetIds?.has(f.id) && (
                        <span
                          className="inline-flex items-center gap-0.5 rounded bg-violet-100 px-1 py-0.5 font-mono text-[9px] font-bold text-violet-700"
                          title="A transformation rule is attached to this field — it applies during Generate Output"
                        >
                          ƒ rule
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 font-mono text-[10px] text-ink-muted">
                      <span>
                        {f.data_type || "Character"}
                        {f.max_length && ` (${f.max_length})`}
                      </span>
                      {(() => {
                        // Which decision layer produced this field — the same
                        // classification the table view and the precedence bar use.
                        const key = classifyLayer(mapping, f, effectiveDefaults, !!ruleTargetIds?.has(f.id), suppressedFields);
                        if (key === "unmapped") return null;
                        const meta = LAYER_META[key];
                        return (
                          <span
                            title={meta.blurb}
                            className="inline-flex items-center gap-1 rounded-full border border-line bg-white px-1.5 py-0 font-sans text-[9px] text-ink"
                          >
                            <span className={cn("h-1.5 w-1.5 rounded-full", LAYER_DOT[key])} />
                            {meta.label}
                          </span>
                        );
                      })()}
                    </div>
                  </div>
                  {mapping && (
                    <Pill tone={statusTone(mapping.status)} className="!text-[9px]">
                      {mapping.status === "suggested" ? `${Math.round(mapping.confidence * 100)}%` :
                       mapping.status}
                    </Pill>
                  )}
                  {mapping?.source_column && onUnmap && (
                    <button
                      onClick={(e) => { e.stopPropagation(); onUnmap(mapping); }}
                      title={`Clear mapping (${mapping.source_column})`}
                      className="shrink-0 rounded p-0.5 text-ink-subtle hover:bg-danger-subtle hover:text-danger"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  )}
                </div>
                {!mapping?.source_column && (() => {
                  const dv = defaultFor(mapping, f.field_name, effectiveDefaults, suppressedFields);
                  if (dv) {
                    return (
                      <div className="mt-1 inline-flex items-center gap-1 text-[10px] text-emerald-600">
                        <Sparkles className="h-2.5 w-2.5" /> Defaulted → {dv}
                      </div>
                    );
                  }
                  if (f.required) {
                    return (
                      <div className="mt-1 inline-flex items-center gap-1 text-[10px] text-danger">
                        <AlertTriangle className="h-2.5 w-2.5" /> Required field unmapped
                      </div>
                    );
                  }
                  return null;
                })()}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// ─────── AI value-map (LOV crosswalk) recommendations for the selected field ───────
// The VRS requirement: don't map on column names alone — compare the DATA in
// the source column against the destination's list of values and recommend the
// translation pairs (Retire→Inactive, "MRP Planned"→3, Days of Supply→Days of
// cover ...). Unresolved values surface as exceptions needing manual mapping.
const methodLabel: Record<string, string> = {
  exact_code: "exact", exact_meaning: "meaning", synonym: "synonym",
  fuzzy: "fuzzy", learned: "learned", ai: "AI",
};

const ValueMapRecommendationsPanel: React.FC<{
  mapping: MappingSuggestion;
  onApplied?: () => void;
}> = ({ mapping, onApplied }) => {
  const [loading, setLoading] = useState(false);
  const [applying, setApplying] = useState(false);
  const [recs, setRecs] = useState<any | null>(null);
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const [appliedMsg, setAppliedMsg] = useState<string | null>(null);

  useEffect(() => { setRecs(null); setSelected({}); setAppliedMsg(null); }, [mapping.id]);

  const lov = mapping.target_lov || [];
  // Show for any mapped field: with a stored LOV we resolve deterministically,
  // and without one the AI still normalizes values to standard Fusion codes.
  if (!mapping.source_column) return null;

  const load = async () => {
    setLoading(true); setAppliedMsg(null);
    try {
      const r = await MappingApi.valueMapRecommendations(String(mapping.id));
      setRecs(r);
      // Pre-select every non-identity translation pair
      const sel: Record<string, boolean> = {};
      (r.recommendations || []).forEach((p: any) => { if (!p.already_valid) sel[p.source_value] = true; });
      setSelected(sel);
    } catch (e: any) {
      setRecs({ error: e?.response?.data?.detail || "Failed to load recommendations" });
    } finally { setLoading(false); }
  };

  const apply = async () => {
    if (!recs) return;
    const pairs = (recs.recommendations || [])
      .filter((p: any) => selected[p.source_value])
      .map((p: any) => ({ source_value: p.source_value, target_value: p.target_value }));
    if (!pairs.length) return;
    setApplying(true);
    try {
      const res = await MappingApi.acceptValueMap(String(mapping.id), { pairs });
      setAppliedMsg(`Applied ${res.pairs_applied} value pair${res.pairs_applied !== 1 ? "s" : ""} — saved as a VALUE_MAP rule and learned to the Crosswalk Library.`);
      setRecs(null); setSelected({});
      onApplied?.();
    } catch (e: any) {
      setAppliedMsg(e?.response?.data?.detail || "Failed to apply value map");
    } finally { setApplying(false); }
  };

  const selCount = Object.values(selected).filter(Boolean).length;

  return (
    <div className="mt-4 rounded-md border border-brand/30 bg-brand/5 p-2.5">
      <div className="flex items-center justify-between">
        <span className="inline-flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-brand-dark">
          <Sparkles className="h-3 w-3" /> {lov.length ? "Target list of values" : "AI value normalization"}
        </span>
        {mapping.target_default_if_blank && (
          <span className="text-[10px] text-ink-subtle">blank → {mapping.target_default_if_blank}</span>
        )}
      </div>
      {/* LOV chips — what the destination actually accepts (when defined) */}
      {lov.length > 0 && (
        <div className="mt-1.5 flex flex-wrap gap-1">
          {lov.map((e) => (
            <span key={e.code} title={e.meaning || e.code}
              className="rounded border border-line bg-white px-1.5 py-0.5 font-mono text-[10.5px] text-ink">
              {e.code}{e.meaning && e.meaning !== e.code ? ` · ${e.meaning}` : ""}
            </span>
          ))}
        </div>
      )}
      {!lov.length && (
        <div className="mt-1 text-[10px] text-ink-subtle">
          Claude maps this column's values to standard Oracle Fusion codes (e.g. United States → US, Kilogram → KG).
        </div>
      )}

      {!recs && !appliedMsg && (
        <button onClick={load} disabled={loading}
          className="mt-2 inline-flex items-center gap-1 rounded-md border border-brand/40 bg-white px-2 py-1 text-[11px] font-medium text-brand-dark hover:bg-brand/10 disabled:opacity-50">
          {loading ? <RefreshCw className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />}
          Recommend value mappings
        </button>
      )}

      {recs?.error && (
        <div className="mt-2 rounded border border-warning/40 bg-warning/10 px-2 py-1 text-[11px] text-ink">
          {recs.error}
        </div>
      )}

      {recs && !recs.error && (
        <div className="mt-2">
          <div className="text-[10.5px] text-ink-subtle">
            {recs.distinct_values.length} distinct source value{recs.distinct_values.length !== 1 ? "s" : ""} ·{" "}
            {Math.round((recs.coverage || 0) * 100)}% resolved to a Fusion value
          </div>
          <div className="mt-1.5 max-h-52 space-y-1 overflow-y-auto pr-0.5">
            {(recs.recommendations || []).map((p: any) => (
              <label key={p.source_value}
                className="flex cursor-pointer items-center gap-1.5 rounded border border-line bg-white px-2 py-1 text-[11px]">
                <input type="checkbox" className="h-3 w-3 accent-brand"
                  checked={!!selected[p.source_value]} disabled={p.already_valid}
                  onChange={(e) => setSelected((s) => ({ ...s, [p.source_value]: e.target.checked }))} />
                <span className="font-mono text-danger">{p.source_value}</span>
                <span className="text-ink-subtle">→</span>
                <span className="font-mono text-success">{p.target_value}</span>
                <span className="ml-auto flex items-center gap-1">
                  {p.already_valid ? (
                    <span className="rounded bg-success/10 px-1 py-0.5 text-[9.5px] font-medium text-success">already valid</span>
                  ) : (
                    <span className="rounded bg-canvas px-1 py-0.5 text-[9.5px] text-ink-muted">
                      {methodLabel[p.method] || p.method} · {Math.round(p.confidence * 100)}%
                    </span>
                  )}
                </span>
              </label>
            ))}
          </div>
          {(recs.unmatched || []).length > 0 && (
            <div className="mt-1.5 rounded border border-warning/40 bg-warning/10 px-2 py-1 text-[11px] text-ink">
              <span className="inline-flex items-center gap-1 font-medium">
                <AlertTriangle className="h-3 w-3 text-warning" /> Needs manual mapping:
              </span>{" "}
              {(recs.unmatched || []).map((v: string) => (
                <span key={v} className="mr-1 font-mono">{v}</span>
              ))}
              <div className="mt-0.5 text-[10px] text-ink-subtle">Add these below in Value mappings, or they pass through unchanged.</div>
            </div>
          )}
          <div className="mt-2 flex items-center gap-2">
            <Button onClick={apply} loading={applying} disabled={selCount === 0} className="!h-7 !px-2.5 !text-[11px]">
              Apply {selCount} selected
            </Button>
            <button onClick={() => { setRecs(null); setSelected({}); }} className="text-[11px] text-ink-subtle hover:underline">
              Cancel
            </button>
          </div>
        </div>
      )}

      {appliedMsg && (
        <div className="mt-2 flex items-start gap-1.5 rounded border border-success/40 bg-success/10 px-2 py-1 text-[11px] text-ink">
          <Check className="mt-0.5 h-3 w-3 shrink-0 text-success" /> {appliedMsg}
        </div>
      )}
    </div>
  );
};

// ─────── Inline value-mapping (crosswalk) editor for the selected field ───────
const ValueMappingsPanel: React.FC<{ targetObject?: string | null; targetField?: string | null }> = ({ targetObject, targetField }) => {
  const [rows, setRows] = useState<any[]>([]);
  const [orig, setOrig] = useState("");
  const [res, setRes] = useState("");
  const [saving, setSaving] = useState(false);

  const load = () => {
    LearningApi.list({ kind: "crosswalk" })
      .then((all: any[]) => setRows(all.filter((c) =>
        (!targetObject || (c.target_object || "").toLowerCase() === String(targetObject).toLowerCase()) &&
        (!c.target_field || !targetField || String(c.target_field).toLowerCase() === String(targetField).toLowerCase())
      )))
      .catch(() => setRows([]));
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [targetObject, targetField]);

  const add = async () => {
    if (!orig.trim() || !res.trim()) return;
    setSaving(true);
    try {
      await LearningApi.capture({
        kind: "crosswalk",
        category: `Value Mapping — ${targetField || targetObject || "field"}`,
        original_value: orig.trim(),
        resolved_value: res.trim(),
        target_object: targetObject || undefined,
        target_field: targetField || undefined,
      } as any);
      setOrig(""); setRes(""); load();
    } finally { setSaving(false); }
  };

  return (
    <div className="mt-4 rounded-md border border-line bg-canvas/60 p-2.5">
      <div className="flex items-center justify-between">
        <span className="inline-flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-ink-muted">
          <ArrowLeftRight className="h-3 w-3" /> Value mappings (crosswalk)
        </span>
        <span className="text-[10px] text-ink-subtle">{rows.length}</span>
      </div>
      <div className="mt-0.5 text-[10.5px] leading-snug text-ink-subtle">
        Translate legacy values into Fusion values for this field. Saved to the Crosswalk Library and reused at output generation.
      </div>

      {rows.length > 0 && (
        <div className="mt-2 space-y-1">
          {rows.map((c) => (
            <div key={c.id} className="flex items-center gap-1.5 rounded border border-line bg-white px-2 py-1 text-[11px]">
              <span className="font-mono text-danger">{c.original_value}</span>
              <span className="text-ink-subtle">→</span>
              <span className="font-mono text-success">{c.resolved_value}</span>
              <button
                onClick={async () => { await LearningApi.delete(c.id); load(); }}
                className="ml-auto rounded p-0.5 text-ink-subtle hover:bg-canvas hover:text-danger"
                title="Remove value mapping"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="mt-2 flex items-center gap-1.5">
        <input className="input !h-7 !text-[11px]" placeholder="legacy" value={orig} onChange={(e) => setOrig(e.target.value)} />
        <span className="text-ink-subtle">→</span>
        <input className="input !h-7 !text-[11px]" placeholder="Fusion" value={res} onChange={(e) => setRes(e.target.value)} />
        <Button onClick={add} loading={saving} disabled={!orig.trim() || !res.trim()} className="!h-7 shrink-0 !px-2 !text-[11px]">Add</Button>
      </div>
    </div>
  );
};

// ─────── Alternative source-column candidates for a target field ───────
// Shows the ranked source columns the AI could map this target to, so the
// reviewer can pick a different one for flexibility. The top pick is the
// current auto-mapping; the rest are alternatives.
const AlternativeCandidatesPanel: React.FC<{
  conversionId: string;
  targetFieldId: number | string;
  currentSource: string | null;
  onPick: (sourceColumn: string) => void;
  /** Verdicts the toolbar "Vet options with AI" already produced for this field. */
  cachedVerdicts?: Record<string, { verdict: string; reason: string }>;
  onAiVerdicts?: (m: Record<string, Record<string, { verdict: string; reason: string }>>) => void;
}> = ({ conversionId, targetFieldId, currentSource, onPick, cachedVerdicts, onAiVerdicts }) => {
  const [cands, setCands] = useState<MappingCandidate[] | null>(null);
  const [open, setOpen] = useState(true);
  const [loading, setLoading] = useState(false);
  const [vetting, setVetting] = useState(false);
  const [vetMsg, setVetMsg] = useState<string | null>(null);

  // Fold cached AI verdicts (from the toolbar run) into the candidates and re-sort,
  // so a field the toolbar already vetted shows its reasons immediately — no click.
  const applyVerdicts = (
    list: MappingCandidate[], verdicts?: Record<string, { verdict: string; reason: string }>,
  ): MappingCandidate[] => {
    if (!verdicts) return list;
    const merged = list.map((c) => {
      const v = verdicts[c.source_column];
      return v ? { ...c, ai_verdict: v.verdict, ai_reason: v.reason } : c;
    });
    const rank = (c: MappingCandidate) =>
      c.ai_verdict === "wrong" ? 2 : c.ai_verdict === "unlikely" ? 1 : (c.plausible === false ? 1 : 0);
    return [...merged].sort((a, b) => rank(a) - rank(b) || (b.confidence || 0) - (a.confidence || 0));
  };

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setCands(null);
    setVetMsg(null);
    MappingApi.candidates(conversionId, { targetFieldId: String(targetFieldId), topN: 6 })
      .then((groups) => {
        if (!alive) return;
        const base = groups[0]?.candidates ?? [];
        const withCached = applyVerdicts(base, cachedVerdicts);
        setCands(withCached);
        if (cachedVerdicts && Object.keys(cachedVerdicts).length) {
          setVetMsg("AI reasons from the last review shown.");
        }
      })
      .catch(() => { if (alive) setCands([]); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
    // re-run if the toolbar vets this field while the panel is open
  }, [conversionId, targetFieldId, cachedVerdicts]);

  // Vet just THIS field's candidates. only_uncertain=false so every option gets a
  // verdict (it is one field — cheap), then fold the verdicts back in and re-sort
  // so the panel's recommendations reflect the AI review, not only the table.
  const vetThisField = async () => {
    // Already reviewed? Don't spend tokens again — just say so.
    if ((cands || []).some((c) => c.ai_verdict)) {
      setVetMsg("This field was already reviewed by AI — reasons are shown.");
      return;
    }
    setVetting(true); setVetMsg(null);
    try {
      const r = await MappingApi.vetCandidates(conversionId, {
        topN: 6, onlyUncertain: false, targetFieldIds: [String(targetFieldId)],
      });
      const verdicts = r.ai[String(targetFieldId)] || {};
      setCands((prev) => applyVerdicts(r.groups[0]?.candidates ?? prev ?? [], verdicts));
      // save into the page cache so it survives closing/reopening this field
      onAiVerdicts?.(r.ai || {});
      setVetMsg(r.vetted > 0 ? `AI reviewed ${r.vetted} option(s).` : "AI review unavailable — deterministic reasons shown.");
    } catch {
      setVetMsg("AI review unavailable — deterministic reasons shown.");
    } finally { setVetting(false); }
  };

  return (
    <div className="mt-4 rounded-md border border-line bg-canvas/60">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between px-3 py-2 text-left"
      >
        <span className="inline-flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-ink-muted">
          <ArrowLeftRight className="h-3 w-3" /> Alternative source columns
        </span>
        <ChevronDown className={cn("h-3.5 w-3.5 text-ink-muted transition", open ? "" : "-rotate-90")} />
      </button>
      {open && (
        <div className="px-3 pb-3">
          <div className="mb-2 flex items-center justify-between gap-2">
            {(() => {
              const done = (cands || []).some((c) => c.ai_verdict);
              return (
                <button
                  onClick={vetThisField}
                  disabled={vetting || loading}
                  title={done
                    ? "Already reviewed by AI — reasons are shown. No tokens will be used."
                    : "Ask AI to judge these options and explain why each does or doesn't fit"}
                  className={cn(
                    "inline-flex items-center gap-1 rounded border px-2 py-0.5 text-[10px] font-semibold disabled:opacity-50",
                    done ? "border-success/40 bg-success-subtle text-success"
                      : "border-brand/40 bg-brand-subtle text-brand hover:bg-brand/10",
                  )}
                >
                  {vetting ? <Spinner /> : done ? <Check className="h-2.5 w-2.5" /> : <Sparkles className="h-2.5 w-2.5" />}
                  {vetting ? "Reviewing…" : done ? "AI review done" : "Vet with AI"}
                </button>
              );
            })()}
            {vetMsg && <span className="text-[10px] text-ink-subtle">{vetMsg}</span>}
          </div>
          {loading ? (
            <div className="flex items-center gap-2 py-2 text-[11px] text-ink-muted">
              <Spinner /> Ranking candidates…
            </div>
          ) : (cands || []).length === 0 ? (
            <div className="py-1 text-[11px] text-ink-subtle">No alternative source columns scored above zero.</div>
          ) : (
            <div className="space-y-1.5">
              {(cands || []).map((c) => {
                const isCurrent = currentSource && c.source_column === currentSource;
                const pct = Math.round((c.confidence || 0) * 100);
                const bad = c.plausible === false || c.ai_verdict === "wrong" || c.ai_verdict === "unlikely";
                const aiLine = c.ai_reason
                  ? `${c.ai_verdict ? c.ai_verdict.toUpperCase() + ": " : ""}${c.ai_reason}`
                  : "";
                return (
                  <div
                    key={c.source_column}
                    className={cn(
                      "rounded-md border px-2.5 py-1.5",
                      isCurrent ? "border-brand/50 bg-brand-subtle/40"
                        : bad ? "border-danger/40 bg-danger-subtle/40" : "border-line bg-white",
                    )}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          {bad && <AlertTriangle className="h-3 w-3 shrink-0 text-danger" />}
                          <code className={cn("truncate rounded bg-canvas px-1.5 py-0.5 text-[11px] text-ink", bad && "line-through decoration-danger/50")}>{c.source_column}</code>
                          {isCurrent && <Pill tone="brand">current</Pill>}
                          {c.ai_reason && <Sparkles className="h-2.5 w-2.5 shrink-0 text-brand" />}
                        </div>
                        <div className="mt-0.5 flex items-center gap-2 text-[10px] text-ink-subtle">
                          <span className="font-mono tabular-nums">{pct}%</span>
                          {c.inferred_type && <span>· {c.inferred_type}</span>}
                          <span>· {Math.round(100 - (c.null_percent || 0))}% filled</span>
                        </div>
                      </div>
                      {!isCurrent && (
                        <button
                          onClick={() => onPick(c.source_column)}
                          className="shrink-0 rounded border border-brand/40 px-2 py-0.5 text-[11px] font-medium text-brand-dark hover:bg-brand-subtle"
                        >
                          Use
                        </button>
                      )}
                    </div>
                    {/* AI verdict takes precedence; else the guard caution; else the deterministic reasons */}
                    {aiLine ? (
                      <div className={cn("mt-1 text-[10px] leading-snug", bad ? "text-danger" : "text-brand-dark")}>{aiLine}</div>
                    ) : bad && c.caution ? (
                      <div className="mt-1 text-[10px] leading-snug text-danger">implausible — {c.caution}</div>
                    ) : c.reasons?.length > 0 ? (
                      <div className="mt-1 text-[10px] leading-snug text-ink-muted">{c.reasons.join(" · ")}</div>
                    ) : null}
                    {c.sample_values?.length > 0 && (
                      <div className="mt-1 flex flex-wrap gap-1">
                        {c.sample_values.slice(0, 3).map((v, i) => (
                          <span key={i} className="rounded bg-canvas px-1.5 py-0.5 font-mono text-[10px] text-ink-muted">{String(v)}</span>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// ─────── Side inspector for a selected mapping ───────

const MappingInspector: React.FC<{
  mapping: MappingSuggestion;
  sourceColumns: DatasetDetail["columns"];
  conversionId: string;
  onClose: () => void;
  onApprove: (m: MappingSuggestion) => void;
  onReject: (m: MappingSuggestion) => void;
  onOverride: (m: MappingSuggestion, src: string) => void;
  onAddCustomRule: (m: MappingSuggestion) => void;
  onResetDefault?: (fieldName: string) => void;
  onSetFixedValue?: (m: MappingSuggestion, value: string) => void;
  onKeepBlank?: (m: MappingSuggestion) => void;
  targetObject?: string | null;
  aiVerdicts?: Record<string, Record<string, { verdict: string; reason: string }>>;
  onAiVerdicts?: (m: Record<string, Record<string, { verdict: string; reason: string }>>) => void;
}> = ({ mapping, sourceColumns, conversionId, onClose, onApprove, onReject, onOverride, onAddCustomRule, onResetDefault, onSetFixedValue, onKeepBlank, targetObject, aiVerdicts, onAiVerdicts }) => {
  const [fixedVal, setFixedVal] = useState("");
  useEffect(() => { setFixedVal(mapping.source_column ? "" : (mapping.default_value ?? "")); }, [mapping.id]);
  const [editingOverride, setEditingOverride] = useState(false);
  const [override, setOverride] = useState(mapping.source_column || "");
  const [vmRefresh, setVmRefresh] = useState(0);

  useEffect(() => { setOverride(mapping.source_column || ""); setEditingOverride(false); }, [mapping.id]);

  const tone = confidenceTone(mapping.confidence);
  const cb = { success: "bg-success", warning: "bg-warning", danger: "bg-danger" }[tone];
  const conf = Math.round(mapping.confidence * 100);

  return (
    <aside className="flex w-[400px] shrink-0 flex-col border-l border-line bg-white">
      <div className="flex items-center justify-between border-b border-line px-4 py-2.5">
        <div className="min-w-0 flex-1">
          <div className="text-[10.5px] font-semibold uppercase tracking-wider text-ink-muted">Mapping</div>
          <div className="truncate text-sm font-semibold text-ink">{mapping.target_field_name}</div>
        </div>
        <button onClick={onClose} className="rounded p-1 text-ink-muted hover:bg-canvas hover:text-ink">
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4">
        {/* Source / Target */}
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div>
            <div className="text-[10px] font-semibold uppercase tracking-wider text-ink-muted">Source</div>
            <div className="mt-1 rounded-md border border-line bg-canvas px-2.5 py-2">
              <div className="flex items-center gap-1.5">
                <div className="font-mono text-[12px] text-ink">{mapping.source_column || "— (none)"}</div>
                {(() => {
                  const col = sourceColumns.find((c) => c.column_name === mapping.source_column);
                  return col?.contains_pii ? (
                    <span
                      className="inline-flex items-center gap-0.5 rounded-full bg-danger/10 px-1.5 py-0.5 text-[9.5px] font-semibold text-danger"
                      title={`Sensitive · ${col.pii_category || "PII"} — must be pseudonymised before load`}
                    >
                      <Lock className="h-2.5 w-2.5" /> {col.pii_category || "PII"}
                    </span>
                  ) : null;
                })()}
              </div>
            </div>
          </div>
          <div>
            <div className="text-[10px] font-semibold uppercase tracking-wider text-ink-muted">Target</div>
            <div className="mt-1 rounded-md border border-line bg-canvas px-2.5 py-2">
              <div className="font-mono text-[12px] text-ink">{mapping.target_field_name}</div>
              <div className="mt-0.5 flex items-center gap-1.5 font-mono text-[10px] text-ink-muted">
                {mapping.target_data_type}{mapping.target_max_length ? ` (${mapping.target_max_length})` : ""}
                {mapping.target_required && <span className="text-danger">required</span>}
              </div>
            </div>
          </div>
        </div>

        {/* Gold-derived constant default — offer to remove it. A value like
            Country → AE captured from one client's gold is wrong for the next; this
            forgets the object rule and blanks the field so it can be re-mapped. */}
        {!mapping.source_column && mapping.default_value && onResetDefault && (
          <div className="mt-4 rounded-md border border-warning/30 bg-warning-subtle/40 px-3 py-2 text-xs">
            <div className="flex items-center justify-between gap-2">
              <div className="text-ink">
                Filled with a constant default{" "}
                <span className="font-mono font-semibold">{mapping.default_value}</span>.
                <div className="mt-0.5 text-[11px] text-ink-muted">
                  If a gold file baked this in and it's wrong here, remove it.
                </div>
              </div>
              <button
                onClick={() => onResetDefault(mapping.target_field_name || "")}
                className="shrink-0 rounded-md border border-warning/50 bg-white px-2 py-1 text-[11px] font-medium text-warning-dark hover:bg-warning-subtle"
              >
                Remove default
              </button>
            </div>
          </div>
        )}

        {/* Fixed value — write a constant into every row for this field. Use for
            codes the user maintains by hand (Country = AE, Supplier Type =
            SUPPLIER, Business Relationship = SPEND_AUTHORIZED, etc.). Setting a
            fixed value clears the source column so the constant wins over AI. */}
        {onSetFixedValue && (
          <div className="mt-4 rounded-md border border-brand/30 bg-brand-subtle/20 px-3 py-2.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1 text-[10.5px] font-semibold uppercase tracking-wider text-brand-dark">
                <Edit2 className="h-3 w-3" /> Fixed value
              </span>
              {!mapping.source_column && mapping.default_value && (
                <Pill tone="brand">currently “{mapping.default_value}”</Pill>
              )}
            </div>
            <div className="mt-1 text-[11px] leading-snug text-ink-muted">
              Write one constant into this column for every row (e.g. a country
              or code you maintain by hand). This overrides AI and clears the
              source column.
            </div>
            <div className="mt-2 flex items-center gap-1.5">
              <input
                className="input !h-8 flex-1 !text-xs"
                placeholder="e.g. AE, CORPORATION, SPEND_AUTHORIZED"
                value={fixedVal}
                onChange={(e) => setFixedVal(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && fixedVal.trim()) onSetFixedValue(mapping, fixedVal); }}
              />
              <button
                onClick={() => onSetFixedValue(mapping, fixedVal)}
                disabled={!fixedVal.trim()}
                className="shrink-0 rounded-md border border-brand/50 bg-brand px-2.5 py-1 text-[11px] font-medium text-white hover:bg-brand-dark disabled:cursor-not-allowed disabled:opacity-40"
              >
                Set fixed value
              </button>
              {!mapping.source_column && mapping.default_value && (
                <button
                  onClick={() => { setFixedVal(""); onSetFixedValue(mapping, ""); }}
                  className="shrink-0 rounded-md border border-line bg-white px-2 py-1 text-[11px] font-medium text-ink-muted hover:bg-canvas"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Keep blank — the third state, and the one that was missing. Clearing
                a fixed value only leaves the field open, so a control default or the
                AI refills it on the next generate; that is exactly how Batch ID kept
                shipping 900001 after it had been "blanked". This states the decision:
                suppress the column, and remember it everywhere. */}
            {onKeepBlank && (
              <div className="mt-2.5 border-t border-brand/20 pt-2.5">
                {mapping.status === "not_applicable" &&
                 !mapping.source_column && !mapping.default_value ? (
                  <div className="flex items-center gap-1.5 text-[11px] font-medium text-success-dark">
                    <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                    Kept blank — this column ships empty in every output.
                  </div>
                ) : (
                  <div className="flex items-start justify-between gap-2">
                    <div className="text-[11px] leading-snug text-ink-muted">
                      Or ship this column <span className="font-medium text-ink">empty</span> —
                      no source, no default, and no control default refilling it later.
                      Saved to learning so every current and future conversion inherits it.
                    </div>
                    <button
                      onClick={() => onKeepBlank(mapping)}
                      className="shrink-0 rounded-md border border-line bg-white px-2.5 py-1 text-[11px] font-medium text-ink hover:bg-canvas"
                    >
                      Keep blank
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Knowledge Bank provenance — shown only when the row came from a
            prior project on the same source ERP. */}
        {mapping.kb_source && (
          <div className="mt-4 rounded-md border border-brand/30 bg-brand-subtle/30 px-3 py-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1 text-[10.5px] font-semibold uppercase tracking-wider text-brand-dark">
                🧠 From {KB_SOURCE_DISPLAY[mapping.kb_source] || mapping.kb_source} Knowledge Bank
              </span>
              <span className="font-mono text-[10.5px] text-brand-dark">
                {(mapping.kb_times_reused ?? 0)} prior reuse{(mapping.kb_times_reused ?? 0) === 1 ? "" : "s"}
              </span>
            </div>
            <div className="mt-1 leading-snug text-ink">
              This source → target pair was approved on a prior {KB_SOURCE_DISPLAY[mapping.kb_source] || mapping.kb_source} engagement. Confirm it
              fits this customer before approving — the Knowledge Bank pre-fills, it doesn't auto-approve.
            </div>
          </div>
        )}

        {/* Confidence */}
        <div className="mt-4">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-semibold uppercase tracking-wider text-ink-muted">
              {mapping.kb_source ? "Knowledge Bank confidence" : "AI confidence"}
            </span>
            <span className="font-mono text-xs tabular-nums">{conf}%</span>
          </div>
          <div className="mt-1 h-2 overflow-hidden rounded-full bg-line">
            <div className={cn("h-full rounded-full", cb)} style={{ width: `${conf}%` }} />
          </div>
        </div>

        {/* Reason */}
        {mapping.reason && (
          <div className="mt-4 rounded-md bg-info-subtle/60 px-3 py-2 text-xs text-ink">
            <div className="flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-info">
              <Sparkles className="h-3 w-3" /> AI explanation
            </div>
            <div className="mt-1 leading-snug">{mapping.reason}</div>
          </div>
        )}

        {/* Suggested transformation */}
        {mapping.suggested_transformation && (
          <div className="mt-4 rounded-md border border-warning/30 bg-warning-subtle px-3 py-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-[10.5px] font-semibold uppercase tracking-wider text-warning">Suggested transformation</span>
              <Pill tone="warning">{mapping.suggested_transformation.rule_type}</Pill>
            </div>
            {mapping.suggested_transformation.description && (
              <div className="mt-1 text-ink-muted">{mapping.suggested_transformation.description}</div>
            )}
          </div>
        )}

        {/* Sample values */}
        {(mapping.sample_source_values || []).length > 0 && (
          <div className="mt-4">
            <div className="text-[10px] font-semibold uppercase tracking-wider text-ink-muted">Sample source values</div>
            <div className="mt-1 space-y-0.5">
              {(mapping.sample_source_values || []).slice(0, 5).map((v, i) => (
                <div key={i} className="rounded bg-canvas px-2 py-1 font-mono text-[11px] text-ink">{String(v)}</div>
              ))}
            </div>
          </div>
        )}

        {/* AI value-map recommendations against the target LOV */}
        <ValueMapRecommendationsPanel mapping={mapping} onApplied={() => setVmRefresh((n) => n + 1)} />

        {/* Value mappings (crosswalk) for this field */}
        <ValueMappingsPanel key={vmRefresh} targetObject={targetObject} targetField={mapping.target_field_name} />

        {/* Alternative source-column candidates (for flexibility) */}
        <AlternativeCandidatesPanel
          conversionId={conversionId}
          targetFieldId={mapping.target_field_id}
          currentSource={mapping.source_column}
          onPick={(src) => onOverride(mapping, src)}
          cachedVerdicts={aiVerdicts?.[String(mapping.target_field_id)]}
          onAiVerdicts={onAiVerdicts}
        />

        {/* Override editor */}
        <div className="mt-5 space-y-2">
          <button
            onClick={() => onAddCustomRule(mapping)}
            className="inline-flex items-center gap-1 text-xs font-medium text-brand-dark hover:underline"
          >
            <Sparkles className="h-3 w-3" /> Add custom transformation rule
          </button>
          {!editingOverride ? (
            <button
              onClick={() => setEditingOverride(true)}
              className="inline-flex items-center gap-1 text-xs font-medium text-brand-dark hover:underline"
            >
              <Edit2 className="h-3 w-3" /> Override source column
            </button>
          ) : (
            <div className="rounded-md border border-line bg-canvas p-2.5">
              <div className="text-[10.5px] font-semibold uppercase tracking-wider text-ink-muted">Override source</div>
              <div className="mt-1 flex items-center gap-1.5">
                <select className="input !h-8 !text-xs" value={override}
                  onChange={(e) => setOverride(e.target.value)}>
                  <option value="">— none —</option>
                  {sourceColumns.map((c) => <option key={c.id} value={c.column_name}>{c.column_name}</option>)}
                </select>
                <Button onClick={() => { onOverride(mapping, override); setEditingOverride(false); }} className="!h-8">
                  Save
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* P6 — dual-cert banner */}
      {!!mapping.requires_dual_approval && (
        <div className="border-t border-line bg-warning-subtle/60 px-4 py-2 text-[11.5px]">
          <div className="flex items-center gap-1.5 font-semibold text-warning">
            <Lock className="h-3 w-3" /> Dual-cert required
          </div>
          <div className="mt-0.5 leading-snug text-ink-muted">
            {mapping.status === "approved" ? (
              <>
                Both sign-offs captured · 1st by{" "}
                <span className="font-mono text-ink">{mapping.approved_by || "—"}</span> · 2nd by{" "}
                <span className="font-mono text-ink">{mapping.second_approver_email || "—"}</span>
              </>
            ) : mapping.approved_by ? (
              <>
                1st sign-off captured from{" "}
                <span className="font-mono text-ink">{mapping.approved_by}</span>. A{" "}
                <strong>different</strong> user must approve as 2nd sign-off
                before this mapping flips to approved.
              </>
            ) : (
              <>
                This field is on the dual-cert list (PII / SOX / customer banking).
                Two distinct approvers required.
              </>
            )}
          </div>
        </div>
      )}

      {/* Action footer */}
      <div className="border-t border-line bg-canvas px-4 py-3">
        {mapping.status === "approved" ? (
          <div className="text-center text-xs text-success">
            <Check className="mx-auto h-4 w-4" />
            {mapping.approved_by === "learning-engine" ? (
              <span className="inline-flex items-center gap-1 text-brand-dark">
                <GraduationCap className="h-3 w-3" />
                Auto-applied from learning library
              </span>
            ) : (
              <>
                Approved by {mapping.approved_by || "—"}
                {mapping.second_approver_email && (
                  <> · 2nd by {mapping.second_approver_email}</>
                )}
                <span className="ml-1 inline-flex items-center gap-1 text-brand-dark">
                  <GraduationCap className="h-3 w-3" /> Learned
                </span>
              </>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            <Button variant="secondary" onClick={() => onReject(mapping)} className="!h-8">
              <X className="h-3.5 w-3.5" /> Reject
            </Button>
            <Button variant="primary" onClick={() => onApprove(mapping)} className="!h-8">
              <Check className="h-3.5 w-3.5" /> Approve
            </Button>
          </div>
        )}
      </div>
    </aside>
  );
};
