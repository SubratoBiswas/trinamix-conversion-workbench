"""Robust Oracle FBDI template parser supporting two formats:

1. Oracle FBDI transposed format: column A has row-labels (Name/Description/Data Type),
   fields span columns B onwards.
2. Standard tabular format: row 1 has field names as column headers from col A onwards,
   prefix "* " marks required fields.

Both are then enriched from the template's HEADER-CELL COMMENTS, where Oracle states
the database rule for each column ("BATCH_ID / NOT NULL / NUMBER (18)"). That matters
most for format 2: it has no Data Type row at all, so before this the type was guessed
from whether one sample row held a number and max_length / format_mask / allowed_values
stayed empty — leaving the validation engine with almost nothing to check. See
services/template_comments.py.
"""
from __future__ import annotations
import re
from pathlib import Path
from app.parsers.xlsx_repair import load_workbook_tolerant

from app.services.lov_service import enrich_field
from app.services.template_comments import apply_to_field, constraints_by_sheet

_DATA_TYPE_RE = re.compile(r"^\s*([A-Za-z]+)\s*(?:\(\s*(\d+)(?:\s*,\s*\d+)?\s*\))?", re.IGNORECASE)


def _parse_data_type(raw):
    if not raw:
        return ("Character", None)
    m = _DATA_TYPE_RE.match(str(raw))
    if not m:
        return (str(raw).strip(), None)
    dtype = m.group(1).strip().capitalize()
    length = int(m.group(2)) if m.group(2) else None
    return (dtype, length)


def _looks_like_module_label(value):
    if not value:
        return False
    s = str(value).strip()
    keywords = ("management", "planning", "order promising", "operations", "supply", "common", "interface", "loader")
    return any(k in s.lower() for k in keywords) and len(s) < 80


def _read_sheet_rows(ws, max_rows: int = 40):
    """Read only the first ``max_rows`` rows (enough for header detection + a
    sample row). FBDI interface sheets can carry tens of thousands of sample rows;
    reading them all is slow and can exhaust memory on small instances."""
    rows = []
    for row in ws.iter_rows(values_only=True):
        rows.append(row)
        if len(rows) >= max_rows:
            break
    while rows and all(v is None for v in rows[-1]):
        rows.pop()
    return rows


def _nonempty_count(row) -> int:
    return sum(1 for v in row if v is not None and str(v).strip() != "")


def _norm_sheet(name) -> str:
    return re.sub(r"[^a-z0-9]", "", str(name or "").lower())


def _interface_sheets(sheet_names: list[str]) -> list[str]:
    """Drop the macro's CamelCase shadow copies of an interface sheet.

    Oracle's Supplier Bank workbook ships six sheets: ``IBY_TEMP_EXT_PAYEES`` and
    also ``IbyTempExtPayees``, and so on. The second set is what the workbook's own
    macro writes into when it builds the CSV — the same table under a different
    spelling, not an extra interface. Importing both created 59 phantom target fields
    that duplicate real ones under names no source column will ever match, which
    makes every coverage number look worse and gives the analyst two rows to map for
    one column.

    Keep the Oracle interface-table spelling (UPPER_SNAKE); if neither looks like
    one, keep whichever came first so behaviour is stable.
    """
    by_key: dict[str, str] = {}
    for name in sheet_names:
        key = _norm_sheet(name)
        if not key:
            continue
        kept = by_key.get(key)
        if kept is None:
            by_key[key] = name
            continue
        def _is_table(s: str) -> bool:
            s = str(s).strip()
            return "_" in s and s.upper() == s
        if _is_table(name) and not _is_table(kept):
            by_key[key] = name
    return [n for n in sheet_names if by_key.get(_norm_sheet(n)) == n]


def parse_fbdi_template(file_path):
    file_path = Path(file_path)
    # Tolerant open: Oracle's own SupplierSiteImportTemplate.xlsm carries one
    # out-of-spec <family val="34"/>, and plain openpyxl refuses the whole workbook
    # over it — so uploading a template the analyst actually has failed outright.
    wb = load_workbook_tolerant(file_path, data_only=True, read_only=True)

    # Oracle's per-column rules, read straight from the OOXML comment parts.
    # ``read_only=True`` above discards comments, and dropping it to reach a few
    # hundred strings in a 20-sheet workbook is slow enough to matter on a small
    # instance — so this is a separate, cheap pass. {} when the template has no
    # comments (the bundled Item workbook has none), which changes nothing.
    comments = constraints_by_sheet(str(file_path))

    business_object = None
    description = None

    for sname in wb.sheetnames:
        if "instruction" in sname.lower():
            ws = wb[sname]
            for row in ws.iter_rows(min_row=1, max_row=10, values_only=True):
                for cell in row:
                    if cell and isinstance(cell, str) and ":" in cell and len(cell) < 200:
                        if any(k in cell.lower() for k in ("upload:", "import:", "interface:")):
                            business_object = cell.split(":", 1)[1].strip()
                            break
                if business_object:
                    break
            break

    sheets_out = []
    fields_out = []
    seq = 0

    for sname in _interface_sheets(list(wb.sheetnames)):
        if "instruction" in sname.lower():
            continue
        ws = wb[sname]
        # This sheet's mined constraints, keyed by 1-based column index.
        sheet_cons = comments.get(sname) or {}

        # Use iter_rows to avoid max_row/max_col returning None on some openpyxl versions
        all_rows = _read_sheet_rows(ws)
        if not all_rows:
            continue
        max_row = len(all_rows)
        max_col = max((len(r) for r in all_rows), default=0)
        if max_col == 0:
            continue

        def cell_val(r, c):
            """1-based row/col access into all_rows list."""
            try:
                return all_rows[r - 1][c - 1]
            except IndexError:
                return None

        # Detect format: Oracle transposed has "Name" as a row label in col A
        col_a_labels = []
        for r in range(1, min(15, max_row + 1)):
            v = cell_val(r, 1)
            if v:
                col_a_labels.append((r, str(v).strip()))

        is_oracle_fbdi = any(lbl.lower() == "name" for _, lbl in col_a_labels)
        sheet_field_count = 0

        if is_oracle_fbdi:
            name_row = next((r for r, lbl in col_a_labels if lbl.lower() == "name"), 1)
            desc_row = next((r for r, lbl in col_a_labels if "description" in lbl.lower()), 2)
            type_row = next((r for r, lbl in col_a_labels if "data type" in lbl.lower() or lbl.lower() == "type"), 3)
            module_rows = [(r, lbl) for r, lbl in col_a_labels if r > type_row and _looks_like_module_label(lbl)]

            for col in range(2, max_col + 1):
                raw_name = cell_val(name_row, col)
                if not raw_name:
                    continue
                name = str(raw_name).strip()
                if not name:
                    continue
                is_req = name.startswith("*")
                field_name = name.lstrip("*").strip()
                desc_val = cell_val(desc_row, col)
                desc_text = str(desc_val).strip() if desc_val else None
                dtype_raw = cell_val(type_row, col)
                data_type, max_length = _parse_data_type(dtype_raw)
                req_modules = []
                for r, lbl in module_rows:
                    cv = cell_val(r, col)
                    if cv and "required" in str(cv).strip().lower():
                        req_modules.append(lbl)
                required = is_req or bool(req_modules)
                seq += 1
                sheet_field_count += 1
                # Coded column? Oracle publishes the accepted codes (and which one
                # means "no") right in the description — mine it rather than
                # letting an AI guess what belongs in a NUMBER column later.
                lov = enrich_field(field_name, desc_text)
                fields_out.append(apply_to_field({
                    "field_name": field_name,
                    # keep the raw header (with Oracle's '*' required marker) so
                    # generated output can reproduce the exact template header.
                    "display_name": name,
                    "description": desc_text,
                    "required": required,
                    "data_type": data_type,
                    "max_length": max_length,
                    "format_mask": "YYYYMMDD" if data_type.lower() == "date" else None,
                    "sample_value": None,
                    "lookup_type": lov["lookup_type"],
                    "allowed_values": lov["allowed_values"],
                    "default_if_blank": lov["default_if_blank"],
                    "validation_notes": lov["validation_notes"],
                    "sequence": seq,
                    "sheet_name": sname,
                    "required_modules": req_modules,
                }, sheet_cons.get(col)))

        else:
            # Standard tabular, but the header row isn't always row 1. Real Oracle
            # FBDI CSV-generation templates put field names on ~row 4 (blank row 1,
            # a title row, a "* Required" legend row, then the headers). Detect the
            # header row as the one with the most non-empty cells in the first 15
            # rows (earliest on ties); the sample row is the next non-empty row.
            scan = min(15, len(all_rows))
            header_idx, best_cnt = 0, -1
            for i in range(scan):
                cnt = _nonempty_count(all_rows[i])
                if cnt > best_cnt:
                    best_cnt, header_idx = cnt, i
            header_row = all_rows[header_idx] if all_rows else []
            sample_row = []
            for j in range(header_idx + 1, len(all_rows)):
                if _nonempty_count(all_rows[j]) > 0:
                    sample_row = all_rows[j]
                    break

            for col_idx, raw_name in enumerate(header_row):
                if raw_name is None:
                    continue
                name = str(raw_name).strip()
                if not name:
                    continue
                # Required is marked by a leading OR trailing "*" (e.g. "Supplier
                # Name*", "Import Action *", "*Batch ID").
                is_req = name.startswith("*") or name.endswith("*")
                field_name = name.strip("*").strip()
                if not field_name:
                    continue
                sample_val = sample_row[col_idx] if col_idx < len(sample_row) else None
                sample_text = str(sample_val).strip() if sample_val is not None else None
                # A LAST-RESORT type guess only. One sample row holding a number is
                # weak evidence and was actively harmful: a VARCHAR2(30) column of
                # numeric-looking ids became "Number" and every value then failed a
                # numeric check it should never have faced. The header comment
                # overrides this whenever Oracle stated the type (97% of columns).
                if isinstance(sample_val, (int, float)):
                    data_type, max_length = "Number", None
                else:
                    data_type, max_length = "Character", None
                seq += 1
                sheet_field_count += 1
                fields_out.append(apply_to_field({
                    "field_name": field_name,
                    # keep the raw header (with Oracle's '*' required marker) so
                    # generated output can reproduce the exact template header.
                    "display_name": name,
                    "description": None,
                    "required": is_req,
                    "data_type": data_type,
                    "max_length": max_length,
                    "format_mask": None,
                    "sample_value": sample_text,
                    "lookup_type": None,
                    "validation_notes": None,
                    "sequence": seq,
                    "sheet_name": sname,
                    "required_modules": [],
                }, sheet_cons.get(col_idx + 1)))

        sheets_out.append({"sheet_name": sname, "sequence": len(sheets_out), "field_count": sheet_field_count})

    return {"business_object": business_object, "description": description, "sheets": sheets_out, "fields": fields_out}
