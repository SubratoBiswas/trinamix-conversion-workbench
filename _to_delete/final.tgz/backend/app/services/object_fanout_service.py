"""One source dataset -> the full set of FBDI templates for a conversion object.

Given a conversion *object type* (Supplier / Item / Customer / ...), resolve the
ordered set of FBDI templates that object requires, create one auto-mapped
conversion per resolved template from a SINGLE source dataset, set the Fusion
load order, and chain the load-sequence dependencies. Templates that aren't
seeded in the tool yet are reported as ``missing`` so the user knows exactly
which Oracle templates still need to be uploaded.

This is the engine behind requirement #1: "one source data dump must generate
all related FBDI templates for that conversion object."
"""
from __future__ import annotations

from datetime import datetime

from beanie import PydanticObjectId

from app.models.conversion import Conversion
from app.models.dataset import Dataset
from app.models.dependency import Dependency
from app.models.fbdi import FBDITemplate


# Each step matches ONE FBDI template. A template matches a step when its
# name/business_object contains ALL of ``all`` and NONE of ``none`` (lowercased).
# ``object`` is the canonical target-object label used on the conversion + the
# load-sequence dependency graph. Steps are listed in Fusion load order.
OBJECT_TEMPLATE_CATALOG: dict[str, list[dict]] = {
    # Supplier is 6 separate FBDI files. "Supplier Contact Addresses" is NOT a
    # standalone template — it is a second worksheet inside the Supplier Contacts
    # import template, so it comes out as an extra CSV when that (2-sheet) file's
    # output is generated, rather than as its own conversion.
    "supplier": [
        {"label": "Supplier Import",          "object": "Supplier Import",          "all": ["supplier"],                       "none": ["address", "site", "contact", "bank", "assignment"]},
        {"label": "Supplier Address",         "object": "Supplier Address",         "all": ["supplier", "address"],            "none": ["contact"]},
        {"label": "Supplier Site",            "object": "Supplier Site",            "all": ["supplier", "site"],               "none": ["assignment"]},
        {"label": "Supplier Site Assignment", "object": "Supplier Site Assignment", "all": ["supplier", "site", "assignment"], "none": []},
        {"label": "Supplier Contacts",        "object": "Supplier Contacts",        "all": ["supplier", "contact"],            "none": []},
        {"label": "Supplier Banks",           "object": "Supplier Banks",           "all": ["bank"],                           "none": []},
    ],
    # Customer / Item / AP / AR / GL are each a SINGLE Oracle FBDI workbook with
    # many interface sheets (unlike supplier, which is 7 separate files). So the
    # object resolves to one template; the per-sheet load order lives inside that
    # workbook and is emitted as one CSV per sheet at output time.
    "customer":   [{"label": "Customer Import", "object": "Customer Import", "all": ["customer", "import"], "none": []}],
    "item":       [{"label": "Item Import",     "object": "Item Import",     "all": ["item", "import"],     "none": []}],
    "ap_invoice": [{"label": "AP Invoice Import", "object": "AP Invoice Import", "all": ["invoice"], "none": ["autoinvoice", "receivable"]}],
    "ar_invoice": [{"label": "AR Invoice Import", "object": "AR Invoice Import", "all": ["autoinvoice"], "none": []}],
    "gl_journal": [{"label": "GL Journal Import", "object": "GL Journal Import", "all": ["journal"], "none": []}],
}

# Objects whose FBDI is a single multi-sheet workbook (vs supplier's many files).
# The UI + object detail surface the sheet order as the load sequence for these.
SINGLE_TEMPLATE_OBJECTS: frozenset[str] = frozenset(
    {"customer", "item", "ap_invoice", "ar_invoice", "gl_journal"}
)

# Free-text aliases the UI / detector might supply -> canonical catalog key.
OBJECT_ALIASES: dict[str, str] = {
    "supplier": "supplier", "suppliers": "supplier", "vendor": "supplier", "vendors": "supplier",
    "customer": "customer", "customers": "customer", "client": "customer", "clients": "customer",
    "item": "item", "items": "item", "product": "item", "products": "item", "material": "item",
    "ap invoice": "ap_invoice", "ap_invoice": "ap_invoice", "payables": "ap_invoice", "ap invoices": "ap_invoice",
    "ar invoice": "ar_invoice", "ar_invoice": "ar_invoice", "receivables": "ar_invoice", "ar invoices": "ar_invoice",
    "gl": "gl_journal", "gl journal": "gl_journal", "gl_journal": "gl_journal", "journal": "gl_journal",
}


def object_types() -> list[dict]:
    """Catalog summary for the UI picker: [{key, label, step_count, steps:[...]}]."""
    labels = {
        "supplier": "Supplier", "customer": "Customer", "item": "Item",
        "ap_invoice": "AP Invoices", "ar_invoice": "AR Invoices", "gl_journal": "GL Journals",
    }
    out = []
    for key, steps in OBJECT_TEMPLATE_CATALOG.items():
        out.append({
            "key": key,
            "label": labels.get(key, key.title()),
            "step_count": len(steps),
            "steps": [{"label": s["label"], "load_order": i} for i, s in enumerate(steps, start=1)],
        })
    return out


def resolve_object_key(object_type: str | None) -> str | None:
    if not object_type:
        return None
    k = object_type.strip().lower()
    if k in OBJECT_TEMPLATE_CATALOG:
        return k
    if k in OBJECT_ALIASES:
        return OBJECT_ALIASES[k]
    # substring inference (e.g. "Supplier Addresses Interface" -> supplier)
    for alias, key in OBJECT_ALIASES.items():
        if alias in k:
            return key
    return None


def _matches(template: FBDITemplate, step: dict) -> bool:
    hay = f"{template.name or ''} {template.business_object or ''}".lower()
    if any(kw not in hay for kw in step["all"]):
        return False
    if any(kw in hay for kw in step.get("none", [])):
        return False
    return True


def _find_template_for_step(step: dict, templates: list[FBDITemplate],
                            prefer_richest: bool = False) -> FBDITemplate | None:
    matches = [t for t in templates if _matches(t, step)]
    if not matches:
        return None
    # When several templates match the keywords (e.g. "Customer Import" AND
    # "CustomerReturnImport" both contain customer+import), prefer an EXACT name
    # or business-object match to the step first, then a parsed real template
    # with the most required fields. This keeps the fan-out on the full import
    # workbook rather than a narrow variant.
    label = (step.get("label") or "").strip().lower()
    obj = (step.get("object") or "").strip().lower()

    def _rank(t: FBDITemplate) -> tuple:
        name = (t.name or "").strip().lower()
        bo = (t.business_object or "").strip().lower()
        exact_name = 1 if name in (label, obj) else 0
        exact_bo = 1 if bo in (label, obj) else 0
        parsed = 1 if t.status == "parsed" else 0
        rich = t.required_field_count or 0
        # Single-workbook objects (Customer/Item/AP/AR/GL) MUST resolve to the full
        # multi-sheet FBDI workbook, never a thin same-named stub. Rank the parsed,
        # field-rich workbook FIRST and treat an exact name only as a tiebreaker —
        # otherwise a 20-field "Customer Import" stub beats the 1250-field
        # "Customer Import (HZ_IMP)" workbook purely because its name matches the
        # step label exactly, and the fan-out binds to the wrong template.
        if prefer_richest:
            return (parsed, rich, exact_name, exact_bo)
        return (exact_name, exact_bo, parsed, rich)

    matches.sort(key=_rank, reverse=True)
    return matches[0]


async def generate_object_template_set(
    project_id: str, dataset_id, object_type: str,
) -> dict:
    """Fan source file(s) out to every FBDI template its object type needs.

    ``dataset_id`` may be a single id (back-compat) or a list of ids in PRIORITY
    order. Every created conversion is bound to ALL of them (``dataset_ids``) so
    Generate merges + de-duplicates the sources into one output; the first is the
    primary used for naming/idempotency."""
    key = resolve_object_key(object_type)
    if not key:
        return {"error": f"Unknown conversion object type: {object_type!r}",
                "created": [], "missing": [], "existing": []}

    raw_ids = dataset_id if isinstance(dataset_id, (list, tuple)) else [dataset_id]
    ds_oids = [PydanticObjectId(str(x)) for x in raw_ids if x]
    datasets = [d for d in [await Dataset.get(x) for x in ds_oids] if d]
    if not datasets:
        return {"error": "Dataset not found", "created": [], "missing": [], "existing": []}
    dataset = datasets[0]                       # primary (naming + idempotency)
    all_ds_ids = [d.id for d in datasets]

    templates = await FBDITemplate.find_all().to_list()
    steps = OBJECT_TEMPLATE_CATALOG[key]

    existing_convs = await Conversion.find(
        Conversion.project_id == PydanticObjectId(project_id)
    ).to_list()
    existing_by_pair = {
        (str(c.dataset_id), str(c.template_id)): c
        for c in existing_convs if c.dataset_id and c.template_id
    }
    existing_pairs = set(existing_by_pair.keys())

    # Idempotency was keyed on the PRIMARY dataset alone, so a second call naming a
    # different sheet of the same workbook collided with nothing and inserted a
    # duplicate conversion for the same template — one Customer Import per sheet
    # (CW_Issues row 1). The caller is fixed to send every sheet at once; this is the
    # backstop, because "the UI stopped doing it" is not the same as "it cannot
    # happen". A conversion is treated as the same one when it targets this template
    # AND its bound sources OVERLAP the requested set — deliberately not "same
    # template" alone, since a project may legitimately load two different Customer
    # extracts.
    _want = {str(x) for x in all_ds_ids}
    for _c in existing_convs:
        if not _c.template_id:
            continue
        _have = {str(x) for x in (getattr(_c, "source_dataset_ids", None) or [])}
        if _have & _want:
            _k = (str(dataset.id), str(_c.template_id))
            existing_pairs.add(_k)
            existing_by_pair.setdefault(_k, _c)

    created: list[dict] = []
    existing: list[dict] = []
    missing: list[dict] = []
    resolved_objects: list[str] = []
    now = datetime.utcnow()

    prefer_richest = key in SINGLE_TEMPLATE_OBJECTS
    for i, step in enumerate(steps, start=1):
        tpl = _find_template_for_step(step, templates, prefer_richest=prefer_richest)
        if not tpl:
            missing.append({"label": step["label"], "load_order": i})
            continue
        resolved_objects.append(step["object"])
        if (str(dataset.id), str(tpl.id)) in existing_pairs:
            # Already have this file — heal its load order + object label so the
            # sequence stays correct (e.g. a Supplier Address created ad-hoc at
            # load order 100 becomes step 2).
            ec = existing_by_pair.get((str(dataset.id), str(tpl.id)))
            if ec and (ec.planned_load_order != i or ec.target_object != step["object"]):
                await ec.set({"planned_load_order": i, "target_object": step["object"], "updated_at": now})
            existing.append({"label": step["label"], "template": tpl.name, "load_order": i})
            continue
        conv = Conversion(
            project_id=PydanticObjectId(project_id),
            name=f"{dataset.name} → {step['label']}",
            dataset_id=dataset.id,
            dataset_ids=all_ds_ids,
            template_id=tpl.id,
            target_object=step["object"],
            planned_load_order=i,
            source_type="dataset",
            output_mode="fbdi_download",
            status="draft",
            created_at=now,
            updated_at=now,
        )
        await conv.insert()
        created.append({
            "label": step["label"], "template": tpl.name,
            "conversion_id": str(conv.id), "load_order": i,
        })

    # Chain load-sequence dependency edges across resolved objects (idempotent).
    existing_deps = await Dependency.find(Dependency.relationship_type == "prerequisite").to_list()
    dep_pairs = {(d.source_object.lower(), d.target_object.lower()) for d in existing_deps}
    for src, tgt in zip(resolved_objects, resolved_objects[1:]):
        if (src.lower(), tgt.lower()) in dep_pairs:
            continue
        await Dependency(
            source_object=src, target_object=tgt,
            relationship_type="prerequisite",
            description=f"Load sequence: {src} → {tgt}",
        ).insert()
        dep_pairs.add((src.lower(), tgt.lower()))

    return {
        "object_type": key,
        "created": created,
        "existing": existing,
        "missing": missing,
        "resolved_count": len(resolved_objects),
        "total_steps": len(steps),
    }
