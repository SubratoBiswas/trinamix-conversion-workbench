"""Oracle Fusion Cloud target integration.

Covers three things the Load Management UI needs:
  * which FBDI **interface tables** each conversion's object loads into,
  * a real **Test Connection** against the Fusion REST API (basic auth), and
  * a real **load** via Oracle's ERP Integration Service `importBulkData`
    (uploads the FBDI zip to UCM and submits the import ESS job in one call).

The per-object ESS job metadata below uses canonical Oracle paths; if a job
name differs on a given pod it can be overridden per object, but the request
shape is the standard ERP Integration contract.
"""
from __future__ import annotations

import base64
import io
import logging
import zipfile
from typing import Any, Optional

import httpx

log = logging.getLogger(__name__)

# ── business object → FBDI interface tables it populates in Fusion ───────────
FBDI_INTERFACE_TABLES: dict[str, list[str]] = {
    "UOM":              ["MTL_UOM_INTERFACE", "MTL_UOM_CLASS_INTERFACE", "MTL_UOM_CONVERSIONS_INTERFACE"],
    "Inventory Org":    ["MTL_INV_ORG_PARAMETERS_INT", "HR_ORGANIZATION_INTERFACE"],
    "Item Class":       ["MTL_ITEM_CATEGORIES_INTERFACE", "EGP_ITEM_CLASSES_INTERFACE"],
    "Item":             ["EGP_SYSTEM_ITEMS_INTERFACE", "EGP_ITEM_REVISIONS_INTERFACE", "EGP_ITEM_CATEGORIES_INTF"],
    "Customer":         ["HZ_IMP_PARTIES_T", "HZ_IMP_ACCOUNTS_T", "HZ_IMP_ACCT_SITES_T", "HZ_IMP_CONTACTPTS_T"],
    "Supplier":         ["POZ_SUPPLIERS_INT", "POZ_SUP_ADDRESSES_INT", "POZ_SUP_SITES_INT", "POZ_SUP_CONTACTS_INT"],
    "BOM":              ["BOM_BILL_OF_MTLS_INTERFACE", "BOM_INVENTORY_COMPS_INTERFACE"],
    "On-Hand Balance":  ["INV_TRANSACTIONS_INTERFACE", "MTL_TRANSACTIONS_INTERFACE"],
    "Sales Order":      ["DOO_ORDER_HEADERS_ALL_INT", "DOO_ORDER_LINES_ALL_INT"],
    "Purchase Order":   ["PO_HEADERS_INTERFACE", "PO_LINES_INTERFACE", "PO_DISTRIBUTIONS_INTERFACE"],
    # ── SCM children that load through a parent object's import job ───────────
    "UOM Class":        ["MTL_UOM_CLASS_INTERFACE"],
    "Customer Site":    ["HZ_IMP_ACCT_SITES_T", "HZ_IMP_CONTACTPTS_T"],
    "Supplier Site":    ["POZ_SUP_ADDRESSES_INT", "POZ_SUP_SITES_INT"],
    "Sales Order Line": ["DOO_ORDER_LINES_ALL_INT"],
    # ── SCM objects with their own import job ────────────────────────────────
    "Subinventory":     ["INV_SUBINVENTORIES_INTERFACE"],
    "Locator":          ["INV_LOCATORS_INTERFACE"],
    "Price List":       ["QP_INTERFACE_LIST_HEADERS", "QP_INTERFACE_LIST_LINES"],
    "Lot Number":       ["INV_LOT_NUMBERS_INTERFACE"],
    "Serial Number":    ["INV_SERIAL_NUMBERS_INTERFACE"],
}

# ── business object → ERP Integration import job metadata ────────────────────
# document_account = the UCM account the zip is staged to; JobName = ESS path,name.
FBDI_LOAD_META: dict[str, dict[str, str]] = {
    "UOM":            {"document_account": "scm$/item$/import$",      "job_name": "/oracle/apps/ess/scm/productHub/items/uom/,UnitOfMeasureImport"},
    "Inventory Org":  {"document_account": "scm$/inventory$/import$", "job_name": "/oracle/apps/ess/scm/inventory/setup/,InventoryOrgImport"},
    "Item Class":     {"document_account": "scm$/item$/import$",      "job_name": "/oracle/apps/ess/scm/productHub/items/itemClass/,ItemClassImport"},
    "Item":           {"document_account": "scm$/item$/import$",      "job_name": "/oracle/apps/ess/scm/productHub/items/itemImport/,ItemImportJob"},
    "Customer":       {"document_account": "hz$/customer$/import$",   "job_name": "/oracle/apps/ess/cdm/hz/dataImport/,CustomerImport"},
    "Supplier":       {"document_account": "prc$/supplier$/import$",  "job_name": "/oracle/apps/ess/prc/poz/supplierImport/,SupplierImport"},
    "BOM":            {"document_account": "scm$/bom$/import$",       "job_name": "/oracle/apps/ess/scm/inventory/bom/,BomImport"},
    "On-Hand Balance":{"document_account": "scm$/inventory$/import$", "job_name": "/oracle/apps/ess/scm/inventory/transactions/,OnHandQuantityImport"},
    "Sales Order":    {"document_account": "scm$/order$/import$",     "job_name": "/oracle/apps/ess/scm/doo/import/,ImportSalesOrders"},
    "Purchase Order": {"document_account": "prc$/po$/import$",        "job_name": "/oracle/apps/ess/prc/po/import/,ImportPurchaseOrders"},
    # ── children: submitted through the parent object's ESS import job ────────
    "UOM Class":      {"document_account": "scm$/item$/import$",      "job_name": "/oracle/apps/ess/scm/productHub/items/uom/,UnitOfMeasureImport"},
    "Customer Site":  {"document_account": "hz$/customer$/import$",   "job_name": "/oracle/apps/ess/cdm/hz/dataImport/,CustomerImport"},
    "Supplier Site":  {"document_account": "prc$/supplier$/import$",  "job_name": "/oracle/apps/ess/prc/poz/supplierImport/,SupplierImport"},
    "Sales Order Line":{"document_account": "scm$/order$/import$",    "job_name": "/oracle/apps/ess/scm/doo/import/,ImportSalesOrders"},
    # ── objects with their own ESS import job (job paths may need per-pod tuning)
    "Subinventory":   {"document_account": "scm$/inventory$/import$", "job_name": "/oracle/apps/ess/scm/inventory/setup/,SubinventoryImport"},
    "Locator":        {"document_account": "scm$/inventory$/import$", "job_name": "/oracle/apps/ess/scm/inventory/setup/,LocatorImport"},
    "Price List":     {"document_account": "scm$/pricing$/import$",   "job_name": "/oracle/apps/ess/scm/pricing/priceList/,PriceListImport"},
    "Lot Number":     {"document_account": "scm$/inventory$/import$", "job_name": "/oracle/apps/ess/scm/inventory/setup/,LotNumberImport"},
    "Serial Number":  {"document_account": "scm$/inventory$/import$", "job_name": "/oracle/apps/ess/scm/inventory/setup/,SerialNumberImport"},
}

_FUSION_REST = "/fscmRestApi/resources/11.13.18.05"

# A conversion's object can arrive as the template's display name ("Unit of
# Measure") OR the conversion target_object ("UOM"). Resolve both to the
# canonical key used by the maps above.
_OBJECT_ALIASES: dict[str, str] = {
    "uom": "UOM", "unit of measure": "UOM", "units of measure": "UOM",
    "inventory org": "Inventory Org", "inventory organization": "Inventory Org",
    "item class": "Item Class", "item catalog / class": "Item Class", "item class setup": "Item Class",
    "item": "Item", "item master": "Item", "item master conversion": "Item",
    "customer": "Customer", "customer master": "Customer",
    "supplier": "Supplier", "supplier master": "Supplier",
    "bom": "BOM", "bills of material": "BOM", "bill of materials": "BOM", "bom conversion": "BOM",
    "on-hand balance": "On-Hand Balance", "on hand balance": "On-Hand Balance",
    "on-hand inventory balances": "On-Hand Balance", "on-hand balance load": "On-Hand Balance",
    "sales order": "Sales Order", "open sales orders": "Sales Order", "sales order backlog": "Sales Order",
    "purchase order": "Purchase Order", "open purchase orders": "Purchase Order",
    # newly-wired SCM objects (children + own-job)
    "uom class": "UOM Class", "units of measure classes": "UOM Class", "unit of measure class": "UOM Class",
    "customer site": "Customer Site", "customer sites": "Customer Site",
    "customer sites (bill-to / ship-to)": "Customer Site",
    "supplier site": "Supplier Site", "supplier sites": "Supplier Site",
    "sales order line": "Sales Order Line", "open sales order lines": "Sales Order Line",
    "subinventory": "Subinventory", "subinventories": "Subinventory",
    "subinventories (storage locations)": "Subinventory",
    "locator": "Locator", "locators": "Locator", "locators (bin / rack / row)": "Locator",
    "price list": "Price List", "price lists": "Price List",
    "lot number": "Lot Number", "lot numbers": "Lot Number",
    "serial number": "Serial Number", "serial numbers": "Serial Number",
}


def resolve_object_key(business_object: Optional[str]) -> Optional[str]:
    """Map any of the object's names to the canonical map key (or None)."""
    if not business_object:
        return None
    if business_object in FBDI_INTERFACE_TABLES:
        return business_object
    return _OBJECT_ALIASES.get(business_object.strip().lower())


def interface_tables_for(business_object: Optional[str]) -> list[str]:
    return FBDI_INTERFACE_TABLES.get(resolve_object_key(business_object) or "", [])


def load_meta_for(business_object: Optional[str]) -> dict[str, str]:
    return FBDI_LOAD_META.get(resolve_object_key(business_object) or "", {})


# ── object → Fusion work area where the loaded records can be verified ────────
FUSION_WORK_AREAS: dict[str, str] = {
    "UOM":              "Setup and Maintenance → Manage Units of Measure",
    "UOM Class":        "Setup and Maintenance → Manage Unit of Measure Classes",
    "Inventory Org":    "Setup and Maintenance → Manage Inventory Organizations",
    "Subinventory":     "Setup and Maintenance → Manage Subinventories",
    "Locator":          "Setup and Maintenance → Manage Item Locators",
    "Item Class":       "Product Information Management → Manage Item Classes",
    "Item":             "Product Information Management → Manage Items",
    "Customer":         "Receivables → Billing → Manage Customers",
    "Customer Site":    "Receivables → Billing → Manage Customers (Sites)",
    "Supplier":         "Procurement → Suppliers → Manage Suppliers",
    "Supplier Site":    "Procurement → Suppliers → Manage Suppliers (Sites)",
    "Price List":       "Pricing Administration → Manage Price Lists",
    "On-Hand Balance":  "Inventory Management → Manage Item Quantities",
    "Lot Number":       "Inventory Management → Manage Item Quantities (Lots)",
    "Serial Number":    "Inventory Management → Manage Item Quantities (Serials)",
    "Sales Order":      "Order Management → Manage Orders",
    "Sales Order Line": "Order Management → Manage Orders",
    "BOM":              "Product Information Management → Manage Bills of Material",
    "Purchase Order":   "Procurement → Purchase Orders → Manage Orders",
}


def work_area_for(business_object: Optional[str]) -> Optional[str]:
    return FUSION_WORK_AREAS.get(resolve_object_key(business_object) or "")


# Oracle ESS job phases → a small normalized state vocabulary for the UI.
_STATE_MAP: dict[str, str] = {
    "SUCCEEDED": "succeeded", "COMPLETED": "succeeded", "FINISHED": "succeeded",
    "WARNING": "warning",
    "ERROR": "error", "ERROR_AUTO_RETRY": "error", "VALIDATION_FAILED": "error",
    "CANCELLED": "error", "EXPIRED": "error",
    "RUNNING": "running", "READY": "running", "WAIT": "running", "WAITING": "running",
    "BLOCKED": "running", "PAUSED": "running", "HOLD": "running", "SCHEDULE_READY": "running",
}


def _normalize_ess_state(raw: str) -> str:
    """Map an Oracle ESS phase string to succeeded/warning/error/running/unknown."""
    key = (raw or "").strip().upper().split(":")[0].strip()
    if key in _STATE_MAP:
        return _STATE_MAP[key]
    up = (raw or "").upper()
    if "SUCC" in up:
        return "succeeded"
    if "WARN" in up:
        return "warning"
    if "ERROR" in up or "FAIL" in up:
        return "error"
    if "RUN" in up or "WAIT" in up or "READY" in up or "PROGRESS" in up:
        return "running"
    return "unknown"


def _password(conn) -> str:
    pw = conn.encrypted_password or ""
    return pw[6:] if pw.startswith("PLAIN:") else pw


async def test_fusion_connection(base_url: str, username: str, password: str) -> dict[str, Any]:
    """Basic-auth GET against the Fusion REST resource catalog. 200 = reachable
    with valid credentials; 401 = reached the pod but creds rejected."""
    url = base_url.rstrip("/") + _FUSION_REST + "/"
    try:
        async with httpx.AsyncClient(timeout=25.0, follow_redirects=True) as client:
            r = await client.get(url, auth=(username, password))
        if r.status_code == 200:
            return {"ok": True, "status": 200, "message": "Connected to Oracle Fusion REST API."}
        if r.status_code in (401, 403):
            return {"ok": False, "status": r.status_code, "message": "Reached Fusion, but the credentials were rejected."}
        return {"ok": False, "status": r.status_code, "message": f"Fusion returned HTTP {r.status_code}."}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "status": None, "message": f"Could not reach Fusion: {exc}"}


async def load_to_fusion(conn, business_object: Optional[str], csv_bytes: bytes,
                         base_filename: str) -> dict[str, Any]:
    """Zip the FBDI CSV, base64 it, and submit Oracle ERP Integration
    `importBulkData` — which stages the file in UCM and runs the import job.
    """
    zip_name = (base_filename.rsplit(".", 1)[0] or "fbdi") + ".zip"
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(base_filename, csv_bytes)
    content_b64 = base64.b64encode(buf.getvalue()).decode("ascii")

    meta = load_meta_for(business_object)
    if not meta:
        return {"ok": False, "status": None,
                "message": f"No Fusion import job is mapped for object '{business_object}'. "
                           f"Add it to FBDI_LOAD_META to enable loading.",
                "request_id": None}

    body = {
        "OperationName": "importBulkData",
        "DocumentContent": content_b64,
        "ContentType": "zip",
        "FileName": zip_name,
        "DocumentAccount": meta["document_account"],
        "JobName": meta["job_name"],
        "ParameterList": meta.get("parameter_list", ""),
        "NotificationCode": "10",
        "CallbackURL": "",
    }
    url = conn.base_url.rstrip("/") + _FUSION_REST + "/erpintegrations"
    try:
        async with httpx.AsyncClient(timeout=120.0, follow_redirects=True) as client:
            r = await client.post(url, json=body, auth=(conn.username, _password(conn)))
        ok = r.status_code in (200, 201)
        try:
            data = r.json()
        except Exception:  # noqa: BLE001
            data = {"raw": r.text[:500]}
        req_id = None
        if isinstance(data, dict):
            req_id = (data.get("ReqstId") or data.get("RequestId") or data.get("ReqstID")
                      or data.get("requestId") or data.get("DocumentId") or data.get("result")
                      or data.get("Result"))
        elif isinstance(data, (str, int)):
            # Some pods return the request id as a bare numeric/string body.
            req_id = data
        if req_id is not None:
            req_id = str(req_id).strip() or None
        # Strip the echoed base64 file content so the stored/displayed response keeps
        # the diagnostically useful fields (DocumentId, ReqstId, error text) readable.
        display = data
        if isinstance(data, dict):
            display = {k: ("<base64 omitted>" if k in ("DocumentContent", "Content") else v)
                       for k, v in data.items()}
        # importBulkData returns -1 (sometimes 0) when Oracle ACCEPTS the REST call
        # (HTTP 200) but could NOT queue the import job — typically the UCM document
        # account or ESS job isn't provisioned for this user/pod, or the user lacks
        # ERP Integration privileges. Treat that as a real failure, not "submitted".
        queued = ok and (req_id not in (None, "-1", "0"))
        if ok and not queued:
            doc_id = data.get("DocumentId") if isinstance(data, dict) else None
            ucm = (" The file was not staged to UCM (DocumentId is null), which points to a missing "
                   "ERP Integration / UCM-upload privilege rather than a bad mapping.") if doc_id in (None, "", "null") else ""
            return {
                "ok": False,
                "status": r.status_code,
                "message": (
                    f"Oracle accepted the call but returned request id {req_id or 'none'} — the import job was "
                    f"not queued.{ucm} Use a Fusion user with an ERP Integration role (e.g. Supply Chain "
                    "Application Administrator) and a valid document account; a read-only / demo 'student' user "
                    "can read data but cannot run imports."
                ),
                "request_id": req_id,
                "response": display,
                "file_name": zip_name,
            }
        return {
            "ok": queued,
            "status": r.status_code,
            "message": "Submitted to Fusion ERP Integration." if queued else f"Fusion rejected the load (HTTP {r.status_code}).",
            "request_id": req_id,
            "response": display,
            "file_name": zip_name,
        }
    except Exception as exc:  # noqa: BLE001
        log.warning(f"load_to_fusion failed: {exc}")
        return {"ok": False, "status": None, "message": f"Could not reach Fusion: {exc}", "request_id": None}


async def get_load_status(conn, request_id: str) -> dict[str, Any]:
    """Poll Oracle ERP Integration `getESSJobStatus` for a submitted request.

    Returns a normalized state (succeeded / warning / error / running / unknown)
    plus the raw phase string Fusion reported, so the UI can show progress and
    the final outcome without the user opening Scheduled Processes by hand.
    """
    if not request_id:
        return {"ok": False, "state": "unknown", "raw": None,
                "message": "No Fusion request id recorded for this run."}
    if str(request_id).strip() in ("-1", "0"):
        return {"ok": False, "state": "error", "raw": str(request_id),
                "message": ("Request id -1 means Oracle never queued the import job, so there is no "
                            "ESS process to poll. The load did not run — check the document account, "
                            "import job, and that the user has ERP Integration / SCM privileges on this pod.")}

    url = conn.base_url.rstrip("/") + _FUSION_REST + "/erpintegrations"
    # Different pods accept slightly different param casings — send both.
    body = {
        "OperationName": "getESSJobStatus",
        "ReqstId": str(request_id),
        "requestId": str(request_id),
        "JobType": "ESS",
    }
    try:
        async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
            r = await client.post(url, json=body, auth=(conn.username, _password(conn)))
        raw = ""
        try:
            data = r.json()
            if isinstance(data, dict):
                raw = (data.get("result") or data.get("Result")
                       or data.get("Status") or data.get("status") or r.text)
            else:
                raw = str(data)
        except Exception:  # noqa: BLE001
            raw = r.text
        raw_str = (str(raw) or "").strip()
        state = _normalize_ess_state(raw_str)
        ok = r.status_code in (200, 201)
        if not ok and state == "unknown":
            msg = f"Fusion returned HTTP {r.status_code} while checking status."
        else:
            msg = f"Job {request_id}: {raw_str[:120] or state}"
        return {"ok": ok, "http_status": r.status_code, "state": state,
                "raw": raw_str[:300], "message": msg}
    except Exception as exc:  # noqa: BLE001
        log.warning(f"get_load_status failed: {exc}")
        return {"ok": False, "state": "unknown", "raw": None,
                "message": f"Could not reach Fusion: {exc}"}


# A representative SCM REST resource per object — if the pod/user can read it,
# the module is provisioned and an FBDI import for that object can be attempted.
_PROBE_RESOURCE: dict[str, str] = {
    "Item": "items", "Item Class": "itemClasses",
    "UOM": "items", "UOM Class": "items",
    "Inventory Org": "inventoryOrganizations",
    "Subinventory": "inventoryOrganizations", "Locator": "inventoryOrganizations",
    "On-Hand Balance": "inventoryOrganizations",
    "Lot Number": "items", "Serial Number": "items",
    "Customer": "items", "Customer Site": "items",
    "Supplier": "suppliers", "Supplier Site": "suppliers",
    "Price List": "priceLists",
    "Sales Order": "salesOrdersForOrderHub", "Sales Order Line": "salesOrdersForOrderHub",
    "BOM": "items", "Purchase Order": "draftPurchaseOrders",
}


async def preflight_fusion(conn, business_object: Optional[str]) -> dict[str, Any]:
    """Probe whether this pod/user can actually run an import for the object.

    Two independent checks:
      1. read a representative SCM data resource — proves the module is provisioned
         and readable on this pod;
      2. reach the ERP Integration endpoint — proves the user is authorized for
         integration (the privilege that actually uploads to UCM + submits the job).

    A read-only / demo 'student' user can pass (1) and fail (2) — which is exactly
    the case that returns request id -1. So we only report a confident 'ready' when
    BOTH pass, and otherwise say 'data readable, but integration not verified'.
    """
    key = resolve_object_key(business_object)
    resource = _PROBE_RESOURCE.get(key or "", "items")
    base = conn.base_url.rstrip("/") + _FUSION_REST
    auth = (conn.username, _password(conn))
    try:
        async with httpx.AsyncClient(timeout=25.0, follow_redirects=True) as client:
            rd = await client.get(f"{base}/{resource}?limit=1", auth=auth)
            dsc = rd.status_code
            esc: Optional[int] = None
            if dsc == 200:
                try:
                    re_ = await client.get(f"{base}/erpintegrations?limit=1", auth=auth)
                    esc = re_.status_code
                except Exception:  # noqa: BLE001
                    esc = None
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "level": "unreachable", "resource": resource, "http_status": None,
                "message": f"Could not reach the pod for the pre-flight check: {exc}"}

    if dsc in (401, 403):
        return {"ok": False, "level": "no_privilege", "resource": resource, "http_status": dsc,
                "message": f"Authenticated, but not authorized to read '{resource}' (HTTP {dsc}). The import will return -1 — grant this user the matching SCM / ERP Integration role."}
    if dsc == 404:
        return {"ok": False, "level": "module_missing", "resource": resource, "http_status": dsc,
                "message": f"The '{resource}' resource was not found on this pod (HTTP 404) — this module isn't provisioned here, so an import for {business_object or 'this object'} will return -1. Point the connection at an SCM-provisioned pod."}
    if dsc != 200:
        return {"ok": False, "level": "unknown", "resource": resource, "http_status": dsc,
                "message": f"Pod check returned HTTP {dsc} for '{resource}'. The import may still work — proceed with caution."}

    # Data is readable — interpret the ERP Integration probe (the real gate).
    if esc in (200, 405):
        return {"ok": True, "level": "reachable", "resource": resource, "http_status": esc,
                "message": ("SCM data is readable and the ERP Integration endpoint is reachable. Note: this does "
                            "NOT confirm the UCM-upload / submit privilege — if a load returns request id -1 with "
                            "DocumentId null, the user lacks the ERP Integration role (read access is not enough).")}
    if esc in (401, 403):
        return {"ok": False, "level": "no_erp_integration", "resource": resource, "http_status": esc,
                "message": (f"SCM data is readable, but this user is NOT authorized for ERP Integration (HTTP {esc}) — "
                            "imports cannot upload to UCM or submit the job and will return request id -1. Use a user "
                            "with an ERP Integration role (e.g. Supply Chain Application Administrator).")}
    return {"ok": False, "level": "data_readable", "resource": resource, "http_status": esc,
            "message": ("SCM data is readable, but the ERP Integration privilege (upload to UCM + submit import) could "
                        "not be verified — a read-only / demo user can still get request id -1. The only definitive "
                        "test is an actual load.")}
