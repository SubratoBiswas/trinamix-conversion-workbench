"""No React hook may sit below a component's early return.

Output Preview went blank on every load. `OutputPreviewPage` declared
``useState`` for `fixBusy`/`fixNote` roughly 470 lines below
``if (!project) return <PageLoader />``, so the first render — project still
loading — ran two fewer hooks than the second. React counts hooks by call order
and throws when the count changes between renders: "Rendered more hooks than
during the previous render", shipped as minified error #310. It took the entire
page down, and with no error boundary the symptom was a white screen.

The bug is invisible by eye in a 1,600-line component: the hook looks perfectly
ordinary sitting next to the handler that uses it, and the early return is
hundreds of lines away. It is trivial to reintroduce for exactly that reason,
and the next person to add a piece of state next to its handler will do it
again. So it is checked mechanically.

Pure: stdlib only, reads the shipped frontend source. The frontend has no test
runner, which is why this lives here alongside the other frontend seams.
"""
import re
from pathlib import Path

_FRONTEND = Path(__file__).resolve().parent.parent.parent / "frontend" / "src"

_HOOK = re.compile(r'\b(useState|useEffect|useMemo|useCallback|useRef|useReducer|'
                   r'useLayoutEffect|useContext|useTransition|useDeferredValue)\s*\(')
# A return at exactly two spaces of indent is the component's own — anything
# deeper belongs to a nested function or a callback and is not an early exit
# from the component.
_TOP_RETURN = re.compile(r'^  (?:if\s*\(.*\)\s*)?return\b')
# Where a new component starts, which resets the "have we returned yet" state.
_COMPONENT = re.compile(r'^(?:export\s+)?(?:const|function)\s+[A-Z_]\w*')


def _violations(path: Path):
    """(line, text) for every hook that follows a top-level return in its own
    component."""
    out, returned_at = [], None
    for n, line in enumerate(path.read_text(encoding="utf-8").split("\n"), 1):
        if _COMPONENT.match(line):
            returned_at = None                    # a new component, a clean slate
        if _TOP_RETURN.match(line) and returned_at is None:
            returned_at = n
        indent = len(line) - len(line.lstrip())
        if returned_at and indent == 2 and _HOOK.search(line):
            out.append((returned_at, n, line.strip()))
    return out


def _pages():
    return sorted(p for p in _FRONTEND.rglob("*.tsx"))


def test_no_hook_sits_below_an_early_return():
    """The whole rule, mechanically. A hook below an early return means one
    render path calls fewer hooks than another, and React takes the page down."""
    bad = {}
    for p in _pages():
        v = _violations(p)
        if v:
            bad[str(p.relative_to(_FRONTEND))] = v
    assert not bad, "hooks declared after a component-level return:\n" + "\n".join(
        f"  {f}: return at line {r}, hook at line {n} -> {t}"
        for f, vs in bad.items() for r, n, t in vs)


def test_output_preview_keeps_its_hooks_together():
    """The specific regression, pinned. Every hook in this component is above
    `if (!project) return <PageLoader />`."""
    src = (_FRONTEND / "pages" / "OutputPreviewPage.tsx").read_text(encoding="utf-8")
    lines = src.split("\n")
    # The CODE line, not the comment above the hooks that quotes it.
    guard = next(i for i, l in enumerate(lines, 1)
                 if l.strip().startswith("if (!project) return <PageLoader />"))
    late = [(i, l.strip()) for i, l in enumerate(lines, 1)
            if i > guard and (len(l) - len(l.lstrip())) == 2 and _HOOK.search(l)]
    assert not late, f"hooks below the guard at line {guard}: {late}"


def test_the_two_that_caused_it_are_with_their_siblings():
    lines = (_FRONTEND / "pages" / "OutputPreviewPage.tsx") \
        .read_text(encoding="utf-8").split("\n")

    def line_of(prefix):
        return next(i for i, l in enumerate(lines, 1)
                    if l.strip().startswith(prefix))

    guard = line_of("if (!project) return <PageLoader />")
    assert line_of("const [fixBusy") < guard
    assert line_of("const [colRulesError") < line_of("const [fixBusy")


def test_the_detector_would_catch_it_coming_back():
    """A guard nothing can trip is not a guard. This proves the check fires on
    the exact shape that shipped."""
    import tempfile
    broken = (
        "export const Thing: React.FC = () => {\n"
        "  const [a, setA] = useState(0);\n"
        "  if (!a) return <Loader />;\n"
        "  const [b, setB] = useState(1);\n"
        "  return <div />;\n"
        "};\n"
    )
    with tempfile.TemporaryDirectory() as d:
        f = Path(d) / "Broken.tsx"
        f.write_text(broken, encoding="utf-8")
        found = _violations(f)
    assert found, "the detector does not catch a hook after an early return"
    assert found[0][1] == 4


def test_the_detector_does_not_flag_a_return_inside_a_callback():
    """A `return` inside a nested function is not an early exit from the
    component, and flagging it would make this test noise everyone ignores."""
    import tempfile
    fine = (
        "export const Thing: React.FC = () => {\n"
        "  const load = async () => {\n"
        "    if (!id) return;\n"
        "  };\n"
        "  const [b, setB] = useState(1);\n"
        "  return <div />;\n"
        "};\n"
    )
    with tempfile.TemporaryDirectory() as d:
        f = Path(d) / "Fine.tsx"
        f.write_text(fine, encoding="utf-8")
        assert not _violations(f)
